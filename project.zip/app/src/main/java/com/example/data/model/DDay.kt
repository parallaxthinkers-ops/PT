package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

@Entity(tableName = "ddays")
data class DDay(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val targetDate: Long, // Epoch ms of the target day (local midnight)
    val countUp: Boolean = false,
    val color: Long = 0xFF3B82F6L,
    val isPinned: Boolean = false
) {
    /**
     * Whole calendar days from "today" until the target day: positive = in the future, negative = in the past.
     * Compares LOCAL DATES, so "tomorrow" is always 1 whatever the time of day (the old millisecond maths
     * showed "D-Day" for tomorrow after midnight-ish hours and broke around daylight-saving changes).
     */
    fun getDaysDifference(nowMs: Long = System.currentTimeMillis()): Long {
        val zone = ZoneId.systemDefault()
        val today = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()
        val target = Instant.ofEpochMilli(targetDate).atZone(zone).toLocalDate()
        return ChronoUnit.DAYS.between(today, target)
    }

    fun formattedDDay(nowMs: Long = System.currentTimeMillis()): String {
        val days = getDaysDifference(nowMs)
        return when {
            countUp -> {
                val pastDays = -days
                if (pastDays >= 0) "D+$pastDays" else "D$pastDays"
            }
            days == 0L -> "D-Day"
            days > 0L -> "D-$days"
            else -> "D+${-days}"
        }
    }

    companion object {
        /** Local-midnight epoch ms for a date (what the D-Day picker stores). */
        fun midnightMs(date: LocalDate): Long =
            date.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }
}
