package com.example.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class TimerStatus {
    STOPPED,
    RUNNING,
    PAUSED
}

enum class TimerMode {
    STOPWATCH,
    COUNTDOWN,
    POMODORO
}

enum class PomodoroPhase {
    FOCUS,
    SHORT_BREAK,
    LONG_BREAK
}

data class TimerState(
    val status: TimerStatus = TimerStatus.STOPPED,
    val mode: TimerMode = TimerMode.STOPWATCH,
    val subjectId: Long? = null,
    val subjectName: String = "",
    val subjectColor: Long = 0xFF3B82F6L,
    val sessionStartTime: Long = 0L,     // When this overall study session began
    val lastResumeTime: Long = 0L,       // When the current running slice started
    val accumulatedMillis: Long = 0L,    // Milliseconds accumulated during pauses
    val currentElapsedSeconds: Long = 0L,
    val targetSeconds: Long = 0L,        // For countdown or pomodoro phase
    val remainingSeconds: Long = 0L,     // For countdown or pomodoro
    val pomodoroPhase: PomodoroPhase = PomodoroPhase.FOCUS,
    val pomodoroCycle: Int = 1,
    val interruptions: Int = 0
)

object TimerStateManager {
    private val _timerState = MutableStateFlow(TimerState())
    val timerState: StateFlow<TimerState> = _timerState.asStateFlow()

    fun updateState(transform: (TimerState) -> TimerState) {
        _timerState.value = transform(_timerState.value)
    }

    fun setState(state: TimerState) {
        _timerState.value = state
    }
}
