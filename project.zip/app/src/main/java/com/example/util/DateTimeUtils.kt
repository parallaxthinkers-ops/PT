package com.example.util

import com.example.data.model.StudySession
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Date and time helpers. Everything here is thread-safe (java.time, no shared SimpleDateFormat).
 *
 * Two rules:
 *  - DATABASE KEYS (yyyy-MM-dd) are ALWAYS formatted with Locale.US so digits stay 0-9. The old code used the
 *    device locale, which would turn keys into Bengali digits on a Bengali phone and silently break lookups.
 *  - Clocks and durations use ASCII digits too. Only words (day names, months) follow the app language.
 */
object DateTimeUtils {
    private val formatterCache = ConcurrentHashMap<String, DateTimeFormatter>()

    private fun formatter(pattern: String, locale: Locale): DateTimeFormatter =
        formatterCache.getOrPut(pattern + "|" + locale.toLanguageTag()) {
            DateTimeFormatter.ofPattern(pattern, locale)
        }

    private fun zone(): ZoneId = ZoneId.systemDefault()

    private fun toLocal(timestampMs: Long): LocalDateTime =
        Instant.ofEpochMilli(timestampMs).atZone(zone()).toLocalDateTime()

    /** Database date key "yyyy-MM-dd" (ASCII digits, never localized). */
    fun formatDate(timestampMs: Long): String =
        formatter("yyyy-MM-dd", Locale.US).format(toLocal(timestampMs))

    fun formatDateKey(date: LocalDate): String = formatter("yyyy-MM-dd", Locale.US).format(date)

    fun parseDateKey(key: String): LocalDate? = try {
        LocalDate.parse(key, formatter("yyyy-MM-dd", Locale.US))
    } catch (_: Exception) {
        null
    }

    /** e.g. "Wed, Oct 14" in the app language. */
    fun formatDayHeader(timestampMs: Long): String =
        formatter("EEE, MMM d", Locale.getDefault()).format(toLocal(timestampMs))

    /** e.g. "October 2026" in the app language. */
    fun formatMonth(timestampMs: Long): String =
        formatter("MMMM yyyy", Locale.getDefault()).format(toLocal(timestampMs))

    /** e.g. "Wednesday" in the app language. */
    fun formatWeekday(timestampMs: Long): String =
        formatter("EEEE", Locale.getDefault()).format(toLocal(timestampMs))

    /** 24 h "HH:mm" or 12 h "h:mm a" (ASCII digits). */
    fun formatTime(timestampMs: Long, is12Hour: Boolean = false): String {
        val pattern = if (is12Hour) "h:mm a" else "HH:mm"
        return formatter(pattern, Locale.US).format(toLocal(timestampMs))
    }

    /** Hour-of-day label for the timeline grid, e.g. "05:00" or "5 AM". */
    fun formatHourLabel(hour: Int, is12Hour: Boolean): String {
        val h = ((hour % 24) + 24) % 24
        return if (is12Hour) {
            val suffix = if (h < 12) "AM" else "PM"
            val twelve = if (h % 12 == 0) 12 else h % 12
            "$twelve $suffix"
        } else {
            String.format(Locale.US, "%02d:00", h)
        }
    }

    /**
     * The [startMs, endMs) range of the study day containing [timestampMs],
     * where the study day resets at [dayStartHour] (0..23). Daylight-saving safe.
     */
    fun getStudyDayRange(timestampMs: Long, dayStartHour: Int): Pair<Long, Long> {
        val z = zone()
        val zdt = Instant.ofEpochMilli(timestampMs).atZone(z)
        var date = zdt.toLocalDate()
        if (zdt.hour < dayStartHour) date = date.minusDays(1)
        return studyDayRangeForDate(date, dayStartHour)
    }

    /** The [startMs, endMs) range of the study day that STARTS on calendar [date]. */
    fun studyDayRangeForDate(date: LocalDate, dayStartHour: Int): Pair<Long, Long> {
        val z = zone()
        val start = date.atTime(dayStartHour.coerceIn(0, 23), 0).atZone(z).toInstant().toEpochMilli()
        val end = date.plusDays(1).atTime(dayStartHour.coerceIn(0, 23), 0).atZone(z).toInstant().toEpochMilli()
        return Pair(start, end)
    }

    /** The study-day date (the calendar date on which that study day started) for [timestampMs]. */
    fun studyDateOf(timestampMs: Long, dayStartHour: Int): LocalDate {
        val zdt = Instant.ofEpochMilli(timestampMs).atZone(zone())
        val date = zdt.toLocalDate()
        return if (zdt.hour < dayStartHour) date.minusDays(1) else date
    }

    /** Date string "yyyy-MM-dd" of the study day for [timestampMs]. */
    fun getStudyDateString(timestampMs: Long, dayStartHour: Int): String =
        formatDateKey(studyDateOf(timestampMs, dayStartHour))

    /**
     * Effective duration in milliseconds of [session] within [[rangeStartMs], [rangeEndMs]).
     * Handles sessions that cross a day-start boundary.
     */
    fun getSessionOverlapMillis(session: StudySession, rangeStartMs: Long, rangeEndMs: Long): Long {
        val effectiveStart = maxOf(session.startTime, rangeStartMs)
        val effectiveEnd = minOf(session.endTime, rangeEndMs)
        return (effectiveEnd - effectiveStart).coerceAtLeast(0L)
    }

    /** "HH:MM:SS" with ASCII digits. */
    fun formatTimerClock(totalSeconds: Long): String {
        val safeSeconds = totalSeconds.coerceAtLeast(0L)
        val hours = safeSeconds / 3600
        val minutes = (safeSeconds % 3600) / 60
        val seconds = safeSeconds % 60
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    /** "Xh YYm", "Ym ZZs" or "Zs". */
    fun formatDurationShort(totalSeconds: Long): String {
        val safeSeconds = totalSeconds.coerceAtLeast(0L)
        val hours = safeSeconds / 3600
        val minutes = (safeSeconds % 3600) / 60
        val seconds = safeSeconds % 60
        return when {
            hours > 0 -> String.format(Locale.US, "%dh %02dm", hours, minutes)
            minutes > 0 -> String.format(Locale.US, "%dm %02ds", minutes, seconds)
            else -> String.format(Locale.US, "%ds", seconds)
        }
    }

    /** Compact for tight UI: "2h 15m", "45m", "30s". Never shows seconds once past a minute. */
    fun formatDurationCompact(totalSeconds: Long): String {
        val safeSeconds = totalSeconds.coerceAtLeast(0L)
        val hours = safeSeconds / 3600
        val minutes = (safeSeconds % 3600) / 60
        return when {
            hours > 0 && minutes > 0 -> String.format(Locale.US, "%dh %dm", hours, minutes)
            hours > 0 -> String.format(Locale.US, "%dh", hours)
            minutes > 0 -> String.format(Locale.US, "%dm", minutes)
            else -> String.format(Locale.US, "%ds", safeSeconds)
        }
    }
}
