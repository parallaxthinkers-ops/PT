package com.example.ui.screens.onboarding

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.appBackground
import com.example.StudyApplication
import com.example.data.model.Subject
import com.example.data.repository.AppSettings
import com.example.ui.components.AccentPicker
import com.example.ui.components.AppCard
import com.example.ui.components.PillSelector
import com.example.ui.theme.SubjectColors
import com.example.ui.theme.Ui
import kotlinx.coroutines.launch

private const val STEP_COUNT = 3

/**
 * First-run set-up. Language, theme and accent are written the moment they are chosen, so the screen
 * itself shows the result while the person is still deciding.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val app = context.applicationContext as StudyApplication
    val scope = rememberCoroutineScope()
    val settings by app.settingsRepository.settings.collectAsState(initial = AppSettings())

    var step by remember { mutableIntStateOf(1) }
    var subjectName by remember { mutableStateOf("") }
    var selectedColor by remember { mutableLongStateOf(SubjectColors.first()) }
    var targetHours by remember { mutableIntStateOf(4) }

    var showNotificationRationale by remember { mutableStateOf(false) }
    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> onFinished() }

    val modeLabels = mapOf(
        "SYSTEM" to stringResource(R.string.theme_mode_system),
        "LIGHT" to stringResource(R.string.theme_mode_light),
        "DARK" to stringResource(R.string.theme_mode_dark)
    )
    val styleLabels = mapOf(
        "MINIMAL" to stringResource(R.string.style_minimal),
        "SOFT" to stringResource(R.string.style_soft)
    )

    fun completeOnboarding() {
        scope.launch {
            val name = subjectName.trim()
            if (name.isNotEmpty()) {
                val newId = app.studyRepository.insertSubject(Subject(name = name, color = selectedColor, order = 0))
                app.settingsRepository.setSelectedSubjectId(newId)
            }
            app.studyRepository.setUniformGoal(targetHours * 60)
            app.settingsRepository.setOnboardingCompleted(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                showNotificationRationale = true
            } else {
                onFinished()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .appBackground()
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        // Top row: progress dots on the left, Skip on the right.
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                (1..STEP_COUNT).forEach { s ->
                    Box(
                        modifier = Modifier
                            .height(6.dp)
                            .width(if (step == s) 24.dp else 6.dp)
                            .clip(CircleShape)
                            .background(
                                if (step == s) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                    )
                }
            }
            TextButton(
                onClick = {
                    scope.launch {
                        app.settingsRepository.setOnboardingCompleted(true)
                        onFinished()
                    }
                },
                modifier = Modifier.testTag("onboarding_skip_button")
            ) {
                Text(stringResource(R.string.onboarding_skip), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AnimatedContent(
                targetState = step,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "onboarding_step"
            ) { currentStep ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                ) {
                    when (currentStep) {
                        1 -> {
                            Image(
                                painter = painterResource(R.drawable.logo_mark),
                                contentDescription = null,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.size(88.dp)
                            )
                            Spacer(Modifier.height(24.dp))
                            Text(
                                text = stringResource(R.string.onboarding_welcome_title),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onBackground,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = stringResource(R.string.onboarding_welcome_tagline),
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(24.dp))
                            AppCard(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = stringResource(R.string.about_offline_title),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = stringResource(R.string.about_offline_desc),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(Modifier.height(20.dp))
                            PillSelector(
                                options = listOf("en", "bn"),
                                selected = settings.language,
                                // A language is always written in itself, so these two names are not translated.
                                label = { if (it == "bn") "বাংলা" else "English" },
                                onSelect = { lang -> scope.launch { app.settingsRepository.setLanguage(lang) } }
                            )
                        }
                        2 -> {
                            Text(
                                text = stringResource(R.string.onboarding_subject_title),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onBackground,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = stringResource(R.string.onboarding_subject_desc),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(24.dp))
                            OutlinedTextField(
                                value = subjectName,
                                onValueChange = { subjectName = it.take(40) },
                                label = { Text(stringResource(R.string.subject_name)) },
                                placeholder = { Text(stringResource(R.string.onboarding_subject_hint)) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("onboarding_subject_input")
                            )
                            Spacer(Modifier.height(20.dp))
                            Text(
                                text = stringResource(R.string.subject_color),
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.align(Alignment.Start)
                            )
                            Spacer(Modifier.height(10.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                SubjectColors.forEach { colorValue ->
                                    val isSelected = selectedColor == colorValue
                                    val color = Color(colorValue)
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                            .border(
                                                width = if (isSelected) 3.dp else 0.dp,
                                                color = if (isSelected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                                shape = CircleShape
                                            )
                                            .clickable { selectedColor = colorValue },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Filled.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        else -> {
                            Text(
                                text = stringResource(R.string.onboarding_look_title),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onBackground,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(20.dp))
                            Text(
                                text = stringResource(R.string.onboarding_goal_hours, targetHours.toString()),
                                style = MaterialTheme.typography.displaySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Slider(
                                value = targetHours.toFloat(),
                                onValueChange = { targetHours = it.toInt().coerceIn(1, 14) },
                                valueRange = 1f..14f,
                                steps = 12,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(16.dp))
                            PillSelector(
                                options = listOf("SYSTEM", "LIGHT", "DARK"),
                                selected = settings.themeMode.uppercase(),
                                label = { modeLabels[it] ?: it },
                                onSelect = { mode -> scope.launch { app.settingsRepository.setThemeMode(mode) } }
                            )
                            Spacer(Modifier.height(12.dp))
                            PillSelector(
                                options = listOf("MINIMAL", "SOFT"),
                                selected = settings.themeStyle,
                                label = { styleLabels[it] ?: it },
                                onSelect = { style -> scope.launch { app.settingsRepository.setThemeStyle(style) } }
                            )
                            Spacer(Modifier.height(20.dp))
                            AccentPicker(
                                selected = settings.accentColor,
                                onSelect = { color -> scope.launch { app.settingsRepository.setAccentColor(color) } }
                            )
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (step > 1) {
                OutlinedButton(
                    onClick = { step-- },
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.testTag("onboarding_back_button")
                ) {
                    Text(stringResource(R.string.back))
                }
            } else {
                Spacer(Modifier.width(1.dp))
            }

            Button(
                onClick = { if (step < STEP_COUNT) step++ else completeOnboarding() },
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.testTag("onboarding_next_button")
            ) {
                Text(
                    stringResource(if (step < STEP_COUNT) R.string.onboarding_next else R.string.onboarding_get_started),
                    color = Ui.extra.onAccent
                )
            }
        }
    }

    if (showNotificationRationale) {
        AlertDialog(
            onDismissRequest = {
                showNotificationRationale = false
                onFinished()
            },
            title = { Text(stringResource(R.string.notification_permission_rationale_title)) },
            text = { Text(stringResource(R.string.notification_permission_rationale_desc)) },
            confirmButton = {
                Button(
                    onClick = {
                        showNotificationRationale = false
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            onFinished()
                        }
                    }
                ) {
                    Text(stringResource(R.string.onboarding_notifications_allow), color = Ui.extra.onAccent)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showNotificationRationale = false
                        onFinished()
                    }
                ) {
                    Text(stringResource(R.string.onboarding_notifications_later))
                }
            }
        )
    }
}
