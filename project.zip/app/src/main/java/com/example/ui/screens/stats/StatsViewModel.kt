package com.example.ui.screens.stats

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.StudyApplication
import com.example.data.model.Goal
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.util.DateTimeUtils
import com.example.util.StudyMath
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.time.format.TextStyle
import java.util.Locale

enum class StatsTab { DAY, WEEK, MONTH, YEAR }

data class SubjectDistributionItem(
    val subject: Subject?,
    val durationSeconds: Long,
    val percentage: Float
)

data class BarChartPoint(
    val label: String,
    val seconds: Long,
    val isBest: Boolean = false
)

data class HeatmapDay(
    val dayNumber: Int,
    /** Start of that study day, so the Timeline can jump straight to it. */
    val timestampMs: Long,
    val studySeconds: Long,
    val intensity: Int // 0 to 4
)

/** One tappable cell of the calendar above the stats: a day, a week or a month. */
data class CalendarCell(
    /** The first date of what the cell stands for. Tapping it makes this the shown period. */
    val date: LocalDate,
    /** "14" for a day, "8/4" for a week, "Aug" for a month. */
    val label: String,
    val seconds: Long,
    /** 0 = nothing, 1..4 = more and more, measured against the goal for that stretch of days. */
    val level: Int,
    /** True when it starts after today, so it can be drawn dimmed. */
    val isFuture: Boolean
)

/**
 * The calendar the Day, Week and Month tabs show (a month of days, a quarter of weeks, a year of months).
 * [titleStart] is the first date of that page: the 1st of the month, of the quarter, or of the year.
 */
data class CalendarGrid(
    val tab: StatsTab,
    val columns: Int,
    val leadingBlanks: Int,
    val cells: List<CalendarCell>,
    val totalSeconds: Long,
    val titleStart: LocalDate
)

/**
 * The "Up to ..." chart: a record (grey steps) against today (orange line), at the same point of the day, week or month.
 *
 * [baselineLevels] has one running total per bin, taken at the END of the bin (24 hours, 7 days, or the days of the month).
 * [todayLevels] has one running total per bin up to and including "now", so its last value is today's total so far.
 * [spanBins] is how many bins the orange line covers (a fraction on the Day tab, where "now" is inside an hour).
 * The record is the period being viewed; when the viewed period IS the current one, it is the period before it.
 */
data class CompareChart(
    val tab: StatsTab,
    val bins: Int,
    val baselineLevels: List<Long>,
    val todayLevels: List<Long>,
    val spanBins: Float,
    /** The bin "now" falls in: day of the week counted from the first day (0 = first), day of the month - 1, or whole hours since the study day began. */
    val nowIndex: Int,
    /** Today's running total minus the record's at the same point. Negative = behind the record. */
    val diffSeconds: Long,
    /** First date of the record, for its label. */
    val baselineStart: LocalDate,
    val baselineIsPrevious: Boolean,
    /** The hour of day the Day axis starts at (the study-day start). */
    val axisStartHour: Int
)

/**
 * Everything the Stats screen shows. It carries numbers, dates and short labels only; the sentences
 * ("+1h 05m vs previous week") are built in the screen from string resources, so they follow the language.
 */
data class StatsUiState(
    val selectedTab: StatsTab = StatsTab.WEEK,
    val selectedSubjectId: Long? = null,
    val periodStart: LocalDate = LocalDate.now(),
    val periodEnd: LocalDate = LocalDate.now(),
    val periodStartMs: Long = 0L,
    /** True when today's study day lies inside the shown period, so the "Today" shortcut can be hidden. */
    val isCurrentPeriod: Boolean = true,
    val totalSeconds: Long = 0L,
    val previousPeriodSeconds: Long = 0L,
    /** Average over the days of the period that have already started, so a half-finished week is not diluted. */
    val dailyAverageSeconds: Long = 0L,
    /** Label of the best bar, for example "Mon" or "14:00". Null when nothing was studied. */
    val bestLabel: String? = null,
    val bestSeconds: Long = 0L,
    val totalSessionsCount: Int = 0,
    val longestSessionSeconds: Long = 0L,
    val goalAchievedDaysCount: Int = 0,
    val elapsedDays: Int = 1,
    val totalInterruptions: Int = 0,
    val subjects: List<Subject> = emptyList(),
    val distribution: List<SubjectDistributionItem> = emptyList(),
    val barChartPoints: List<BarChartPoint> = emptyList(),
    val heatmapMonthStartMs: Long = 0L,
    /** Empty cells before day 1, so the first day sits under its own weekday header. */
    val heatmapLeadingBlanks: Int = 0,
    val heatmapDays: List<HeatmapDay> = emptyList(),
    /** Null on the Year tab, which keeps the plain month heatmap. */
    val calendar: CalendarGrid? = null,
    /** Null on the Year tab. */
    val compare: CompareChart? = null,
    val firstDayOfWeek: DayOfWeek = DayOfWeek.MONDAY
)

/** Pure statistics maths. No Android types, so it can be unit tested. */
object StatsEngine {

    fun dayOfWeekFromCalendar(calendarDay: Int): DayOfWeek =
        if (calendarDay == 1) DayOfWeek.SUNDAY else DayOfWeek.of(((calendarDay - 2) % 7 + 7) % 7 + 1)

    /** First and last date of the period that contains [anchor]. */
    fun periodOf(tab: StatsTab, anchor: LocalDate, firstDay: DayOfWeek): Pair<LocalDate, LocalDate> = when (tab) {
        StatsTab.DAY -> anchor to anchor
        StatsTab.WEEK -> {
            val start = anchor.with(TemporalAdjusters.previousOrSame(firstDay))
            start to start.plusDays(6)
        }
        StatsTab.MONTH -> {
            val start = anchor.withDayOfMonth(1)
            start to start.plusMonths(1).minusDays(1)
        }
        StatsTab.YEAR -> {
            val start = anchor.withDayOfYear(1)
            start to start.plusYears(1).minusDays(1)
        }
    }

    /** The same period one step earlier (the period the current one is compared with). */
    fun previousPeriod(tab: StatsTab, start: LocalDate, firstDay: DayOfWeek): Pair<LocalDate, LocalDate> = when (tab) {
        StatsTab.DAY -> start.minusDays(1) to start.minusDays(1)
        StatsTab.WEEK -> start.minusDays(7) to start.minusDays(1)
        StatsTab.MONTH -> periodOf(StatsTab.MONTH, start.minusMonths(1), firstDay)
        StatsTab.YEAR -> periodOf(StatsTab.YEAR, start.minusYears(1), firstDay)
    }

    fun shift(tab: StatsTab, anchor: LocalDate, direction: Int): LocalDate = when (tab) {
        StatsTab.DAY -> anchor.plusDays(direction.toLong())
        StatsTab.WEEK -> anchor.plusDays(7L * direction)
        StatsTab.MONTH -> anchor.plusMonths(direction.toLong())
        StatsTab.YEAR -> anchor.plusYears(direction.toLong())
    }

    /** Days of [start]..[end] that have begun by [today]. */
    fun elapsedDays(start: LocalDate, end: LocalDate, today: LocalDate): Int {
        if (today.isBefore(start)) return 0
        val last = if (end.isBefore(today)) end else today
        return (ChronoUnit.DAYS.between(start, last) + 1).toInt()
    }

    private fun sumDays(secondsByDay: Map<LocalDate, Long>, start: LocalDate, end: LocalDate): Long {
        var total = 0L
        var d = start
        while (!d.isAfter(end)) {
            total += secondsByDay[d] ?: 0L
            d = d.plusDays(1)
        }
        return total
    }

    /**
     * How strongly a cell is coloured, 0..4. [goalSeconds] is the goal for all [days] days of the cell, so a
     * week is measured against a week of goals and a month against a month of goals. With no goal at all it
     * falls back to fixed hours per day (1h, 2h, 4h).
     */
    fun intensity(seconds: Long, goalSeconds: Long, days: Int = 1): Int {
        if (seconds <= 0L) return 0
        if (goalSeconds <= 0L) {
            val perDay = seconds / days.coerceAtLeast(1)
            return if (perDay >= 4 * 3600L) 4 else if (perDay >= 2 * 3600L) 3 else if (perDay >= 3600L) 2 else 1
        }
        val ratio = seconds.toDouble() / goalSeconds.toDouble()
        return when {
            ratio >= 1.0 -> 4
            ratio >= 0.66 -> 3
            ratio >= 0.33 -> 2
            else -> 1
        }
    }

    /** "30:36" for 30 hours 36 minutes. Hours are not capped at 24, because a week or a month is longer than a day. */
    fun clock(totalSeconds: Long): String {
        val s = totalSeconds.coerceAtLeast(0L)
        return String.format(Locale.US, "%d:%02d", s / 3600L, (s % 3600L) / 60L)
    }

    /** The first and last day of the calendar quarter that contains [anchor]. */
    fun quarterOf(anchor: LocalDate): Pair<LocalDate, LocalDate> {
        val first = LocalDate.of(anchor.year, ((anchor.monthValue - 1) / 3) * 3 + 1, 1)
        return first to first.plusMonths(3).minusDays(1)
    }

    /** Quarter number 1..4. */
    fun quarterNumber(anchor: LocalDate): Int = (anchor.monthValue - 1) / 3 + 1

    /**
     * The dates the calendar of a tab needs data for. Day: the month. Week: the whole quarter, widened to full weeks.
     * Month: the year. Year: the month (for the plain heatmap).
     */
    fun calendarRange(tab: StatsTab, anchor: LocalDate, firstDay: DayOfWeek): Pair<LocalDate, LocalDate> = when (tab) {
        StatsTab.DAY, StatsTab.YEAR -> {
            val first = anchor.withDayOfMonth(1)
            first to first.plusMonths(1).minusDays(1)
        }
        StatsTab.WEEK -> {
            val (qs, qe) = quarterOf(anchor)
            qs.with(TemporalAdjusters.previousOrSame(firstDay)) to
                qe.with(TemporalAdjusters.nextOrSame(firstDay.minus(1)))
        }
        StatsTab.MONTH -> {
            val first = anchor.withDayOfYear(1)
            first to first.plusYears(1).minusDays(1)
        }
    }

    /** The calendar of a tab, or null for the Year tab. */
    fun buildCalendar(
        tab: StatsTab,
        anchor: LocalDate,
        today: LocalDate,
        firstDay: DayOfWeek,
        secondsByDay: Map<LocalDate, Long>,
        goalSeconds: (LocalDate) -> Long,
        locale: Locale
    ): CalendarGrid? {
        fun goalSum(from: LocalDate, to: LocalDate): Long {
            var sum = 0L
            var d = from
            while (!d.isAfter(to)) { sum += goalSeconds(d); d = d.plusDays(1) }
            return sum
        }
        return when (tab) {
            StatsTab.DAY -> {
                val monthStart = anchor.withDayOfMonth(1)
                val cells = (0 until monthStart.lengthOfMonth()).map { i ->
                    val date = monthStart.plusDays(i.toLong())
                    val sec = secondsByDay[date] ?: 0L
                    CalendarCell(date, date.dayOfMonth.toString(), sec, intensity(sec, goalSeconds(date)), date.isAfter(today))
                }
                CalendarGrid(
                    tab = tab,
                    columns = 7,
                    leadingBlanks = (monthStart.dayOfWeek.value - firstDay.value + 7) % 7,
                    cells = cells,
                    totalSeconds = cells.sumOf { it.seconds },
                    titleStart = monthStart
                )
            }
            StatsTab.WEEK -> {
                val (qs, qe) = quarterOf(anchor)
                val (gridStart, gridEnd) = calendarRange(StatsTab.WEEK, anchor, firstDay)
                val cells = ArrayList<CalendarCell>()
                var weekStart = gridStart
                while (!weekStart.isAfter(gridEnd)) {
                    val weekEnd = weekStart.plusDays(6)
                    val sec = sumDays(secondsByDay, weekStart, weekEnd)
                    cells.add(
                        CalendarCell(
                            date = weekStart,
                            label = "${weekStart.monthValue}/${weekStart.dayOfMonth}",
                            seconds = sec,
                            level = intensity(sec, goalSum(weekStart, weekEnd), 7),
                            isFuture = weekStart.isAfter(today)
                        )
                    )
                    weekStart = weekStart.plusDays(7)
                }
                CalendarGrid(
                    tab = tab,
                    columns = 5,
                    leadingBlanks = 0,
                    cells = cells,
                    totalSeconds = sumDays(secondsByDay, qs, qe),
                    titleStart = qs
                )
            }
            StatsTab.MONTH -> {
                val yearStart = anchor.withDayOfYear(1)
                val cells = (1..12).map { m ->
                    val monthStart = LocalDate.of(yearStart.year, m, 1)
                    val monthEnd = monthStart.plusMonths(1).minusDays(1)
                    val sec = sumDays(secondsByDay, monthStart, monthEnd)
                    CalendarCell(
                        date = monthStart,
                        label = monthStart.month.getDisplayName(TextStyle.SHORT, locale),
                        seconds = sec,
                        level = intensity(sec, goalSum(monthStart, monthEnd), monthStart.lengthOfMonth()),
                        isFuture = monthStart.isAfter(today)
                    )
                }
                CalendarGrid(
                    tab = tab,
                    columns = 4,
                    leadingBlanks = 0,
                    cells = cells,
                    totalSeconds = cells.sumOf { it.seconds },
                    titleStart = yearStart
                )
            }
            StatsTab.YEAR -> null
        }
    }

    /** "26:25:12". Hours are not capped at 24. */
    fun clockSeconds(totalSeconds: Long): String {
        val s = totalSeconds.coerceAtLeast(0L)
        return String.format(Locale.US, "%d:%02d:%02d", s / 3600L, (s % 3600L) / 60L, s % 60L)
    }

    /** The running totals of a list of per-bin seconds, "after each bin". */
    fun runningTotals(perBin: List<Long>): List<Long> {
        var sum = 0L
        return perBin.map { sum += it; sum }
    }

    /**
     * The "Up to ..." chart, or null for the Year tab.
     *
     * Week and Month work in whole days (so "Up to Thursday" includes all of Thursday on both sides, like YPT). The Day
     * tab works by the hour from the start of the study day and compares at the exact time of day.
     *
     * @param viewedStart first date of the period being viewed
     * @param baselineSessions sessions that cover the record (the viewed period, or the one before it)
     * @param currentSessions sessions that cover the current period (today, this week or this month)
     */
    fun buildCompareChart(
        tab: StatsTab,
        viewedStart: LocalDate,
        today: LocalDate,
        nowMs: Long,
        dayStartHour: Int,
        firstDay: DayOfWeek,
        baselineSessions: List<StudySession>,
        currentSessions: List<StudySession>,
        zone: ZoneId = ZoneId.systemDefault()
    ): CompareChart? {
        if (tab == StatsTab.YEAR) return null
        val (curStart, _) = periodOf(tab, today, firstDay)
        val viewedIsCurrent = viewedStart == curStart
        val (baseStart, baseEnd) = if (viewedIsCurrent) {
            previousPeriod(tab, curStart, firstDay)
        } else {
            periodOf(tab, viewedStart, firstDay)
        }

        if (tab == StatsTab.DAY) {
            val bins = 24
            val baseDayStartMs = DateTimeUtils.studyDayRangeForDate(baseStart, dayStartHour).first
            val curDayStartMs = DateTimeUtils.studyDayRangeForDate(today, dayStartHour).first
            val baseZoned = Instant.ofEpochMilli(baseDayStartMs).atZone(zone)
            val curZoned = Instant.ofEpochMilli(curDayStartMs).atZone(zone)
            fun slotStartMs(day: java.time.ZonedDateTime, h: Int): Long =
                day.plusHours(h.toLong()).toInstant().toEpochMilli()
            fun overlapSeconds(sessions: List<StudySession>, from: Long, to: Long): Long {
                if (to <= from) return 0L
                var sec = 0L
                for (s in sessions) sec += DateTimeUtils.getSessionOverlapMillis(s, from, to) / 1000L
                return sec
            }
            val baseSessions = baselineSessions.filter { it.endTime > baseDayStartMs && it.startTime < slotStartMs(baseZoned, bins) }
            val curSessions = currentSessions.filter { it.endTime > curDayStartMs && it.startTime < slotStartMs(curZoned, bins) }

            val baselineLevels = runningTotals((0 until bins).map { h ->
                overlapSeconds(baseSessions, slotStartMs(baseZoned, h), slotStartMs(baseZoned, h + 1))
            })

            val elapsedMs = (nowMs - curDayStartMs).coerceAtLeast(0L)
            val elapsedHours = (elapsedMs / 3_600_000f).coerceIn(0f, bins.toFloat())
            val nowIndex = elapsedHours.toInt().coerceAtMost(bins - 1)
            val levels = ArrayList<Long>()
            var running = 0L
            for (h in 0 until nowIndex) {
                running += overlapSeconds(curSessions, slotStartMs(curZoned, h), slotStartMs(curZoned, h + 1))
                levels.add(running)
            }
            val todayNow = running + overlapSeconds(curSessions, slotStartMs(curZoned, nowIndex), curDayStartMs + elapsedMs)
            levels.add(todayNow)

            // The record at the same time of day, exactly.
            val baselineNow = overlapSeconds(baseSessions, baseDayStartMs, baseDayStartMs + elapsedMs)
            return CompareChart(
                tab = tab,
                bins = bins,
                baselineLevels = baselineLevels,
                todayLevels = levels,
                spanBins = elapsedHours,
                nowIndex = nowIndex,
                diffSeconds = todayNow - baselineNow,
                baselineStart = baseStart,
                baselineIsPrevious = viewedIsCurrent,
                axisStartHour = dayStartHour
            )
        }

        // Week and Month: whole days.
        val bins = (ChronoUnit.DAYS.between(baseStart, baseEnd) + 1).toInt()
        val baseByDay = StudyMath.secondsPerStudyDay(baselineSessions, dayStartHour)
        val curByDay = StudyMath.secondsPerStudyDay(currentSessions, dayStartHour)
        val baselineLevels = runningTotals((0 until bins).map { baseByDay[baseStart.plusDays(it.toLong())] ?: 0L })
        val nowIndex = ChronoUnit.DAYS.between(curStart, today).toInt().coerceIn(0, bins - 1)
        val todayLevels = runningTotals((0..nowIndex).map { curByDay[curStart.plusDays(it.toLong())] ?: 0L })
        return CompareChart(
            tab = tab,
            bins = bins,
            baselineLevels = baselineLevels,
            todayLevels = todayLevels,
            spanBins = nowIndex + 1f,
            nowIndex = nowIndex,
            diffSeconds = todayLevels.last() - baselineLevels[nowIndex],
            baselineStart = baseStart,
            baselineIsPrevious = viewedIsCurrent,
            axisStartHour = dayStartHour
        )
    }

    fun compute(
        tab: StatsTab,
        subjectId: Long?,
        anchor: LocalDate,
        today: LocalDate,
        dayStartHour: Int,
        firstDay: DayOfWeek,
        sessions: List<StudySession>,
        subjects: List<Subject>,
        goals: List<Goal>,
        locale: Locale,
        /** Sessions of the current period (today, this week, this month), for the "Up to" chart. */
        currentSessions: List<StudySession> = emptyList(),
        nowMs: Long = System.currentTimeMillis()
    ): StatsUiState {
        val zone = ZoneId.systemDefault()
        val (start, end) = periodOf(tab, anchor, firstDay)
        val (prevStart, prevEnd) = previousPeriod(tab, start, firstDay)

        val rangeStartMs = DateTimeUtils.studyDayRangeForDate(start, dayStartHour).first
        val rangeEndMs = DateTimeUtils.studyDayRangeForDate(end, dayStartHour).second

        val secondsByDay = StudyMath.secondsPerStudyDay(sessions, dayStartHour)
        val goalMinutesByWeekday = goals.associate { it.weekday to it.targetMinutes }
        fun goalSeconds(date: LocalDate): Long =
            (goalMinutesByWeekday[StudyMath.calendarWeekday(date)] ?: 240) * 60L

        val totalSeconds = sumDays(secondsByDay, start, end)
        val previousSeconds = sumDays(secondsByDay, prevStart, prevEnd)
        val elapsed = elapsedDays(start, end, today)

        // Sessions that touch the period, and what each subject got of it.
        val inPeriod = sessions.filter { it.endTime > rangeStartMs && it.startTime < rangeEndMs }
        val perSubject = HashMap<Long?, Long>()
        for (s in inPeriod) {
            val sec = DateTimeUtils.getSessionOverlapMillis(s, rangeStartMs, rangeEndMs) / 1000L
            if (sec > 0) perSubject[s.subjectId] = (perSubject[s.subjectId] ?: 0L) + sec
        }
        val subjectById = subjects.associateBy { it.id }
        val distributionTotal = perSubject.values.sum()
        val distribution = perSubject.map { (id, sec) ->
            SubjectDistributionItem(
                subject = id?.let { subjectById[it] },
                durationSeconds = sec,
                percentage = if (distributionTotal > 0) sec.toFloat() / distributionTotal.toFloat() else 0f
            )
        }.sortedByDescending { it.durationSeconds }

        // Bars
        val points = ArrayList<BarChartPoint>()
        val bestLabels = ArrayList<String>()
        when (tab) {
            StatsTab.DAY -> {
                val dayStartInstant = Instant.ofEpochMilli(rangeStartMs).atZone(zone)
                for (h in 0 until 24) {
                    val slotStart = dayStartInstant.plusHours(h.toLong())
                    val slotStartMs = slotStart.toInstant().toEpochMilli()
                    val slotEndMs = slotStart.plusHours(1).toInstant().toEpochMilli()
                    var sec = 0L
                    for (s in inPeriod) sec += DateTimeUtils.getSessionOverlapMillis(s, slotStartMs, slotEndMs) / 1000L
                    val hour = slotStart.hour
                    points.add(BarChartPoint(String.format(Locale.US, "%02d", hour), sec))
                    bestLabels.add(String.format(Locale.US, "%02d:00", hour))
                }
            }
            StatsTab.WEEK -> {
                var d = start
                while (!d.isAfter(end)) {
                    points.add(BarChartPoint(d.dayOfWeek.getDisplayName(TextStyle.SHORT, locale), secondsByDay[d] ?: 0L))
                    bestLabels.add(d.dayOfWeek.getDisplayName(TextStyle.SHORT, locale))
                    d = d.plusDays(1)
                }
            }
            StatsTab.MONTH -> {
                var d = start
                while (!d.isAfter(end)) {
                    points.add(BarChartPoint(d.dayOfMonth.toString(), secondsByDay[d] ?: 0L))
                    bestLabels.add("${d.dayOfMonth} ${d.month.getDisplayName(TextStyle.SHORT, locale)}")
                    d = d.plusDays(1)
                }
            }
            StatsTab.YEAR -> {
                for (m in 1..12) {
                    val monthStart = LocalDate.of(start.year, m, 1)
                    val monthEnd = monthStart.plusMonths(1).minusDays(1)
                    val name = monthStart.month.getDisplayName(TextStyle.SHORT, locale)
                    points.add(BarChartPoint(name, sumDays(secondsByDay, monthStart, monthEnd)))
                    bestLabels.add(name)
                }
            }
        }
        val bestSeconds = points.maxOfOrNull { it.seconds } ?: 0L
        val bestIndex = if (bestSeconds > 0) points.indexOfFirst { it.seconds == bestSeconds } else -1
        val markedPoints = points.mapIndexed { i, p -> p.copy(isBest = i == bestIndex) }

        // Days that reached their goal (only days that have started)
        var goalDays = 0
        var d = start
        while (!d.isAfter(end) && !d.isAfter(today)) {
            val g = goalSeconds(d)
            if (g > 0 && (secondsByDay[d] ?: 0L) >= g) goalDays++
            d = d.plusDays(1)
        }

        // Month heatmap for the month of the anchor
        val monthStart = anchor.withDayOfMonth(1)
        val heatmap = ArrayList<HeatmapDay>()
        for (i in 0 until monthStart.lengthOfMonth()) {
            val date = monthStart.plusDays(i.toLong())
            val sec = secondsByDay[date] ?: 0L
            heatmap.add(
                HeatmapDay(
                    dayNumber = date.dayOfMonth,
                    timestampMs = DateTimeUtils.studyDayRangeForDate(date, dayStartHour).first,
                    studySeconds = sec,
                    intensity = intensity(sec, goalSeconds(date))
                )
            )
        }
        val leadingBlanks = (monthStart.dayOfWeek.value - firstDay.value + 7) % 7

        return StatsUiState(
            selectedTab = tab,
            selectedSubjectId = subjectId,
            periodStart = start,
            periodEnd = end,
            periodStartMs = rangeStartMs,
            isCurrentPeriod = !today.isBefore(start) && !today.isAfter(end),
            totalSeconds = totalSeconds,
            previousPeriodSeconds = previousSeconds,
            dailyAverageSeconds = if (elapsed > 0) totalSeconds / elapsed else 0L,
            bestLabel = if (bestIndex >= 0) bestLabels[bestIndex] else null,
            bestSeconds = bestSeconds,
            totalSessionsCount = inPeriod.size,
            longestSessionSeconds = inPeriod.maxOfOrNull { it.durationSeconds } ?: 0L,
            goalAchievedDaysCount = goalDays,
            elapsedDays = elapsed.coerceAtLeast(1),
            totalInterruptions = inPeriod.sumOf { it.interruptions },
            subjects = subjects.filter { !it.isArchived },
            distribution = distribution,
            barChartPoints = markedPoints,
            heatmapMonthStartMs = DateTimeUtils.studyDayRangeForDate(monthStart, dayStartHour).first,
            heatmapLeadingBlanks = leadingBlanks,
            heatmapDays = heatmap,
            calendar = buildCalendar(tab, anchor, today, firstDay, secondsByDay, { d -> goalSeconds(d) }, locale),
            compare = buildCompareChart(tab, start, today, nowMs, dayStartHour, firstDay, sessions, currentSessions),
            firstDayOfWeek = firstDay
        )
    }
}

class StatsViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as StudyApplication
    private val studyRepo = app.studyRepository
    private val settingsRepo = app.settingsRepository

    private val _selectedTab = MutableStateFlow(StatsTab.WEEK)
    private val _selectedSubjectId = MutableStateFlow<Long?>(null)

    /** null means "today", which follows the study day automatically. */
    private val _anchor = MutableStateFlow<LocalDate?>(null)

    private data class Query(
        val tab: StatsTab,
        val subjectId: Long?,
        val anchor: LocalDate,
        val today: LocalDate,
        val dayStartHour: Int,
        val firstDay: DayOfWeek,
        val language: String
    )

    private val queryFlow = combine(
        _selectedTab,
        _selectedSubjectId,
        _anchor,
        settingsRepo.settings.map { Triple(it.dayStartHour, it.firstDayOfWeek, it.language) }.distinctUntilChanged()
    ) { tab, subjectId, anchor, s ->
        val today = DateTimeUtils.studyDateOf(System.currentTimeMillis(), s.first)
        Query(tab, subjectId, anchor ?: today, today, s.first, StatsEngine.dayOfWeekFromCalendar(s.second), s.third)
    }

    /** The anchor the screen currently shows, for the previous / next buttons. */
    @Volatile
    private var shownAnchor: LocalDate = LocalDate.now()

    @OptIn(ExperimentalCoroutinesApi::class)
    val uiState: StateFlow<StatsUiState> = queryFlow.flatMapLatest { q ->
        shownAnchor = q.anchor
        val (start, end) = StatsEngine.periodOf(q.tab, q.anchor, q.firstDay)
        val (prevStart, _) = StatsEngine.previousPeriod(q.tab, start, q.firstDay)
        val monthStart = q.anchor.withDayOfMonth(1)
        val monthEnd = monthStart.plusMonths(1).minusDays(1)

        // One query covers the period, the period before it, the heatmap month and the calendar of the tab.
        val (calFrom, calTo) = StatsEngine.calendarRange(q.tab, q.anchor, q.firstDay)
        val from = listOf(prevStart, monthStart, start, calFrom).minOf { it }
        val to = listOf(end, monthEnd, calTo).maxOf { it }
        val fromMs = DateTimeUtils.studyDayRangeForDate(from, q.dayStartHour).first
        val toMs = DateTimeUtils.studyDayRangeForDate(to, q.dayStartHour).second

        val sessionFlow = if (q.subjectId != null) {
            studyRepo.getSessionsForSubjectInRange(q.subjectId, fromMs, toMs)
        } else {
            studyRepo.getSessionsInRange(fromMs, toMs)
        }

        // The current period (today, this week, this month) can be far from the one being viewed, so it has its own query.
        val currentFlow = if (q.tab == StatsTab.YEAR) {
            flowOf(emptyList<StudySession>())
        } else {
            val (cs, ce) = StatsEngine.periodOf(q.tab, q.today, q.firstDay)
            val cFromMs = DateTimeUtils.studyDayRangeForDate(cs, q.dayStartHour).first
            val cToMs = DateTimeUtils.studyDayRangeForDate(ce, q.dayStartHour).second
            if (q.subjectId != null) {
                studyRepo.getSessionsForSubjectInRange(q.subjectId, cFromMs, cToMs)
            } else {
                studyRepo.getSessionsInRange(cFromMs, cToMs)
            }
        }

        combine(sessionFlow, currentFlow, studyRepo.allSubjects, studyRepo.allGoals) { sessions, currentSessions, subjects, goals ->
            StatsEngine.compute(
                tab = q.tab,
                subjectId = q.subjectId,
                anchor = q.anchor,
                today = q.today,
                dayStartHour = q.dayStartHour,
                firstDay = q.firstDay,
                sessions = sessions,
                subjects = subjects,
                goals = goals,
                locale = Locale.getDefault(),
                currentSessions = currentSessions,
                nowMs = System.currentTimeMillis()
            )
        }
    }.flowOn(Dispatchers.Default).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = StatsUiState()
    )

    fun selectTab(tab: StatsTab) {
        _selectedTab.value = tab
    }

    fun selectSubjectFilter(subjectId: Long?) {
        _selectedSubjectId.value = subjectId
    }

    fun previousPeriod() {
        _anchor.value = StatsEngine.shift(_selectedTab.value, shownAnchor, -1)
    }

    fun nextPeriod() {
        _anchor.value = StatsEngine.shift(_selectedTab.value, shownAnchor, 1)
    }

    /** One page of the calendar: a month on the Day tab, a quarter on the Week tab, a year on the Month tab. */
    fun shiftCalendar(direction: Int) {
        val months = when (_selectedTab.value) {
            StatsTab.DAY, StatsTab.YEAR -> 1L
            StatsTab.WEEK -> 3L
            StatsTab.MONTH -> 12L
        }
        _anchor.value = shownAnchor.plusMonths(months * direction)
    }

    fun goToToday() {
        _anchor.value = null
    }

    fun setAnchorDate(date: LocalDate) {
        _anchor.value = date
    }
}
