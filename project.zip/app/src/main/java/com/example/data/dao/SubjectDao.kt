package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Subject
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY `order` ASC, id ASC")
    fun getAllSubjectsFlow(): Flow<List<Subject>>

    @Query("SELECT * FROM subjects WHERE isArchived = 0 ORDER BY `order` ASC, id ASC")
    fun getActiveSubjectsFlow(): Flow<List<Subject>>

    @Query("SELECT * FROM subjects ORDER BY `order` ASC, id ASC")
    suspend fun getAllSubjectsList(): List<Subject>

    @Query("SELECT * FROM subjects WHERE isArchived = 0 ORDER BY `order` ASC, id ASC")
    suspend fun getActiveSubjectsList(): List<Subject>

    @Query("SELECT * FROM subjects WHERE id = :id LIMIT 1")
    suspend fun getSubjectById(id: Long): Subject?

    @Query("SELECT * FROM subjects WHERE id = :id LIMIT 1")
    fun getSubjectByIdFlow(id: Long): Flow<Subject?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(subject: Subject): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(subjects: List<Subject>)

    @Update
    suspend fun update(subject: Subject)

    @Query("UPDATE subjects SET isArchived = 1 WHERE id = :id")
    suspend fun archiveSubject(id: Long)

    @Query("UPDATE subjects SET isArchived = 0 WHERE id = :id")
    suspend fun unarchiveSubject(id: Long)

    @Query("SELECT * FROM subjects WHERE isArchived = 1 ORDER BY `order` ASC, id ASC")
    fun getArchivedSubjectsFlow(): Flow<List<Subject>>

    @Delete
    suspend fun delete(subject: Subject)

    @Query("DELETE FROM subjects WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM subjects")
    suspend fun deleteAll()
}
