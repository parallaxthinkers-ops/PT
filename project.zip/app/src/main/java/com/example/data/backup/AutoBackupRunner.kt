package com.example.data.backup

import android.net.Uri
import com.example.StudyApplication
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Runs the scheduled backup. One run at a time (the alarm and the app start can both ask for it).
 * Every attempt records its result, so a broken folder shows up in Settings instead of failing silently.
 */
object AutoBackupRunner {
    private val lock = Mutex()

    /** After a failure the app start does not retry more often than this. */
    private const val RETRY_GAP_MS = 60L * 60L * 1000L

    sealed class Outcome {
        object Skipped : Outcome()
        data class Saved(val fileName: String) : Outcome()
        data class Failed(val reason: String) : Outcome()
    }

    /** Runs only when enabled, a folder is set and a backup is due. [force] skips the due check ("Back up now"). */
    suspend fun run(app: StudyApplication, force: Boolean): Outcome = lock.withLock {
        val repo = app.settingsRepository
        val s = repo.settings.first()
        if (!force) {
            if (!s.autoBackupEnabled || s.autoBackupFolderUri.isBlank()) return@withLock Outcome.Skipped
            val now = System.currentTimeMillis()
            if (!AutoBackupPlan.isDue(s.autoBackupLastSuccess, now, s.autoBackupIntervalDays)) return@withLock Outcome.Skipped
            // A failed attempt is not repeated on every app start.
            if (s.autoBackupLastError.isNotEmpty() && now - s.autoBackupLastAttempt in 0 until RETRY_GAP_MS) return@withLock Outcome.Skipped
        }
        if (s.autoBackupFolderUri.isBlank()) return@withLock Outcome.Failed("No folder chosen")

        val result = BackupManager.exportToTree(
            app, Uri.parse(s.autoBackupFolderUri), s.autoBackupKeep, app.studyRepository, repo
        )
        if (result.isSuccess) {
            repo.recordAutoBackupResult(true, "")
            Outcome.Saved(result.getOrDefault(""))
        } else {
            val reason = result.exceptionOrNull()?.message ?: result.exceptionOrNull()?.javaClass?.simpleName ?: "Unknown error"
            repo.recordAutoBackupResult(false, reason)
            Outcome.Failed(reason)
        }
    }
}
