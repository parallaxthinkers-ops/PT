package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LayoutMath

/**
 * The glass look in one place, so the Timer, the toggles, the buttons and the pop-ups all match the glass cards.
 * Colours are worked out once per theme. Everything is a static shape (a translucent fill, a thin edge that is bright
 * at the top-left and fades, a faint highlight along the top): no blur and no animation, so it costs next to nothing.
 *
 * It works in every layout, not only Glassmorphism, because it is built from the theme's own colours.
 */
@Immutable
class GlassLook(
    /** Big surfaces: the timer disc, buttons, pop-ups. */
    val fill: Color,
    /** Small controls that sit inside something else: the toggle track and the preset chips. */
    val control: Color,
    /** The thin edge, bright at the top-left, faint at the bottom-right. */
    val edge: Brush,
    /** The faint highlight over the top of a surface. */
    val sheen: Color,
    /** A soft translucent line, for example the empty part of the timer ring. */
    val line: Color
)

private fun buildGlassLook(scheme: ColorScheme, dark: Boolean): GlassLook {
    val edgeStart = if (dark) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.95f)
    val edgeEnd = if (dark) Color.White.copy(alpha = 0.06f) else scheme.onSurface.copy(alpha = 0.10f)
    return GlassLook(
        fill = scheme.surface.copy(alpha = LayoutMath.GLASS_ALPHA),
        control = scheme.surfaceVariant.copy(alpha = 0.60f),
        edge = Brush.linearGradient(listOf(edgeStart, edgeEnd)),
        sheen = if (dark) Color.White.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.22f),
        line = scheme.onSurface.copy(alpha = if (dark) 0.10f else 0.08f)
    )
}

@Composable
fun rememberGlassLook(): GlassLook {
    val scheme = MaterialTheme.colorScheme
    val dark = scheme.background.luminance() < 0.5f
    return remember(scheme, dark) { buildGlassLook(scheme, dark) }
}

/** The edge of an accent-tinted piece of glass: the accent, bright at the top-left and fading. */
fun glassAccentEdge(accent: Color): Brush =
    Brush.linearGradient(listOf(accent.copy(alpha = 0.70f), accent.copy(alpha = 0.22f)))

/**
 * Draws the highlight and the thin edge ON TOP of what the modifier wraps. Put it first (outermost), then the
 * clip and the fill inside it, so the edge is not cut by the clip.
 */
fun Modifier.glassEdge(shape: Shape, look: GlassLook, edge: Brush = look.edge, width: Dp = 1.dp): Modifier =
    this.drawWithCache {
        // The shape as a Path, built once per size. (drawOutline is not used: it is not resolved by the compiler here.)
        val path = when (val outline = shape.createOutline(size, layoutDirection, this)) {
            is Outline.Generic -> outline.path
            is Outline.Rounded -> Path().apply { addRoundRect(outline.roundRect) }
            is Outline.Rectangle -> Path().apply { addRect(outline.rect) }
        }
        val sheen = Brush.verticalGradient(listOf(look.sheen, Color.Transparent), startY = 0f, endY = size.height * 0.6f)
        val stroke = Stroke(width = width.toPx())
        onDrawWithContent {
            drawContent()
            drawPath(path, sheen)
            drawPath(path, edge, style = stroke)
        }
    }

/**
 * A piece of glass: fill, optional accent tint, highlight and edge. [accent] null = plain glass, otherwise the glass is
 * tinted with the accent and gets an accent edge (used for the selected state and for the Start button).
 */
fun Modifier.glassPanel(
    shape: Shape,
    look: GlassLook,
    fill: Color = look.fill,
    accent: Color? = null,
    tint: Float = 0.20f
): Modifier {
    val base = this
        .glassEdge(shape, look, edge = if (accent != null) glassAccentEdge(accent) else look.edge)
        .clip(shape)
        .background(fill)
    return if (accent != null) base.background(accent.copy(alpha = tint)) else base
}

/**
 * A glass button. The text and icon keep the normal text colour (always readable on the glass); the accent shows in the
 * tint and in the edge. [accent] null = plain glass.
 */
@Composable
fun GlassButton(
    onClick: () -> Unit,
    shape: Shape,
    modifier: Modifier = Modifier,
    accent: Color? = null,
    contentColor: Color = MaterialTheme.colorScheme.onSurface,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit
) {
    val look = rememberGlassLook()
    CompositionLocalProvider(LocalContentColor provides contentColor) {
        Row(
            modifier = modifier
                .alpha(if (enabled) 1f else 0.5f)
                .glassPanel(shape, look, accent = accent)
                .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
                .defaultMinSize(minHeight = 40.dp)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

/**
 * The one chip used for filters and presets on every screen, so they all look and behave the same. The chosen chip is a
 * brighter piece of glass tinted with the accent and edged in the accent; the others are plain glass. The corner follows
 * the "Corners" setting (the same token as the toggle and the preset chips).
 */
@Composable
fun GlassChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    dotColor: Color? = null
) {
    val look = rememberGlassLook()
    val shape = MaterialTheme.shapes.medium
    val panel = if (selected) {
        Modifier.glassPanel(shape, look, fill = look.fill, accent = MaterialTheme.colorScheme.primary, tint = 0.22f)
    } else {
        Modifier.glassPanel(shape, look, fill = look.control)
    }
    Row(
        modifier = modifier
            .then(panel)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (dotColor != null) {
            ColorDot(color = dotColor, size = 8.dp)
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1
        )
    }
}

/** A thin glass progress bar: a soft translucent track and a softened fill. No end dot, no animation. */
@Composable
fun GlassProgressBar(progress: Float, color: Color, modifier: Modifier = Modifier, barHeight: Dp = 6.dp) {
    val look = rememberGlassLook()
    val p = progress.coerceIn(0f, 1f)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(barHeight)
            .clip(CircleShape)
            .background(look.line)
    ) {
        if (p > 0.005f) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(p)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.80f))
            )
        }
    }
}

/**
 * Lets a sideways-scrolling row run to the screen edge even when the screen has side padding, so a chip is not cut off
 * at the page margin. Use it as: fillMaxWidth().bleedHorizontal(pad).horizontalScroll(state).padding(horizontal = pad).
 * [amount] must equal the side padding of the screen.
 */
fun Modifier.bleedHorizontal(amount: Dp): Modifier = this.layout { measurable, constraints ->
    val extra = amount.roundToPx()
    if (constraints.hasBoundedWidth) {
        val wideWidth = constraints.maxWidth + 2 * extra
        val placeable = measurable.measure(constraints.copy(minWidth = wideWidth, maxWidth = wideWidth))
        layout(constraints.maxWidth, placeable.height) { placeable.place(-extra, 0) }
    } else {
        val placeable = measurable.measure(constraints)
        layout(placeable.width, placeable.height) { placeable.place(0, 0) }
    }
}
