package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LocalThemeLook

/**
 * A ring that fills as [progress] goes from 0 to 1. Flat colour on purpose (minimal style): a sweep
 * gradient shows a visible seam where the ring closes and costs more to draw every second.
 */
@Composable
fun CircularProgressTimer(
    progress: Float,
    primaryColor: Color,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    strokeWidth: Dp = LocalThemeLook.current.ringStroke,
    modifier: Modifier = Modifier,
    /** When given, the ring is drawn as glass: a translucent disc inside, a soft track and thin fading edges on both sides of the band. */
    glass: GlassLook? = null,
    content: @Composable () -> Unit
) {
    // Animated state is read inside the draw block, so a frame of animation redraws the ring only
    // and does not recompose the content on top of it.
    val animatedProgress = animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 600),
        label = "progress_anim"
    )

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokePx = strokeWidth.toPx()
            val diameter = minOf(size.width, size.height) - strokePx
            val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
            val arcSize = Size(diameter, diameter)
            val stroke = Stroke(width = strokePx, cap = StrokeCap.Round)

            if (glass != null) {
                val centre = Offset(size.width / 2f, size.height / 2f)
                val outerR = diameter / 2f + strokePx / 2f
                val innerR = diameter / 2f - strokePx / 2f
                val hair = Stroke(width = 1.dp.toPx())
                // The glass disc inside the ring, with the same faint highlight along the top as the cards.
                drawCircle(color = glass.fill, radius = innerR, center = centre)
                drawCircle(
                    brush = Brush.verticalGradient(
                        listOf(glass.sheen, Color.Transparent),
                        startY = centre.y - innerR,
                        endY = centre.y + innerR * 0.2f
                    ),
                    radius = innerR,
                    center = centre
                )
                // The empty part of the ring is a soft translucent band, edged on both sides like a glass tube.
                drawCircle(color = glass.line, radius = diameter / 2f, center = centre, style = Stroke(width = strokePx))
                drawCircle(brush = glass.edge, radius = outerR, center = centre, style = hair)
                drawCircle(brush = glass.edge, radius = innerR, center = centre, style = hair)
            }

            if (glass == null) {
                drawArc(
                    color = trackColor,
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = stroke
                )
            }

            val value = animatedProgress.value
            if (value > 0f) {
                drawArc(
                    color = primaryColor,
                    startAngle = -90f,
                    sweepAngle = 360f * value,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = stroke
                )
            }
        }
        content()
    }
}
