package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.AppDatabase
import com.example.data.model.DDay
import com.example.data.model.Goal
import com.example.data.model.StudySession
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.TaskCompletion
import kotlinx.coroutines.flow.Flow

class StudyRepository(private val database: AppDatabase) {
    private val subjectDao = database.subjectDao()
    private val sessionDao = database.studySessionDao()
    private val goalDao = database.goalDao()
    private val dDayDao = database.dDayDao()
    private val taskDao = database.studyTaskDao()
    private val taskCompletionDao = database.taskCompletionDao()

    // Subjects
    val allSubjects: Flow<List<Subject>> = subjectDao.getAllSubjectsFlow()
    val activeSubjects: Flow<List<Subject>> = subjectDao.getActiveSubjectsFlow()

    suspend fun getSubjectById(id: Long): Subject? = subjectDao.getSubjectById(id)
    suspend fun insertSubject(subject: Subject): Long = subjectDao.insert(subject)
    suspend fun updateSubject(subject: Subject) = subjectDao.update(subject)

    val archivedSubjects: Flow<List<Subject>> = subjectDao.getArchivedSubjectsFlow()

    suspend fun archiveSubject(id: Long) {
        subjectDao.archiveSubject(id)
    }

    suspend fun unarchiveSubject(id: Long) {
        subjectDao.unarchiveSubject(id)
    }

    suspend fun sessionCountForSubject(id: Long): Int = sessionDao.countForSubject(id)

    /** Saves a new manual order. [orderedIds] is the full desired order of the ACTIVE subjects. */
    suspend fun reorderSubjects(orderedIds: List<Long>) {
        database.withTransaction {
            orderedIds.forEachIndexed { index, id ->
                val subject = subjectDao.getSubjectById(id)
                if (subject != null && subject.order != index) {
                    subjectDao.update(subject.copy(order = index))
                }
            }
        }
    }

    suspend fun hardDeleteSubject(id: Long) {
        database.withTransaction {
            sessionDao.deleteBySubjectId(id)
            taskDao.unlinkSubject(id)
            subjectDao.deleteById(id)
        }
    }

    suspend fun deleteSubject(subject: Subject, deleteHistory: Boolean) {
        if (deleteHistory) {
            hardDeleteSubject(subject.id)
        } else {
            archiveSubject(subject.id)
        }
    }

    // Sessions
    val allSessions: Flow<List<StudySession>> = sessionDao.getAllSessionsFlow()

    fun getSessionsInRange(startMs: Long, endMs: Long): Flow<List<StudySession>> =
        sessionDao.getSessionsInRangeFlow(startMs, endMs)

    fun getSessionsForSubjectInRange(subjectId: Long, startMs: Long, endMs: Long): Flow<List<StudySession>> =
        sessionDao.getSessionsForSubjectInRangeFlow(subjectId, startMs, endMs)

    suspend fun getSessionsInRangeList(startMs: Long, endMs: Long): List<StudySession> =
        sessionDao.getSessionsInRangeList(startMs, endMs)

    suspend fun getSessionsForSubjectInRangeList(subjectId: Long, startMs: Long, endMs: Long): List<StudySession> =
        sessionDao.getSessionsForSubjectInRangeList(subjectId, startMs, endMs)

    suspend fun getSessionById(id: Long): StudySession? = sessionDao.getSessionById(id)
    suspend fun insertSession(session: StudySession): Long = sessionDao.insert(session)
    suspend fun updateSession(session: StudySession) = sessionDao.update(session)
    suspend fun deleteSession(session: StudySession) = sessionDao.delete(session)
    suspend fun deleteSessionById(id: Long) = sessionDao.deleteById(id)

    // Goals
    val allGoals: Flow<List<Goal>> = goalDao.getAllGoalsFlow()
    fun getGoalForWeekday(weekday: Int): Flow<Goal?> = goalDao.getGoalForWeekdayFlow(weekday)
    suspend fun getGoalForWeekdayDirect(weekday: Int): Goal? = goalDao.getGoalForWeekday(weekday)
    suspend fun setGoal(goal: Goal) = goalDao.insertOrUpdate(goal)

    suspend fun setGoalForWeekday(weekday: Int, targetMinutes: Int) {
        goalDao.insertOrUpdate(Goal(weekday = weekday, targetMinutes = targetMinutes))
    }

    suspend fun setUniformGoal(targetMinutes: Int) {
        val goals = (1..7).map { Goal(weekday = it, targetMinutes = targetMinutes) }
        goalDao.insertAll(goals)
    }

    // D-Days
    val allDDays: Flow<List<DDay>> = dDayDao.getAllDDaysFlow()
    val pinnedDDay: Flow<DDay?> = dDayDao.getPinnedDDayFlow()

    suspend fun insertDDay(dDay: DDay): Long {
        if (dDay.isPinned) {
            dDayDao.unpinAll()
        }
        return dDayDao.insert(dDay)
    }

    suspend fun updateDDay(dDay: DDay) {
        if (dDay.isPinned) {
            dDayDao.unpinAll()
        }
        dDayDao.update(dDay)
    }

    suspend fun deleteDDay(dDay: DDay) = dDayDao.delete(dDay)

    suspend fun pinDDay(id: Long) {
        dDayDao.unpinAll()
        dDayDao.pinDDay(id)
    }

    // Tasks
    val allTasks: Flow<List<StudyTask>> = taskDao.getAllTasksFlow()
    fun getTasksForDate(date: String): Flow<List<StudyTask>> = taskDao.getTasksForDateFlow(date)
    suspend fun insertTask(task: StudyTask): Long = taskDao.insert(task)
    suspend fun updateTask(task: StudyTask) = taskDao.update(task)

    suspend fun deleteTask(task: StudyTask) {
        taskCompletionDao.deleteForTask(task.id)
        taskDao.delete(task)
    }

    suspend fun updateTasksOrder(tasks: List<StudyTask>) {
        tasks.forEachIndexed { index, task ->
            taskDao.update(task.copy(order = index))
        }
    }

    // Task Completions per date
    fun getCompletionsForDate(date: String): Flow<List<TaskCompletion>> =
        taskCompletionDao.getCompletionsForDateFlow(date)

    suspend fun toggleTaskCompletion(taskId: Long, date: String, isCompleted: Boolean) {
        if (isCompleted) {
            taskCompletionDao.markCompleted(TaskCompletion(taskId = taskId, date = date))
        } else {
            taskCompletionDao.unmarkCompleted(taskId = taskId, date = date)
        }
    }

    // Clear and restore for backup
    suspend fun clearAllData() {
        database.withTransaction {
            taskCompletionDao.deleteAll()
            sessionDao.deleteAll()
            taskDao.deleteAll()
            subjectDao.deleteAll()
            dDayDao.deleteAll()
            goalDao.deleteAll()
        }
    }

    suspend fun restoreAllData(
        subjects: List<Subject>,
        sessions: List<StudySession>,
        goals: List<Goal>,
        dDays: List<DDay>,
        tasks: List<StudyTask>,
        completions: List<TaskCompletion> = emptyList()
    ) {
        database.withTransaction {
            taskCompletionDao.deleteAll()
            sessionDao.deleteAll()
            taskDao.deleteAll()
            subjectDao.deleteAll()
            dDayDao.deleteAll()
            goalDao.deleteAll()

            val subjectIds = subjects.map { it.id }.toSet()
            val cleanSessions = sessions.map {
                if (it.subjectId != null && it.subjectId !in subjectIds) it.copy(subjectId = null) else it
            }
            val cleanTasks = tasks.map {
                if (it.subjectId != null && it.subjectId !in subjectIds) it.copy(subjectId = null) else it
            }
            val taskIds = cleanTasks.map { it.id }.toSet()
            val cleanCompletions = completions.filter { it.taskId in taskIds }

            subjectDao.insertAll(subjects)
            sessionDao.insertAll(cleanSessions)
            goalDao.insertAll(goals)
            dDayDao.insertAll(dDays)
            taskDao.insertAll(cleanTasks)
            if (cleanCompletions.isNotEmpty()) {
                taskCompletionDao.insertAll(cleanCompletions)
            }
        }
    }

    /** Wipes everything and restores only the default weekday goals (4 h). No sample subjects or D-Days. */
    suspend fun resetAllData() {
        database.withTransaction {
            taskCompletionDao.deleteAll()
            sessionDao.deleteAll()
            taskDao.deleteAll()
            subjectDao.deleteAll()
            dDayDao.deleteAll()
            goalDao.deleteAll()
            goalDao.insertAll((1..7).map { Goal(weekday = it, targetMinutes = 240) })
        }
    }

    suspend fun getAllDataForBackup(): BackupPayload {
        return BackupPayload(
            subjects = subjectDao.getAllSubjectsList(),
            sessions = sessionDao.getAllSessionsList(),
            goals = goalDao.getAllGoalsList(),
            dDays = dDayDao.getAllDDaysList(),
            tasks = taskDao.getAllTasksList(),
            taskCompletions = taskCompletionDao.getAllCompletionsList()
        )
    }
}

data class BackupPayload(
    val subjects: List<Subject>,
    val sessions: List<StudySession>,
    val goals: List<Goal>,
    val dDays: List<DDay>,
    val tasks: List<StudyTask>,
    val taskCompletions: List<TaskCompletion> = emptyList()
)
