package com.example.ui.screens.stats.share

import com.example.ui.screens.stats.BarChartPoint
import com.example.ui.screens.stats.CalendarGrid
import com.example.ui.screens.stats.CompareChart
import com.example.ui.screens.stats.HeatmapDay
import com.example.ui.screens.stats.StatsEngine
import com.example.ui.screens.stats.StatsTab
import com.example.ui.screens.stats.SubjectDistributionItem
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.max

/*
 * The "Download SS" picture. This file is the pure part: what the picture says (the model), the words around the numbers
 * (ShareFormat) and where everything sits (ShareLayout). No Android classes, so it is unit tested on the JVM.
 * The drawing itself is in ShareCardRenderer.
 */

/** The colours of the picture, taken from the theme the person has chosen. ARGB Longs. */
data class ShareColors(
    val bg: Long,
    val surface: Long,
    val variant: Long,
    val onSurface: Long,
    val onVariant: Long,
    val accent: Long,
    val accent2: Long,
    val hairline: Long,
    val success: Long,
    val warning: Long,
    val danger: Long,
    val dark: Boolean
)

data class ShareSubjectRow(val name: String, val color: Long, val seconds: Long, val percent: Int)

data class ShareStat(val label: String, val value: String)

data class ShareCalendarBlock(
    val title: String,
    val totalText: String,
    val grid: CalendarGrid,
    /** Seven weekday names for the Day calendar, empty on Week and Month. */
    val weekdayHeaders: List<String>,
    val selectedDate: LocalDate
)

data class ShareHeatBlock(
    val title: String,
    val subtitle: String,
    val leadingBlanks: Int,
    val days: List<HeatmapDay>,
    val weekdayHeaders: List<String>
)

data class ShareCompareBlock(
    val title: String,
    val upTo: String,
    val diffText: String,
    val todayLabel: String,
    val recordLabel: String,
    val chart: CompareChart,
    val axisLabels: List<String>
)

data class ShareBarsBlock(
    val title: String,
    val maxText: String,
    val points: List<BarChartPoint>,
    /** Every n-th bar gets a label under it. */
    val labelStep: Int
)

data class ShareSubjectsBlock(
    val title: String,
    val emptyText: String,
    val rows: List<ShareSubjectRow>,
    val totalText: String,
    val totalShort: String
)

/** Everything the picture shows, already in words and short numbers (and in the app language). */
data class ShareModel(
    val tab: StatsTab,
    val colors: ShareColors,
    val appName: String,
    val tabLabel: String,
    val periodTitle: String,
    val totalLabel: String,
    val totalText: String,
    val badgeText: String,
    /** 1 = up on the previous period, -1 = down, 0 = the same. */
    val badgeKind: Int,
    val stats: List<ShareStat>,
    /** Day, Week and Month tabs. */
    val calendar: ShareCalendarBlock?,
    /** Year tab: the month heatmap. */
    val heat: ShareHeatBlock?,
    val compare: ShareCompareBlock?,
    val bars: ShareBarsBlock?,
    val subjects: ShareSubjectsBlock,
    val lessLabel: String,
    val moreLabel: String,
    val footer: String
)

/** Small, pure helpers for the words and numbers of the picture. They mirror what the Stats screen shows. */
object ShareFormat {

    fun weekdayHeaders(firstDay: DayOfWeek, style: TextStyle, locale: Locale): List<String> =
        (0 until 7).map { DayOfWeek.of(((firstDay.value - 1 + it) % 7) + 1).getDisplayName(style, locale) }

    /** The weekday names above the Day calendar, in the order of its columns (same rule as the calendar on screen). */
    fun dayCalendarHeaders(grid: CalendarGrid, locale: Locale): List<String> =
        (0 until 7).map { offset ->
            DayOfWeek.of(((grid.titleStart.dayOfWeek.value - 1 - grid.leadingBlanks + offset + 14) % 7) + 1)
                .getDisplayName(TextStyle.SHORT, locale)
        }

    /** "+1:05:00", "−0:30:00" (a real minus sign) or "0:00:00". */
    fun signedDiff(diffSeconds: Long): String {
        val sign = if (diffSeconds > 0) "+" else if (diffSeconds < 0) "−" else ""
        return sign + StatsEngine.clockSeconds(if (diffSeconds < 0) -diffSeconds else diffSeconds)
    }

    /** The point the "Up to ..." heading names: a weekday, an hour, or a date of the month. */
    fun compareNowText(chart: CompareChart, firstDay: DayOfWeek, locale: Locale): String = when (chart.tab) {
        StatsTab.WEEK -> DayOfWeek.of(((firstDay.value - 1 + chart.nowIndex) % 7) + 1).getDisplayName(TextStyle.FULL, locale)
        StatsTab.DAY -> "${(chart.axisStartHour + chart.nowIndex) % 24}:00"
        else -> (chart.nowIndex + 1).toString()
    }

    /** m/d for Day and Week, the month name for Month. */
    fun compareRecordLabel(chart: CompareChart, locale: Locale): String = when (chart.tab) {
        StatsTab.MONTH -> chart.baselineStart.month.getDisplayName(TextStyle.SHORT, locale)
        else -> "${chart.baselineStart.monthValue}/${chart.baselineStart.dayOfMonth}"
    }

    /** The labels under the "Up to" chart: seven weekdays, three hours, or 1 / middle / last. */
    fun compareAxisLabels(chart: CompareChart, firstDay: DayOfWeek, locale: Locale): List<String> = when (chart.tab) {
        StatsTab.WEEK -> weekdayHeaders(firstDay, TextStyle.SHORT, locale)
        StatsTab.DAY -> {
            val start = chart.axisStartHour
            listOf("$start:00", "${(start + 12) % 24}:00", "$start:00")
        }
        else -> listOf("1", (chart.bins / 2).toString(), chart.bins.toString())
    }

    /**
     * The rows next to the donut: at most [maxRows], biggest first. When there are more subjects the smallest ones are
     * folded into one "Others" row, so the picture never has a list that runs off the card.
     */
    fun subjectRows(
        items: List<SubjectDistributionItem>,
        nameOf: (SubjectDistributionItem) -> String,
        colorOf: (SubjectDistributionItem) -> Long,
        othersName: String,
        othersColor: Long = 0xFF94A3B8L,
        maxRows: Int = 5
    ): List<ShareSubjectRow> {
        val sorted = items.filter { it.durationSeconds > 0L }.sortedByDescending { it.durationSeconds }
        fun row(i: SubjectDistributionItem) = ShareSubjectRow(nameOf(i), colorOf(i), i.durationSeconds, (i.percentage * 100f).toInt())
        if (sorted.size <= maxRows) return sorted.map { row(it) }
        val head = sorted.take(maxRows - 1)
        val rest = sorted.drop(maxRows - 1)
        val restPercent = Math.round(rest.sumOf { it.percentage.toDouble() * 100.0 }).toInt()
        return head.map { row(it) } + ShareSubjectRow(othersName, othersColor, rest.sumOf { it.durationSeconds }, restPercent)
    }

    fun fileName(now: LocalDateTime): String =
        "ParallaxTracker_Stats_" + now.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss", Locale.US)) + ".png"
}

enum class ShareBlockKind { BRAND, HERO, CALENDAR, HEAT, COMPARE, BARS, SUBJECTS, FOOTER }

data class ShareBlockBox(val kind: ShareBlockKind, val top: Int, val height: Int)

data class ShareLayoutResult(val width: Int, val height: Int, val blocks: List<ShareBlockBox>) {
    fun box(kind: ShareBlockKind): ShareBlockBox? = blocks.firstOrNull { it.kind == kind }
}

/** What decides the picture's height: which blocks exist and how many rows the calendar and the subject list have. */
data class ShareLayoutInput(
    val calendarTab: StatsTab?,
    val calendarColumns: Int,
    /** Leading blanks plus cells. */
    val calendarSlots: Int,
    /** Leading blanks plus days of the Year-tab heatmap; 0 = no heatmap. */
    val heatSlots: Int,
    val hasCompare: Boolean,
    val hasBars: Boolean,
    val subjectRows: Int
)

fun ShareModel.layoutInput(): ShareLayoutInput = ShareLayoutInput(
    calendarTab = calendar?.grid?.tab,
    calendarColumns = calendar?.grid?.columns ?: 0,
    calendarSlots = calendar?.let { it.grid.leadingBlanks + it.grid.cells.size } ?: 0,
    heatSlots = heat?.let { it.leadingBlanks + it.days.size } ?: 0,
    hasCompare = compare != null,
    hasBars = bars != null,
    subjectRows = subjects.rows.size
)

/**
 * Where everything sits, in pixels. The picture is a phone-friendly column: 1080 wide, as tall as its blocks need and never
 * shorter than 1920 (when it would be shorter the spare space is spread evenly between the blocks).
 * Portrait on purpose: at 1:1 on a phone the text stays readable, which a wide landscape picture would not.
 */
object ShareLayout {
    const val WIDTH = 1080
    const val MIN_HEIGHT = 1920
    const val MARGIN = 56
    const val GAP = 20
    const val TOP = 64
    const val BOTTOM = 40

    const val BRAND_H = 88
    const val HERO_H = 480
    const val COMPARE_H = 330
    const val BARS_H = 330
    const val FOOTER_H = 56

    const val CARD_TITLE_H = 76
    const val CARD_PAD = 28
    const val LEGEND_H = 56
    const val WEEKDAY_ROW_H = 44
    const val ROW_GAP = 8
    const val HEAT_CELL_H = 54
    const val DONUT = 260
    const val SUBJECT_ROW_H = 52

    fun rowsOf(slots: Int, columns: Int): Int = if (slots <= 0 || columns <= 0) 0 else (slots + columns - 1) / columns

    fun calendarCellHeight(tab: StatsTab): Int = when (tab) {
        StatsTab.DAY -> 60
        StatsTab.WEEK -> 76
        else -> 84
    }

    fun calendarHeight(tab: StatsTab, columns: Int, slots: Int): Int {
        val header = if (tab == StatsTab.DAY) WEEKDAY_ROW_H else 0
        return CARD_TITLE_H + header + rowsOf(slots, columns) * (calendarCellHeight(tab) + ROW_GAP) + LEGEND_H + CARD_PAD
    }

    fun heatHeight(slots: Int): Int =
        CARD_TITLE_H + WEEKDAY_ROW_H + rowsOf(slots, 7) * (HEAT_CELL_H + ROW_GAP) + LEGEND_H + CARD_PAD

    fun subjectsHeight(rowCount: Int): Int =
        if (rowCount <= 0) CARD_TITLE_H + 120 + CARD_PAD else CARD_TITLE_H + max(DONUT, rowCount * SUBJECT_ROW_H) + CARD_PAD

    fun compute(input: ShareLayoutInput): ShareLayoutResult {
        val items = ArrayList<Pair<ShareBlockKind, Int>>()
        items.add(ShareBlockKind.BRAND to BRAND_H)
        items.add(ShareBlockKind.HERO to HERO_H)
        val calendarTab = input.calendarTab
        if (calendarTab != null) {
            items.add(ShareBlockKind.CALENDAR to calendarHeight(calendarTab, input.calendarColumns, input.calendarSlots))
        }
        if (input.heatSlots > 0) items.add(ShareBlockKind.HEAT to heatHeight(input.heatSlots))
        if (input.hasCompare) items.add(ShareBlockKind.COMPARE to COMPARE_H)
        if (input.hasBars) items.add(ShareBlockKind.BARS to BARS_H)
        items.add(ShareBlockKind.SUBJECTS to subjectsHeight(input.subjectRows))
        items.add(ShareBlockKind.FOOTER to FOOTER_H)

        val content = items.sumOf { it.second }
        val gaps = items.size - 1
        val base = TOP + content + GAP * gaps + BOTTOM
        val height = max(MIN_HEIGHT, base)
        val extra = height - base
        val extraGap = if (gaps > 0) extra / gaps else 0
        var y = TOP + (extra - extraGap * gaps)
        val blocks = ArrayList<ShareBlockBox>()
        for ((kind, h) in items) {
            blocks.add(ShareBlockBox(kind, y, h))
            y += h + GAP + extraGap
        }
        return ShareLayoutResult(WIDTH, height, blocks)
    }
}
