package com.example.service

import android.content.Context
import com.example.R
import com.example.data.AppDatabase
import com.example.data.model.StudySession
import com.example.util.DateTimeUtils
import com.example.util.LocaleHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Rebuilds the timer after the process was killed. The timer is never an in-memory counter: it is a set of
 * timestamps saved in SharedPreferences, so elapsed time is always recomputed from the wall clock.
 */
object SessionRecovery {
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * True when the phone was restarted after [heartbeatMs] (the last time the timer was known to be alive).
     * [uptimeMs] is the time since boot including sleep (SystemClock.elapsedRealtime). A heartbeat older than the boot
     * moment means the phone was off in between. Ten seconds of slack absorb clock corrections at start-up.
     */
    internal fun rebootedSince(heartbeatMs: Long, nowMs: Long, uptimeMs: Long): Boolean {
        if (heartbeatMs <= 0L) return false
        val bootMs = nowMs - uptimeMs
        return heartbeatMs < bootMs - 10_000L
    }

    /**
     * Restores the in-memory timer state from disk. Never starts a service, safe from any thread.
     * Returns true when a RUNNING or PAUSED timer is now in memory.
     */
    fun restoreStateOnly(context: Context): Boolean {
        val current = TimerStateManager.timerState.value
        if (current.status != TimerStatus.STOPPED) return true

        val prefs = context.getSharedPreferences(TimerForegroundService.PREFS_NAME, Context.MODE_PRIVATE)
        val statusStr = prefs.getString(TimerForegroundService.PREF_STATUS, null) ?: return false
        var status = try { TimerStatus.valueOf(statusStr) } catch (_: Exception) { return false }
        if (status == TimerStatus.STOPPED) return false

        val modeStr = prefs.getString(TimerForegroundService.PREF_MODE, TimerMode.STOPWATCH.name) ?: TimerMode.STOPWATCH.name
        val mode = try { TimerMode.valueOf(modeStr) } catch (_: Exception) { TimerMode.STOPWATCH }

        val subjectId = prefs.getLong(TimerForegroundService.PREF_SUBJECT_ID, -1L)
        if (subjectId == -1L) {
            prefs.edit().clear().apply()
            return false
        }
        val subjectName = prefs.getString(TimerForegroundService.PREF_SUBJECT_NAME, "") ?: ""
        val subjectColor = prefs.getLong(TimerForegroundService.PREF_SUBJECT_COLOR, 0xFF3B82F6L)
        val sessionStart = prefs.getLong(TimerForegroundService.PREF_SESSION_START, 0L)
        val lastResume = prefs.getLong(TimerForegroundService.PREF_LAST_RESUME, 0L)
        var accumulatedMs = prefs.getLong(TimerForegroundService.PREF_ACCUMULATED_MS, 0L)
        val targetSec = prefs.getLong(TimerForegroundService.PREF_TARGET_SECONDS, 0L)
        val pomoPhaseStr = prefs.getString(TimerForegroundService.PREF_POMO_PHASE, PomodoroPhase.FOCUS.name) ?: PomodoroPhase.FOCUS.name
        val pomoPhase = try { PomodoroPhase.valueOf(pomoPhaseStr) } catch (_: Exception) { PomodoroPhase.FOCUS }
        val pomoCycle = prefs.getInt(TimerForegroundService.PREF_POMO_CYCLE, 1)
        val interruptions = prefs.getInt(TimerForegroundService.PREF_INTERRUPTIONS, 0)

        val now = System.currentTimeMillis()

        // The phone was restarted while the timer ran: pause it at the last moment the app was alive. This is decided
        // here, not only in BootReceiver, because Android creates the Application BEFORE it delivers the boot broadcast,
        // so by the time the receiver ran the hours the phone was off had already been counted as study time.
        if (status == TimerStatus.RUNNING) {
            val heartbeat = prefs.getLong(TimerForegroundService.PREF_HEARTBEAT, 0L)
            if (rebootedSince(heartbeat, now, android.os.SystemClock.elapsedRealtime())) {
                accumulatedMs += if (heartbeat > lastResume) heartbeat - lastResume else 0L
                status = TimerStatus.PAUSED
                prefs.edit()
                    .putString(TimerForegroundService.PREF_STATUS, TimerStatus.PAUSED.name)
                    .putLong(TimerForegroundService.PREF_ACCUMULATED_MS, accumulatedMs)
                    .apply()
            }
        }

        val totalMs = if (status == TimerStatus.RUNNING) {
            accumulatedMs + (now - lastResume).coerceAtLeast(0L)
        } else {
            accumulatedMs
        }
        val elapsedSec = totalMs / 1000L

        // A countdown or Pomodoro phase that already ended while the process was dead: save it and finish.
        if ((mode == TimerMode.COUNTDOWN || mode == TimerMode.POMODORO) && targetSec > 0 && elapsedSec >= targetSec) {
            val countsAsStudy = mode == TimerMode.COUNTDOWN || pomoPhase == PomodoroPhase.FOCUS
            if (countsAsStudy) {
                val session = StudySession(
                    subjectId = subjectId,
                    startTime = sessionStart,
                    endTime = sessionStart + (targetSec * 1000L),
                    mode = mode.name,
                    interruptions = interruptions
                )
                val database = AppDatabase.getInstance(context)
                ioScope.launch { database.studySessionDao().insert(session) }
            }
            prefs.edit().clear().apply()
            TimerStateManager.setState(TimerState(status = TimerStatus.STOPPED))
            if (countsAsStudy) showRecoveryCompletionNotification(context, subjectName, targetSec)
            return false
        }

        val remainingSec = if (targetSec > 0) (targetSec - elapsedSec).coerceAtLeast(0L) else 0L
        TimerStateManager.setState(
            TimerState(
                status = status,
                mode = mode,
                subjectId = subjectId,
                subjectName = subjectName,
                subjectColor = subjectColor,
                sessionStartTime = sessionStart,
                lastResumeTime = if (status == TimerStatus.RUNNING) now else lastResume,
                accumulatedMillis = if (status == TimerStatus.RUNNING) totalMs else accumulatedMs,
                currentElapsedSeconds = elapsedSec,
                targetSeconds = targetSec,
                remainingSeconds = remainingSec,
                pomodoroPhase = pomoPhase,
                pomodoroCycle = pomoCycle,
                interruptions = interruptions
            )
        )
        return true
    }

    /**
     * Called from Application.onCreate. Restores the state and, if a timer was running, asks the service
     * to resume ticking. Starting a foreground service from the background can be refused on Android 12+,
     * so that call is wrapped: the state is already restored, and MainActivity retries when the app is visible.
     */
    fun restoreSessionIfAny(context: Context) {
        val restored = try { restoreStateOnly(context) } catch (_: Exception) { false }
        if (restored && TimerStateManager.timerState.value.status == TimerStatus.RUNNING) {
            TimerForegroundService.restoreRunningTimer(context)
        }
    }

    private fun showRecoveryCompletionNotification(context: Context, subjectName: String, targetSec: Long) {
        val text = LocaleHelper.localized(context)
        val name = subjectName.ifEmpty { text.getString(R.string.notif_default_subject) }
        NotificationHelper.showCompletionNotification(
            context,
            text.getString(R.string.countdown_complete_title),
            text.getString(R.string.countdown_complete_message, DateTimeUtils.formatDurationShort(targetSec), name)
        )
    }
}
