package com.example.data.backup

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

/** Pure rules of the scheduled backup (no Android classes, so they are unit tested on the JVM). */
object AutoBackupPlan {
    private val stamp = DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmm", Locale.US)

    /** Sorts by age when sorted by name, because the date comes first and every number has a fixed width. */
    fun fileName(nowMs: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        BackupManager.AUTO_PREFIX + stamp.format(Instant.ofEpochMilli(nowMs).atZone(zone)) + ".json"

    /** Only files this feature made may be deleted by the cleanup. Never touch anything else in the folder. */
    fun isOurFile(displayName: String): Boolean =
        displayName.startsWith(BackupManager.AUTO_PREFIX) && displayName.endsWith(".json")

    /**
     * Is a new backup due? Compared by calendar DATE, not by 24-hour distance: the daily check runs at about
     * the same clock time, and a run a few minutes early would otherwise be skipped for a whole day.
     * A clock that moved backwards (last backup "in the future") also counts as due.
     */
    fun isDue(lastSuccessMs: Long, nowMs: Long, intervalDays: Int, zone: ZoneId = ZoneId.systemDefault()): Boolean {
        if (lastSuccessMs <= 0L) return true
        val last: LocalDate = Instant.ofEpochMilli(lastSuccessMs).atZone(zone).toLocalDate()
        val today: LocalDate = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()
        val days = ChronoUnit.DAYS.between(last, today)
        return days < 0 || days >= intervalDays.coerceAtLeast(1)
    }
}
