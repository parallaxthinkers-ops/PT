package com.example.ui.screens.stats.share

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.R
import com.example.ui.screens.stats.StatsEngine
import com.example.ui.screens.stats.StatsTab
import com.example.ui.screens.stats.StatsUiState
import com.example.util.DateTimeUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

/** Turns what the Stats screen shows into a [ShareModel], with every word in the app language. */
object ShareModelFactory {

    private const val UNKNOWN_SUBJECT_COLOR = 0xFF64748BL

    fun create(context: Context, ui: StatsUiState, colors: ShareColors, now: LocalDateTime = LocalDateTime.now()): ShareModel {
        val locale = Locale.getDefault()
        val tab = ui.selectedTab
        val s = { id: Int -> context.getString(id) }
        val tabLabel = s(
            when (tab) {
                StatsTab.DAY -> R.string.stats_day
                StatsTab.WEEK -> R.string.stats_week
                StatsTab.MONTH -> R.string.stats_month
                StatsTab.YEAR -> R.string.stats_year
            }
        )

        // Title: the period, plus the subject when the screen is filtered to one.
        var periodTitle = when (tab) {
            StatsTab.DAY -> DateTimeUtils.formatDayHeader(ui.periodStartMs)
            StatsTab.WEEK -> context.getString(R.string.stats_week_of, DateTimeUtils.formatDate(ui.periodStartMs))
            StatsTab.MONTH -> DateTimeUtils.formatMonth(ui.periodStartMs)
            StatsTab.YEAR -> context.getString(R.string.stats_year_label, ui.periodStart.year.toString())
        }
        val filtered = ui.subjects.firstOrNull { it.id == ui.selectedSubjectId }
        if (filtered != null) periodTitle += " · " + filtered.name

        // The change against the previous period, worded like the badge on the Stats screen.
        val previousName = s(
            when (tab) {
                StatsTab.DAY -> R.string.stats_prev_day
                StatsTab.WEEK -> R.string.stats_prev_week
                StatsTab.MONTH -> R.string.stats_prev_month
                StatsTab.YEAR -> R.string.stats_prev_year
            }
        )
        val diff = ui.totalSeconds - ui.previousPeriodSeconds
        val badgeText = when {
            diff > 0 -> context.getString(R.string.stats_vs_up, DateTimeUtils.formatDurationShort(diff), previousName)
            diff < 0 -> context.getString(R.string.stats_vs_down, DateTimeUtils.formatDurationShort(-diff), previousName)
            else -> context.getString(R.string.stats_vs_same, previousName)
        }
        val badgeKind = if (diff > 0) 1 else if (diff < 0) -1 else 0

        val stats = listOf(
            ShareStat(s(R.string.stats_daily_average), DateTimeUtils.formatDurationShort(ui.dailyAverageSeconds)),
            ShareStat(
                s(R.string.stats_goal_achieved_days),
                context.getString(R.string.stats_days_of, ui.goalAchievedDaysCount.toString(), ui.elapsedDays.toString())
            ),
            ShareStat(s(R.string.stats_longest_session), DateTimeUtils.formatDurationShort(ui.longestSessionSeconds))
        )

        // Calendar (Day, Week, Month) or the month heatmap (Year).
        val calendar = ui.calendar?.let { grid ->
            val year = grid.titleStart.year
            val title = when (grid.tab) {
                StatsTab.DAY -> grid.titleStart.month.getDisplayName(TextStyle.FULL, locale) + " " + year
                StatsTab.WEEK -> context.getString(R.string.stats_quarter_label, year.toString(), StatsEngine.quarterNumber(grid.titleStart).toString())
                else -> year.toString()
            }
            val totalLabel = when (grid.tab) {
                StatsTab.DAY -> grid.titleStart.month.getDisplayName(TextStyle.SHORT, locale)
                StatsTab.WEEK -> context.getString(R.string.stats_quarter_short, StatsEngine.quarterNumber(grid.titleStart).toString())
                else -> year.toString()
            }
            ShareCalendarBlock(
                title = title,
                totalText = context.getString(R.string.stats_cal_total, totalLabel, DateTimeUtils.formatDurationCompact(grid.totalSeconds)),
                grid = grid,
                weekdayHeaders = if (grid.tab == StatsTab.DAY) ShareFormat.dayCalendarHeaders(grid, locale) else emptyList(),
                selectedDate = ui.periodStart
            )
        }
        val heat = if (ui.calendar == null && ui.heatmapDays.isNotEmpty()) {
            ShareHeatBlock(
                title = s(R.string.stats_monthly_heatmap),
                subtitle = DateTimeUtils.formatMonth(ui.heatmapMonthStartMs),
                leadingBlanks = ui.heatmapLeadingBlanks,
                days = ui.heatmapDays,
                weekdayHeaders = ShareFormat.weekdayHeaders(ui.firstDayOfWeek, TextStyle.NARROW, locale)
            )
        } else {
            null
        }

        val compare = ui.compare?.let { chart ->
            ShareCompareBlock(
                title = s(R.string.stats_compare_title),
                upTo = context.getString(R.string.stats_upto, ShareFormat.compareNowText(chart, ui.firstDayOfWeek, locale)),
                diffText = ShareFormat.signedDiff(chart.diffSeconds),
                todayLabel = s(R.string.stats_today),
                recordLabel = ShareFormat.compareRecordLabel(chart, locale),
                chart = chart,
                axisLabels = ShareFormat.compareAxisLabels(chart, ui.firstDayOfWeek, locale)
            )
        }

        val bars = if (ui.barChartPoints.isEmpty()) {
            null
        } else {
            val maxSeconds = ui.barChartPoints.maxOf { it.seconds }.coerceAtLeast(60L)
            ShareBarsBlock(
                title = s(R.string.stats_activity_breakdown),
                maxText = context.getString(R.string.stats_max_axis, DateTimeUtils.formatDurationCompact(maxSeconds)),
                points = ui.barChartPoints,
                labelStep = when (tab) {
                    StatsTab.DAY -> 4
                    StatsTab.WEEK -> 1
                    StatsTab.MONTH -> 5
                    StatsTab.YEAR -> 2
                }
            )
        }

        val rows = ShareFormat.subjectRows(
            items = ui.distribution,
            nameOf = { item ->
                val subject = item.subject
                when {
                    subject == null -> s(R.string.timeline_unknown_subject)
                    subject.isArchived -> subject.name + " " + s(R.string.timeline_deleted_suffix)
                    else -> subject.name
                }
            },
            colorOf = { item ->
                val subject = item.subject
                if (subject != null && !subject.isArchived) subject.color and 0xFFFFFFFFL else UNKNOWN_SUBJECT_COLOR
            },
            othersName = s(R.string.stats_share_others)
        )
        val subjects = ShareSubjectsBlock(
            title = s(R.string.stats_subject_breakdown),
            emptyText = s(R.string.stats_no_data),
            rows = rows,
            totalText = DateTimeUtils.formatDurationShort(ui.totalSeconds),
            totalShort = s(R.string.stats_total_short)
        )

        val appName = s(R.string.app_name)
        val dateText = now.format(DateTimeFormatter.ofPattern("MMM d, yyyy", locale))
        return ShareModel(
            tab = tab,
            colors = colors,
            appName = appName,
            tabLabel = tabLabel,
            periodTitle = periodTitle,
            totalLabel = s(R.string.stats_total_time),
            totalText = DateTimeUtils.formatDurationShort(ui.totalSeconds),
            badgeText = badgeText,
            badgeKind = badgeKind,
            stats = stats,
            calendar = calendar,
            heat = heat,
            compare = compare,
            bars = bars,
            subjects = subjects,
            lessLabel = s(R.string.stats_less),
            moreLabel = s(R.string.stats_more),
            footer = context.getString(R.string.stats_share_footer, appName, dateText)
        )
    }
}

/** Puts a finished picture into the phone's gallery (Pictures / Parallax Tracker). */
object ShareSaver {
    private const val FOLDER = "Parallax Tracker"

    /** The saved picture's address, or null when it could not be saved. */
    fun save(context: Context, bitmap: Bitmap, fileName: String): Uri? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) saveWithMediaStore(context, bitmap, fileName)
        else saveToPublicFolder(context, bitmap, fileName)

    // Android 10 and newer: the gallery store takes the file and no permission is needed.
    private fun saveWithMediaStore(context: Context, bitmap: Bitmap, fileName: String): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + FOLDER)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val stream = resolver.openOutputStream(uri) ?: throw IOException("no output stream")
            stream.use { if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IOException("compress failed") }
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            uri
        } catch (e: Exception) {
            // Do not leave a half-written picture in the gallery.
            try { resolver.delete(uri, null, null) } catch (_: Exception) { }
            null
        }
    }

    // Android 8 and 9: write into the public Pictures folder (needs the storage permission) and tell the gallery.
    @Suppress("DEPRECATION")
    private fun saveToPublicFolder(context: Context, bitmap: Bitmap, fileName: String): Uri? {
        return try {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), FOLDER)
            if (!dir.exists() && !dir.mkdirs()) return null
            val file = File(dir, fileName)
            FileOutputStream(file).use { if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) throw IOException("compress failed") }
            MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/png"), null)
            Uri.fromFile(file)
        } catch (e: Exception) {
            null
        }
    }
}

/** Builds the picture and saves it, all off the main thread. */
object ShareExporter {
    /** True when the picture was saved. */
    suspend fun export(context: Context, ui: StatsUiState, colors: ShareColors): Boolean = withContext(Dispatchers.Default) {
        var bitmap: Bitmap? = null
        try {
            val model = ShareModelFactory.create(context, ui, colors)
            bitmap = ShareCardRenderer.render(context, model)
            ShareSaver.save(context, bitmap, ShareFormat.fileName(LocalDateTime.now())) != null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            // Out of memory, a missing font, a full disk: all of them just mean "could not save", never a crash.
            false
        } finally {
            bitmap?.recycle()
        }
    }
}
