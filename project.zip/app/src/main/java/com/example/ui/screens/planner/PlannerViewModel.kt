package com.example.ui.screens.planner

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.StudyApplication
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.util.DateTimeUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZoneId

data class TaskWithSubject(
    val task: StudyTask,
    val subject: Subject?,
    val isCompletedToday: Boolean
)

data class PlannerUiState(
    val date: LocalDate = LocalDate.now(),
    /** "yyyy-MM-dd", the key tasks and completions are stored under. */
    val dateKey: String = DateTimeUtils.formatDateKey(LocalDate.now()),
    val isToday: Boolean = true,
    val tasks: List<TaskWithSubject> = emptyList(),
    val subjects: List<Subject> = emptyList(),
    val completedCount: Int = 0,
    val totalCount: Int = 0,
    val totalPlannedMinutes: Int = 0
) {
    /** Midday of [date] in the local zone, for formatting the header. */
    val dateMs: Long
        get() = date.atTime(12, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
}

/**
 * The Planner works in STUDY days, like the rest of the app: with a day start of 05:00, 02:00 still belongs
 * to the previous day. All date maths uses java.time and ASCII date keys, so the language setting (which can
 * switch to Bengali digits) never changes how a task's date is stored or compared.
 */
class PlannerViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as StudyApplication
    private val studyRepo = app.studyRepository
    private val settingsRepo = app.settingsRepository

    /** null means "today", which then follows the study day automatically. */
    private val selectedDate = MutableStateFlow<LocalDate?>(null)

    private val dayStartHour = settingsRepo.settings.map { it.dayStartHour }.distinctUntilChanged()

    /** Today's study date. Checked every minute, so a Planner left open overnight moves on to the new day by itself. */
    @OptIn(ExperimentalCoroutinesApi::class)
    private val todayKey: Flow<LocalDate> = dayStartHour
        .flatMapLatest { hour ->
            flow {
                while (true) {
                    emit(DateTimeUtils.studyDateOf(System.currentTimeMillis(), hour))
                    delay(60_000L)
                }
            }
        }
        .distinctUntilChanged()

    @OptIn(ExperimentalCoroutinesApi::class)
    val uiState: StateFlow<PlannerUiState> = combine(selectedDate, todayKey) { selected, today ->
        (selected ?: today) to today
    }.distinctUntilChanged().flatMapLatest { (date, today) ->
        val dateKey = DateTimeUtils.formatDateKey(date)
        combine(
            studyRepo.allTasks,
            studyRepo.getCompletionsForDate(dateKey),
            studyRepo.allSubjects
        ) { allTasks, completions, subjects ->
            val completedIds = completions.map { it.taskId }.toSet()
            // Tasks of an archived subject stay visible, just without the subject.
            val activeById = subjects.filter { !it.isArchived }.associateBy { it.id }

            val visible = allTasks.filter { task -> appearsOn(task, date, dateKey) }.sortedBy { it.order }
            val items = visible.map { task ->
                TaskWithSubject(
                    task = task,
                    subject = task.subjectId?.let { activeById[it] },
                    isCompletedToday = completedIds.contains(task.id) || (task.repeatRule == "NONE" && task.isDone)
                )
            }

            PlannerUiState(
                date = date,
                dateKey = dateKey,
                isToday = date == today,
                tasks = items,
                subjects = subjects.filter { !it.isArchived },
                completedCount = items.count { it.isCompletedToday },
                totalCount = items.size,
                totalPlannedMinutes = items.sumOf { it.task.plannedMinutes }
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = PlannerUiState()
    )

    /** Does this task show up on [date]? Dates are compared as ISO keys, which sort like dates. */
    private fun appearsOn(task: StudyTask, date: LocalDate, dateKey: String): Boolean {
        val taskDate = DateTimeUtils.parseDateKey(task.date)
        return when (task.repeatRule) {
            "DAILY" -> dateKey >= task.date
            "WEEKDAYS" -> dateKey >= task.date &&
                date.dayOfWeek != DayOfWeek.SATURDAY && date.dayOfWeek != DayOfWeek.SUNDAY
            "WEEKLY" -> dateKey >= task.date && taskDate != null && date.dayOfWeek == taskDate.dayOfWeek
            else -> task.date == dateKey
        }
    }

    fun selectDate(date: LocalDate) {
        selectedDate.value = date
    }

    fun goToToday() {
        selectedDate.value = null
    }

    fun nextDay() {
        selectedDate.value = uiState.value.date.plusDays(1)
    }

    fun prevDay() {
        selectedDate.value = uiState.value.date.minusDays(1)
    }

    fun toggleTask(item: TaskWithSubject) {
        viewModelScope.launch {
            val dateKey = uiState.value.dateKey
            val newCompleted = !item.isCompletedToday
            studyRepo.toggleTaskCompletion(item.task.id, dateKey, newCompleted)
            if (item.task.repeatRule == "NONE") {
                studyRepo.updateTask(item.task.copy(isDone = newCompleted))
            }
        }
    }

    fun addTask(title: String, subjectId: Long?, plannedMinutes: Int, repeatRule: String) {
        viewModelScope.launch {
            val state = uiState.value
            studyRepo.insertTask(
                StudyTask(
                    title = title,
                    subjectId = subjectId,
                    plannedMinutes = plannedMinutes,
                    date = state.dateKey,
                    repeatRule = repeatRule,
                    order = state.tasks.size
                )
            )
        }
    }

    fun updateTask(task: StudyTask) {
        viewModelScope.launch { studyRepo.updateTask(task) }
    }

    fun deleteTask(task: StudyTask) {
        viewModelScope.launch { studyRepo.deleteTask(task) }
    }

    fun moveTask(index: Int, direction: Int) {
        val tasks = uiState.value.tasks.map { it.task }.toMutableList()
        val to = index + direction
        if (index !in tasks.indices || to !in tasks.indices) return
        tasks.add(to, tasks.removeAt(index))
        viewModelScope.launch { studyRepo.updateTasksOrder(tasks) }
    }
}
