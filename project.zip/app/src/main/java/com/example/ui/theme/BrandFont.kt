package com.example.ui.theme

import android.content.Context
import android.graphics.Typeface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily

/**
 * The font of the app name on the Timer screen (Ethnocentric).
 *
 * The font file is NOT inside the code. Put the file in `app/src/main/assets/fonts/` and give it any name that
 * contains "ethnocentric" (for example `ethnocentric.ttf` or `ethnocentric rg.otf`). It is found by name at run
 * time, so the project still builds without it; until the file is there the app name uses the normal font.
 */
private const val FONT_DIR = "fonts"

private object BrandFontCache {
    @Volatile var loaded = false
    @Volatile var family: FontFamily? = null
}

private fun loadBrandFont(context: Context): FontFamily? {
    if (BrandFontCache.loaded) return BrandFontCache.family
    val family = try {
        val assets = context.applicationContext.assets
        val file = assets.list(FONT_DIR).orEmpty().firstOrNull {
            val n = it.lowercase()
            n.contains("ethnocentric") && (n.endsWith(".ttf") || n.endsWith(".otf"))
        }
        if (file == null) null else FontFamily(Typeface.createFromAsset(assets, "$FONT_DIR/$file"))
    } catch (_: Exception) {
        // A missing or damaged font file must never crash the Timer screen.
        null
    }
    BrandFontCache.family = family
    BrandFontCache.loaded = true
    return family
}

/** The Ethnocentric font family, or null when the font file has not been added (the caller then keeps the normal font). */
@Composable
fun rememberBrandFont(): FontFamily? {
    val context = LocalContext.current
    return remember(context) { loadBrandFont(context) }
}
