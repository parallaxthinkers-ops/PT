package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "study_sessions",
    foreignKeys = [
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["subjectId"]),
        Index(value = ["startTime"]),
        Index(value = ["endTime"])
    ]
)
data class StudySession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subjectId: Long? = null,
    val startTime: Long, // Epoch ms
    val endTime: Long,   // Epoch ms
    val mode: String = "STOPWATCH", // STOPWATCH, COUNTDOWN, POMODORO
    val interruptions: Int = 0
) {
    val durationMillis: Long
        get() = (endTime - startTime).coerceAtLeast(0L)

    val durationSeconds: Long
        get() = durationMillis / 1000L
}
