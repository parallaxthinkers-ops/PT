package com.example.ui.screens.focus

import android.content.Intent
import android.content.res.Configuration
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.StudyApplication
import com.example.data.repository.AppSettings
import com.example.service.NotificationHelper
import com.example.service.PomodoroPhase
import com.example.service.TimerForegroundService
import com.example.service.TimerMode
import com.example.service.TimerStateManager
import com.example.service.TimerStatus
import com.example.ui.components.ColorDot
import com.example.ui.theme.TimerDigitsStyle
import com.example.ui.theme.Ui
import com.example.util.DateTimeUtils
import com.example.util.findActivity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

// The focus screen is always dark and pure black, whatever the app theme is: it is meant to be left on a
// desk for hours, so it is as calm and as cheap on an OLED screen as possible.
private val FocusBackground = Color.Black
private val FocusText = Color(0xFFF5F5F4)
private val FocusMuted = Color(0xFF8A8F98)
private val FocusSurface = Color(0xFF16181D)

@Composable
fun FocusScreen(
    onExitFocus: () -> Unit,
    modifier: Modifier = Modifier
) {
    val timerState by TimerStateManager.timerState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    // The context is a wrapper (for the app language), so the Activity has to be found through it.
    val activity = remember(context) { context.findActivity() }
    val app = context.applicationContext as StudyApplication
    val settingsRepo = app.settingsRepository
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    val settings by settingsRepo.settings.collectAsStateWithLifecycle(initialValue = AppSettings())

    var showExitDialog by remember { mutableStateOf(false) }
    var showPinningExplanationDialog by remember { mutableStateOf(false) }
    var isScreenPinned by remember { mutableStateOf(false) }

    // 1. Immersive mode: hide the system bars while focusing.
    DisposableEffect(activity) {
        val window = activity?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            onDispose { controller.show(WindowInsetsCompat.Type.systemBars()) }
        } else {
            onDispose {}
        }
    }

    // 2. Keep the screen on in focus mode.
    DisposableEffect(activity) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    // 3. Ambient mode: dim the screen while focusing, and put the brightness back afterwards.
    DisposableEffect(settings.ambientMode, activity) {
        if (settings.ambientMode && activity != null) {
            val attributes = activity.window.attributes
            val original = attributes.screenBrightness
            attributes.screenBrightness = 0.15f
            activity.window.attributes = attributes
            onDispose {
                attributes.screenBrightness = original
                activity.window.attributes = attributes
            }
        } else {
            onDispose {}
        }
    }

    // 4. Leaving the app while the timer runs counts as an interruption.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && timerState.status == TimerStatus.RUNNING) {
                TimerForegroundService.recordInterruption(context)
                NotificationHelper.showFocusLeftNotification(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    BackHandler { showExitDialog = true }

    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val activeColor = Color(timerState.subjectColor)
    val displaySeconds = when (timerState.mode) {
        TimerMode.STOPWATCH -> timerState.currentElapsedSeconds
        TimerMode.COUNTDOWN, TimerMode.POMODORO -> timerState.remainingSeconds
    }
    val phaseLabel = stringResource(
        when (timerState.pomodoroPhase) {
            PomodoroPhase.FOCUS -> R.string.pomo_phase_focus
            PomodoroPhase.SHORT_BREAK -> R.string.pomo_phase_short_break
            PomodoroPhase.LONG_BREAK -> R.string.pomo_phase_long_break
        }
    )
    val cycleLabel = stringResource(R.string.pomo_cycle_indicator, timerState.pomodoroCycle, settings.pomoInterval)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FocusBackground)
            .safeDrawingPadding()
            .padding(20.dp)
    ) {
        // Top bar: subject, Do Not Disturb shortcut, screen pinning, exit
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = activeColor.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, activeColor.copy(alpha = 0.5f)),
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ColorDot(activeColor)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = timerState.subjectName.ifEmpty { stringResource(R.string.focus_default_title) },
                        color = FocusText,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (settings.dndPromptEnabled) {
                    IconButton(
                        onClick = {
                            try {
                                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                            } catch (_: Exception) {
                                try {
                                    context.startActivity(Intent(Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS))
                                } catch (_: Exception) {
                                }
                            }
                        }
                    ) {
                        Icon(Icons.Filled.DoNotDisturbOn, contentDescription = stringResource(R.string.focus_dnd_button), tint = FocusMuted)
                    }
                }

                IconButton(
                    onClick = {
                        if (isScreenPinned) {
                            try {
                                activity?.stopLockTask()
                            } catch (_: Exception) {
                            }
                            isScreenPinned = false
                        } else {
                            coroutineScope.launch {
                                val explained = settingsRepo.screenPinningExplainedFlow.first()
                                if (!explained) {
                                    showPinningExplanationDialog = true
                                } else {
                                    try {
                                        activity?.startLockTask()
                                        isScreenPinned = true
                                    } catch (_: Exception) {
                                    }
                                }
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (isScreenPinned) Icons.Filled.Lock else Icons.Filled.LockOpen,
                        contentDescription = stringResource(R.string.focus_screen_pinning),
                        tint = if (isScreenPinned) Ui.extra.success else FocusMuted
                    )
                }

                IconButton(onClick = { showExitDialog = true }, modifier = Modifier.testTag("exit_focus_button")) {
                    Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.exit_focus_mode), tint = FocusText)
                }
            }
        }

        // Clock and status
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = DateTimeUtils.formatTimerClock(displaySeconds),
                style = TimerDigitsStyle,
                fontSize = if (isLandscape) 96.sp else 64.sp,
                lineHeight = if (isLandscape) 104.sp else 72.sp,
                color = FocusText,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (timerState.mode == TimerMode.POMODORO) {
                Text(
                    text = "$phaseLabel · $cycleLabel",
                    style = MaterialTheme.typography.titleMedium,
                    color = activeColor
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            val interrupted = timerState.interruptions > 0
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = if (interrupted) Ui.extra.danger.copy(alpha = 0.18f) else FocusSurface
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (interrupted) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = Ui.extra.danger, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = stringResource(R.string.focus_interruptions, timerState.interruptions.toString()),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (interrupted) Ui.extra.danger else FocusMuted
                    )
                }
            }
        }

        // Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (timerState.status == TimerStatus.RUNNING) {
                OutlinedButton(
                    onClick = { TimerForegroundService.pauseTimer(context) },
                    shape = MaterialTheme.shapes.extraLarge,
                    border = BorderStroke(1.dp, FocusMuted)
                ) {
                    Icon(Icons.Filled.Pause, contentDescription = null, tint = FocusText)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.pause), color = FocusText)
                }
            } else if (timerState.status == TimerStatus.PAUSED) {
                Button(
                    onClick = { TimerForegroundService.resumeTimer(context) },
                    shape = MaterialTheme.shapes.extraLarge,
                    colors = ButtonDefaults.buttonColors(containerColor = activeColor, contentColor = Color.White)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(stringResource(R.string.resume))
                }
            }

            if (timerState.mode == TimerMode.POMODORO && timerState.status != TimerStatus.STOPPED) {
                OutlinedButton(
                    onClick = { TimerForegroundService.skipPomodoroPhase(context) },
                    shape = MaterialTheme.shapes.extraLarge,
                    border = BorderStroke(1.dp, FocusMuted)
                ) {
                    Icon(Icons.Filled.SkipNext, contentDescription = null, tint = FocusText)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.pomo_skip_phase), color = FocusText)
                }
            }

            if (timerState.status != TimerStatus.STOPPED) {
                OutlinedButton(
                    onClick = { showExitDialog = true },
                    shape = MaterialTheme.shapes.extraLarge,
                    border = BorderStroke(1.dp, Ui.extra.danger.copy(alpha = 0.6f))
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = null, tint = Ui.extra.danger)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.stop), color = Ui.extra.danger)
                }
            }
        }
    }

    if (showPinningExplanationDialog) {
        AlertDialog(
            onDismissRequest = { showPinningExplanationDialog = false },
            title = { Text(stringResource(R.string.focus_pinning_title)) },
            text = { Text(stringResource(R.string.focus_pinning_desc)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        coroutineScope.launch { settingsRepo.setScreenPinningExplained(true) }
                        showPinningExplanationDialog = false
                        try {
                            activity?.startLockTask()
                            isScreenPinned = true
                        } catch (_: Exception) {
                        }
                    }
                ) {
                    Text(stringResource(R.string.focus_pinning_enable))
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinningExplanationDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text(stringResource(R.string.focus_exit_title)) },
            text = { Text(stringResource(R.string.focus_exit_message)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (isScreenPinned) {
                            try {
                                activity?.stopLockTask()
                            } catch (_: Exception) {
                            }
                        }
                        showExitDialog = false
                        onExitFocus()
                    }
                ) {
                    Text(stringResource(R.string.focus_exit_confirm))
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitDialog = false }) {
                    Text(stringResource(R.string.focus_exit_stay))
                }
            }
        )
    }
}
