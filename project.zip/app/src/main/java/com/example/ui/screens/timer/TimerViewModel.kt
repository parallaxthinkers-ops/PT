package com.example.ui.screens.timer

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.StudyApplication
import com.example.data.model.DDay
import com.example.data.model.Goal
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.data.repository.AppSettings
import com.example.service.PomodoroPhase
import com.example.service.TimerForegroundService
import com.example.service.TimerMode
import com.example.service.TimerState
import com.example.service.TimerStateManager
import com.example.service.TimerStatus
import com.example.util.DateTimeUtils
import com.example.util.StudyMath
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class SubjectStudyStat(
    val subject: Subject,
    /** Seconds already saved today. The running timer adds its own live seconds on top, in the UI leaf. */
    val todaySeconds: Long
)

/** The parts of the timer that change rarely. Per-second values stay out of [TimerUiState]. */
data class RunInfo(
    val status: TimerStatus = TimerStatus.STOPPED,
    val mode: TimerMode = TimerMode.STOPWATCH,
    val subjectId: Long? = null,
    val subjectName: String = "",
    val subjectColor: Long = 0xFF3B82F6L,
    val phase: PomodoroPhase = PomodoroPhase.FOCUS,
    val cycle: Int = 1,
    val targetSeconds: Long = 0L,
    val interruptions: Int = 0
)

/**
 * Everything the Timer screen needs EXCEPT the ticking seconds. This is recomputed when the database or
 * settings change, never once per second. The screen reads the live seconds from [TimerViewModel.timerState]
 * in small leaf composables.
 */
data class TimerUiState(
    val run: RunInfo = RunInfo(),
    val subjects: List<Subject> = emptyList(),
    val subjectStats: List<SubjectStudyStat> = emptyList(),
    val selectedSubjectId: Long? = null,
    val completedTodaySeconds: Long = 0L,
    val todayGoalSeconds: Long = 14400L,
    /** Consecutive goal-met days before today. Today adds one once its goal is reached. */
    val streakBeforeToday: Int = 0,
    val pinnedDDay: DDay? = null,
    val settings: AppSettings = AppSettings(),
    val showCelebrationDialog: Boolean = false
)

/** Database-derived numbers. Recomputed on data change or when the study day rolls over. */
private data class TodayBase(
    val subjects: List<Subject>,
    val completedBySubject: Map<Long, Long>,
    val completedTotal: Long,
    val goalSeconds: Long,
    val streakBeforeToday: Int
)

class TimerViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as StudyApplication
    private val studyRepo = app.studyRepository
    private val settingsRepo = app.settingsRepository
    private val uiPrefs = application.getSharedPreferences("timer_ui", Context.MODE_PRIVATE)

    private val _showCelebration = MutableStateFlow(false)

    /** Live timer state. Collect it only in small composables, it changes every second. */
    val timerState: StateFlow<TimerState> = TimerStateManager.timerState

    private val runInfo: Flow<RunInfo> = TimerStateManager.timerState
        .map {
            RunInfo(
                status = it.status,
                mode = it.mode,
                subjectId = it.subjectId,
                subjectName = it.subjectName,
                subjectColor = it.subjectColor,
                phase = it.pomodoroPhase,
                cycle = it.pomodoroCycle,
                targetSeconds = it.targetSeconds,
                interruptions = it.interruptions
            )
        }
        .distinctUntilChanged()

    /** Emits the current study date, and again when the study day rolls over (also if the day-start changes). */
    @OptIn(ExperimentalCoroutinesApi::class)
    private val dayKey: Flow<Pair<LocalDate, Int>> = settingsRepo.dayStartHourFlow
        .flatMapLatest { hour ->
            flow {
                while (true) {
                    emit(DateTimeUtils.studyDateOf(System.currentTimeMillis(), hour) to hour)
                    delay(30_000L)
                }
            }
        }
        .distinctUntilChanged()

    private val todayBase: Flow<TodayBase> = combine(
        dayKey,
        studyRepo.activeSubjects,
        studyRepo.allSessions,
        studyRepo.allGoals
    ) { key, subjects, sessions, goals ->
        computeTodayBase(key.first, key.second, subjects, sessions, goals)
    }.flowOn(Dispatchers.Default)

    private val slow: Flow<TimerUiState> = combine(
        todayBase,
        settingsRepo.settings,
        studyRepo.pinnedDDay,
        runInfo
    ) { base, settings, pinned, run ->
        val candidate = if (run.status != TimerStatus.STOPPED) run.subjectId else settings.selectedSubjectId
        val effectiveSelected = when {
            candidate != null && base.subjects.any { it.id == candidate } -> candidate
            base.subjects.isNotEmpty() -> base.subjects.first().id
            else -> null
        }
        TimerUiState(
            run = run,
            subjects = base.subjects,
            subjectStats = base.subjects.map { SubjectStudyStat(it, base.completedBySubject[it.id] ?: 0L) },
            selectedSubjectId = effectiveSelected,
            completedTodaySeconds = base.completedTotal,
            todayGoalSeconds = base.goalSeconds,
            streakBeforeToday = base.streakBeforeToday,
            pinnedDDay = pinned,
            settings = settings
        )
    }

    val uiState: StateFlow<TimerUiState> = combine(slow, _showCelebration) { state, celebrate ->
        state.copy(showCelebrationDialog = celebrate)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TimerUiState()
    )

    private fun computeTodayBase(
        today: LocalDate,
        dayStartHour: Int,
        subjects: List<Subject>,
        sessions: List<StudySession>,
        goals: List<Goal>
    ): TodayBase {
        val (startMs, endMs) = DateTimeUtils.studyDayRangeForDate(today, dayStartHour)

        val bySubject = HashMap<Long, Long>()
        var total = 0L
        for (s in sessions) {
            if (s.endTime <= startMs || s.startTime >= endMs) continue
            val sec = DateTimeUtils.getSessionOverlapMillis(s, startMs, endMs) / 1000L
            total += sec
            s.subjectId?.let { id -> bySubject[id] = (bySubject[id] ?: 0L) + sec }
        }

        fun goalSecondsFor(date: LocalDate): Long {
            val weekday = StudyMath.calendarWeekday(date)
            val minutes = goals.firstOrNull { it.weekday == weekday }?.targetMinutes ?: 240
            return minutes * 60L
        }

        // Buckets every session once, here, instead of filtering the full history per day.
        val perDay = StudyMath.secondsPerStudyDay(sessions, dayStartHour)
        var past = 0
        var date = today.minusDays(1)
        while (past < 366) {
            val goal = goalSecondsFor(date)
            if (goal > 0 && (perDay[date] ?: 0L) >= goal) {
                past++
                date = date.minusDays(1)
            } else {
                break
            }
        }

        return TodayBase(
            subjects = subjects,
            completedBySubject = bySubject,
            completedTotal = total,
            goalSeconds = goalSecondsFor(today),
            streakBeforeToday = past
        )
    }

    /** Seconds of the running timer that count as study time (Pomodoro breaks do not). */
    fun liveStudySeconds(state: TimerState): Long {
        if (state.status == TimerStatus.STOPPED) return 0L
        if (state.mode == TimerMode.POMODORO && state.pomodoroPhase != PomodoroPhase.FOCUS) return 0L
        return state.currentElapsedSeconds
    }

    /** Called by the UI when today's total reaches the goal. Shows the dialog once per study day. */
    fun onGoalReached() {
        val dayStart = uiState.value.settings.dayStartHour
        val key = DateTimeUtils.getStudyDateString(System.currentTimeMillis(), dayStart)
        if (uiPrefs.getString(KEY_CELEBRATED, null) != key) {
            uiPrefs.edit().putString(KEY_CELEBRATED, key).apply()
            _showCelebration.value = true
        }
    }

    fun dismissCelebration() {
        _showCelebration.value = false
    }

    fun selectSubject(subjectId: Long) {
        viewModelScope.launch { settingsRepo.setSelectedSubjectId(subjectId) }
        val state = TimerStateManager.timerState.value
        val newSubj = uiState.value.subjects.find { it.id == subjectId } ?: return
        if (state.status != TimerStatus.STOPPED && state.subjectId != subjectId) {
            TimerForegroundService.switchSubject(
                context = getApplication(),
                newSubjectId = newSubj.id,
                newSubjectName = newSubj.name,
                newSubjectColor = newSubj.color
            )
        }
    }

    fun archiveSubject(subjectId: Long) {
        viewModelScope.launch {
            studyRepo.archiveSubject(subjectId)
            if (settingsRepo.selectedSubjectIdFlow.first() == subjectId) {
                settingsRepo.setSelectedSubjectId(null)
            }
        }
    }

    fun deleteSubjectAndHistory(subjectId: Long) {
        viewModelScope.launch {
            studyRepo.hardDeleteSubject(subjectId)
            if (settingsRepo.selectedSubjectIdFlow.first() == subjectId) {
                settingsRepo.setSelectedSubjectId(null)
            }
        }
    }

    fun setCountdownDuration(seconds: Long) {
        viewModelScope.launch { settingsRepo.setCountdownSeconds(seconds) }
    }

    fun selectPresetMinutes(minutes: Int) = setCountdownDuration(minutes * 60L)

    fun addCustomPreset(minutes: Int) {
        viewModelScope.launch { settingsRepo.addCustomPreset(minutes) }
    }

    fun deleteCustomPreset(minutes: Int) {
        viewModelScope.launch { settingsRepo.deleteCustomPreset(minutes) }
    }

    fun adjustRunningCountdown(deltaSeconds: Long) {
        TimerForegroundService.adjustCountdown(getApplication(), deltaSeconds)
    }

    fun updatePomodoroSettings(focus: Int, shortBreak: Int, longBreak: Int, interval: Int) {
        viewModelScope.launch { settingsRepo.setPomoSettings(focus, shortBreak, longBreak, interval) }
    }

    fun startTimerForSubject(subjectId: Long, mode: TimerMode = TimerMode.STOPWATCH) {
        val target = uiState.value.subjects.find { it.id == subjectId } ?: return
        viewModelScope.launch { settingsRepo.setSelectedSubjectId(subjectId) }
        startTimer(mode = mode, subject = target)
    }

    fun startTimer(mode: TimerMode = TimerMode.STOPWATCH, subject: Subject? = null) {
        val state = uiState.value
        val chosen = subject
            ?: state.subjects.find { it.id == state.selectedSubjectId }
            ?: state.subjects.firstOrNull()
            ?: return

        viewModelScope.launch {
            val s = settingsRepo.settings.first()
            val targetSec = when (mode) {
                TimerMode.STOPWATCH -> 0L
                TimerMode.COUNTDOWN -> s.countdownSeconds
                TimerMode.POMODORO -> s.pomoFocusMinutes * 60L
            }
            TimerForegroundService.startTimer(
                context = getApplication(),
                subjectId = chosen.id,
                subjectName = chosen.name,
                subjectColor = chosen.color,
                mode = mode,
                targetSeconds = targetSec,
                pomoFocus = s.pomoFocusMinutes,
                pomoShortBreak = s.pomoShortBreakMinutes,
                pomoLongBreak = s.pomoLongBreakMinutes,
                pomoInterval = s.pomoInterval
            )
        }
    }

    fun pauseTimer() = TimerForegroundService.pauseTimer(getApplication())
    fun resumeTimer() = TimerForegroundService.resumeTimer(getApplication())
    fun stopTimer() = TimerForegroundService.stopTimer(getApplication())
    fun skipPomodoroPhase() = TimerForegroundService.skipPomodoroPhase(getApplication())

    fun addSubject(name: String, color: Long) {
        viewModelScope.launch {
            val newId = studyRepo.insertSubject(
                Subject(name = name.trim(), color = color, order = uiState.value.subjects.size)
            )
            if (uiState.value.selectedSubjectId == null) {
                settingsRepo.setSelectedSubjectId(newId)
            }
        }
    }

    fun updateSubject(subject: Subject) {
        // A running timer keeps showing the old name until it stops; renaming must never split a session.
        viewModelScope.launch { studyRepo.updateSubject(subject) }
    }

    companion object {
        private const val KEY_CELEBRATED = "celebrated_study_day"
    }
}
