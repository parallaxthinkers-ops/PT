package com.example.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.backup.BackupSummary
import com.example.data.model.Subject
import com.example.ui.components.AppAlertDialog
import com.example.ui.components.ColorDot
import com.example.ui.components.RowDivider
import com.example.ui.components.SectionLabel
import com.example.ui.theme.Ui
import com.example.util.DateTimeUtils

/** Sets the hour when the study day resets. */
@Composable
fun DayStartDialog(
    initialHour: Int,
    is12Hour: Boolean,
    onDismiss: () -> Unit,
    onSave: (Int) -> Unit
) {
    var hour by remember { mutableFloatStateOf(initialHour.coerceIn(0, 23).toFloat()) }
    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.day_start_time)) },
        text = {
            Column {
                Text(
                    text = stringResource(R.string.day_start_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.size(20.dp))
                Text(
                    text = DateTimeUtils.formatHourLabel(hour.toInt(), is12Hour),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Slider(
                    value = hour,
                    onValueChange = { hour = it },
                    valueRange = 0f..23f,
                    steps = 22
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(hour.toInt()) }) { Text(stringResource(R.string.save)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

/** Hours and minutes sliders for one goal. Minutes move in steps of 5. */
@Composable
fun GoalDialog(
    title: String,
    initialMinutes: Int,
    onDismiss: () -> Unit,
    onSave: (totalMinutes: Int) -> Unit
) {
    val initial = initialMinutes.coerceIn(0, 24 * 60)
    var hours by remember { mutableFloatStateOf((initial / 60).coerceAtMost(16).toFloat()) }
    var minutes by remember { mutableFloatStateOf(((initial % 60) / 5 * 5).toFloat()) }
    val total = hours.toInt() * 60 + minutes.toInt()

    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(
                    text = if (total == 0) stringResource(R.string.settings_goal_none)
                    else DateTimeUtils.formatDurationCompact(total * 60L),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.size(12.dp))
                Text(
                    text = stringResource(R.string.countdown_hours),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(value = hours, onValueChange = { hours = it }, valueRange = 0f..16f, steps = 15)
                Text(
                    text = stringResource(R.string.countdown_minutes),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(value = minutes, onValueChange = { minutes = it }, valueRange = 0f..55f, steps = 10)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(total) }) { Text(stringResource(R.string.save)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

/** Reorder active subjects and bring archived ones back. */
@Composable
fun ManageSubjectsDialog(
    active: List<Subject>,
    archived: List<Subject>,
    onMove: (subjectId: Long, direction: Int) -> Unit,
    onRestore: (subjectId: Long) -> Unit,
    onDismiss: () -> Unit
) {
    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.settings_manage_subjects)) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (active.isEmpty()) {
                    Text(
                        text = stringResource(R.string.settings_no_subjects),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                active.forEachIndexed { index, subject ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ColorDot(Color(subject.color), size = 12.dp)
                        Spacer(Modifier.size(12.dp))
                        Text(
                            text = subject.name,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { onMove(subject.id, -1) }, enabled = index > 0) {
                            Icon(Icons.Filled.ArrowUpward, contentDescription = stringResource(R.string.cd_move_up))
                        }
                        IconButton(onClick = { onMove(subject.id, 1) }, enabled = index < active.lastIndex) {
                            Icon(Icons.Filled.ArrowDownward, contentDescription = stringResource(R.string.cd_move_down))
                        }
                    }
                }

                SectionLabel(stringResource(R.string.settings_archived_subjects))
                if (archived.isEmpty()) {
                    Text(
                        text = stringResource(R.string.settings_no_archived),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                archived.forEach { subject ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ColorDot(Color(subject.color), size = 12.dp)
                        Spacer(Modifier.size(12.dp))
                        Text(
                            text = subject.name,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { onRestore(subject.id) }) {
                            Text(stringResource(R.string.settings_restore))
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.done)) } }
    )
}

/** The word the user has to type before everything is erased. */
private const val RESET_KEYWORD = "DELETE"

@Composable
fun ResetDialog(onDismiss: () -> Unit, onConfirm: () -> Unit) {
    var typed by remember { mutableStateOf("") }
    val matches = typed.trim() == RESET_KEYWORD
    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.reset_dialog_title)) },
        text = {
            Column {
                Text(
                    text = stringResource(R.string.reset_dialog_message, RESET_KEYWORD),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.size(12.dp))
                OutlinedTextField(
                    value = typed,
                    onValueChange = { typed = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onConfirm, enabled = matches) {
                Text(
                    text = stringResource(R.string.reset_dialog_confirm),
                    color = if (matches) Ui.extra.danger else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun RestoreSummaryDialog(
    summary: BackupSummary,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.backup_restore_title)) },
        text = {
            Column {
                Text(
                    text = stringResource(
                        R.string.backup_restore_summary,
                        summary.subjectsCount.toString(),
                        summary.sessionsCount.toString(),
                        summary.tasksCount.toString()
                    ),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (summary.exportTime > 0L) {
                    Spacer(Modifier.size(4.dp))
                    Text(
                        text = stringResource(
                            R.string.backup_restore_saved_on,
                            DateTimeUtils.formatDate(summary.exportTime)
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.size(12.dp))
                RowDivider()
                Spacer(Modifier.size(12.dp))
                Text(
                    text = stringResource(R.string.backup_warning),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Ui.extra.warning
                )
            }
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text(stringResource(R.string.backup_restore_confirm)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}
