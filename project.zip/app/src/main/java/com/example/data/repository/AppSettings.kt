package com.example.data.repository

import java.util.Calendar

/** Appearance style. Stored by name. Old values are mapped in [normalizeThemeStyle]. */
object ThemeStyleNames {
    const val MINIMAL = "MINIMAL"
    const val SOFT = "SOFT"

    /** MATERIAL (the old default) becomes MINIMAL, the removed NEUMORPHISM becomes SOFT. Anything else falls back to MINIMAL. */
    fun normalize(raw: String?): String = when (raw) {
        SOFT, "NEUMORPHISM" -> SOFT
        else -> MINIMAL
    }
}

object CornerStyleNames {
    const val SHARP = "SHARP"
    const val ROUNDED = "ROUNDED"
    const val PILL = "PILL"

    fun normalize(raw: String?): String = when (raw) {
        SHARP -> SHARP
        PILL -> PILL
        else -> ROUNDED
    }
}

/**
 * One immutable snapshot of every setting. Screens collect THIS instead of 15 separate flows,
 * so a settings write produces one UI update instead of many.
 */
data class AppSettings(
    val dayStartHour: Int = 5,
    val themeMode: String = "SYSTEM",          // SYSTEM, LIGHT, DARK
    val themeStyle: String = ThemeStyleNames.MINIMAL,
    val accentColor: Long = SettingsRepository.DEFAULT_ACCENT_COLOR,
    val amoled: Boolean = false,
    val cornerStyle: String = CornerStyleNames.ROUNDED,
    val language: String = "en",
    val keepScreenOn: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val firstDayOfWeek: Int = Calendar.MONDAY,
    val is12Hour: Boolean = false,
    val defaultTimerMode: String = "COUNTDOWN",
    val pomoFocusMinutes: Int = 25,
    val pomoShortBreakMinutes: Int = 5,
    val pomoLongBreakMinutes: Int = 15,
    val pomoInterval: Int = 4,
    val pomoAutoStart: Boolean = false,
    val countdownSeconds: Long = 1800L,
    val customPresets: List<Int> = listOf(5, 10, 15, 25, 45, 60, 90),
    val selectedSubjectId: Long? = null,
    val timelineZoom: Int = 1,
    val onboardingCompleted: Boolean = false,
    val differentGoalPerWeekday: Boolean = false,
    val studyReminderEnabled: Boolean = false,
    val studyReminderHour: Int = 20,
    val studyReminderMinute: Int = 0,
    val studyReminderDays: Set<Int> = setOf(1, 2, 3, 4, 5, 6, 7),
    val breakReminderEnabled: Boolean = true,
    val breakReminderMinutes: Int = 90,
    val autoBackupReminderEnabled: Boolean = false,
    val autoBackupReminderDays: Int = 7,
    val lastBackupTime: Long = 0L,
    /** Scheduled backup into a folder the user picked (can be a Google Drive folder via the system picker). */
    val autoBackupEnabled: Boolean = false,
    val autoBackupFolderUri: String = "",
    val autoBackupFolderName: String = "",
    val autoBackupIntervalDays: Int = 1,
    val autoBackupKeep: Int = 7,
    val autoBackupLastSuccess: Long = 0L,
    val autoBackupLastAttempt: Long = 0L,
    val autoBackupLastError: String = "",
    val ambientMode: Boolean = false,
    val dndPromptEnabled: Boolean = false,
    val screenPinningExplained: Boolean = false
)
