package com.example.receiver

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.StudyApplication
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Schedules the two local alarms: the daily study reminder and the daily "is a backup due?" check.
 * Both use inexact alarms (no SCHEDULE_EXACT_ALARM permission needed) and are re-armed every time they
 * fire, after a reboot and after the app is updated (an update cancels all alarms).
 */
object ReminderScheduler {
    const val REQUEST_CODE_STUDY_REMINDER = 2001
    const val REQUEST_CODE_BACKUP_CHECK = 2002

    /** The hour of day when the backup check runs. */
    private const val BACKUP_CHECK_HOUR = 10

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** The next time (ms) at [hour]:[minute] that falls on one of [daysSet] (Calendar.SUNDAY=1..SATURDAY=7). */
    fun getNextTriggerMillis(hour: Int, minute: Int, daysSet: Set<Int>, nowMs: Long = System.currentTimeMillis()): Long? {
        if (daysSet.isEmpty()) return null
        val candidate = Calendar.getInstance().apply {
            timeInMillis = nowMs
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (candidate.timeInMillis <= nowMs) {
            candidate.add(Calendar.DAY_OF_YEAR, 1)
        }
        for (i in 0..7) {
            if (daysSet.contains(candidate.get(Calendar.DAY_OF_WEEK))) {
                return candidate.timeInMillis
            }
            candidate.add(Calendar.DAY_OF_YEAR, 1)
        }
        return null
    }

    private fun pendingFor(context: Context, requestCode: Int, action: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply { this.action = action }
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun arm(context: Context, triggerAtMs: Long, pending: PendingIntent) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pending)
        } catch (_: Exception) {
            // An alarm that cannot be set must never crash the app.
        }
    }

    private fun disarm(context: Context, pending: PendingIntent) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pending)
        } catch (_: Exception) {
        }
    }

    suspend fun scheduleNext(context: Context, settingsRepo: SettingsRepository) {
        val s = settingsRepo.settings.first()
        val pending = pendingFor(context, REQUEST_CODE_STUDY_REMINDER, ReminderReceiver.ACTION_STUDY_REMINDER)
        if (!s.studyReminderEnabled || s.studyReminderDays.isEmpty()) {
            disarm(context, pending)
            return
        }
        val triggerAtMs = getNextTriggerMillis(s.studyReminderHour, s.studyReminderMinute, s.studyReminderDays)
        if (triggerAtMs != null) arm(context, triggerAtMs, pending)
    }

    suspend fun scheduleBackupCheck(context: Context, settingsRepo: SettingsRepository) {
        val s = settingsRepo.settings.first()
        val pending = pendingFor(context, REQUEST_CODE_BACKUP_CHECK, ReminderReceiver.ACTION_BACKUP_CHECK)
        if (!s.autoBackupReminderEnabled) {
            disarm(context, pending)
            return
        }
        val triggerAtMs = getNextTriggerMillis(BACKUP_CHECK_HOUR, 0, setOf(1, 2, 3, 4, 5, 6, 7))
        if (triggerAtMs != null) arm(context, triggerAtMs, pending)
    }

    suspend fun scheduleAll(context: Context, settingsRepo: SettingsRepository) {
        scheduleNext(context, settingsRepo)
        scheduleBackupCheck(context, settingsRepo)
    }

    /** Fire-and-forget re-arm of every alarm. Safe to call from anywhere. */
    fun rescheduleAll(context: Context) {
        val appContext = context.applicationContext
        val app = appContext as? StudyApplication ?: return
        scope.launch {
            try {
                scheduleAll(appContext, app.settingsRepository)
            } catch (_: Exception) {
            }
        }
    }
}
