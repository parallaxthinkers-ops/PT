package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.util.LocaleHelper

object NotificationHelper {
    const val CHANNEL_TIMER = "studylocal_timer_channel"
    const val CHANNEL_COMPLETION = "studylocal_completion_channel"
    const val CHANNEL_REMINDERS = "studylocal_reminders_channel"
    const val CHANNEL_FOCUS = "studylocal_focus_channel"

    const val NOTIFICATION_ID_TIMER = 1001
    const val NOTIFICATION_ID_COMPLETION = 1002
    const val NOTIFICATION_ID_FOCUS_LEFT = 1003
    const val NOTIFICATION_ID_BREAK_REMINDER = 1004
    const val NOTIFICATION_ID_GOAL = 1005
    const val NOTIFICATION_ID_STUDY_REMINDER = 1006
    const val NOTIFICATION_ID_BACKUP_REMINDER = 1007

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val text = LocaleHelper.localized(context)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val timerChannel = NotificationChannel(
            CHANNEL_TIMER,
            text.getString(R.string.channel_timer_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = text.getString(R.string.channel_timer_desc)
            setShowBadge(false)
        }

        val completionChannel = NotificationChannel(
            CHANNEL_COMPLETION,
            text.getString(R.string.channel_completion_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = text.getString(R.string.channel_completion_desc)
            // Sound and vibration are played by the service so the in-app toggles are respected.
            setSound(null, null)
            enableVibration(false)
        }

        val remindersChannel = NotificationChannel(
            CHANNEL_REMINDERS,
            text.getString(R.string.channel_reminders_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = text.getString(R.string.channel_reminders_desc)
            enableVibration(true)
        }

        val focusChannel = NotificationChannel(
            CHANNEL_FOCUS,
            text.getString(R.string.channel_focus_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = text.getString(R.string.channel_focus_desc)
            enableVibration(true)
        }

        manager.createNotificationChannels(
            listOf(timerChannel, completionChannel, remindersChannel, focusChannel)
        )
    }

    fun appPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun notifySafely(context: Context, id: Int, build: (Context) -> android.app.Notification) {
        try {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(id, build(LocaleHelper.localized(context)))
        } catch (_: Exception) {
            // Notifications can be blocked (permission denied). Never crash because of that.
        }
    }

    fun showCompletionNotification(context: Context, title: String, message: String) {
        notifySafely(context, NOTIFICATION_ID_COMPLETION) {
            NotificationCompat.Builder(context, CHANNEL_COMPLETION)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(R.drawable.ic_notification_small)
                .setContentIntent(appPendingIntent(context))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .build()
        }
    }

    /** A quiet "session saved" note: no sound, no vibration, no pop-up. */
    fun showSilentSessionSavedNotification(context: Context, title: String, message: String) {
        notifySafely(context, NOTIFICATION_ID_COMPLETION) {
            NotificationCompat.Builder(context, CHANNEL_COMPLETION)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(R.drawable.ic_notification_small)
                .setContentIntent(appPendingIntent(context))
                .setAutoCancel(true)
                .setSilent(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .build()
        }
    }

    fun showFocusLeftNotification(context: Context) {
        notifySafely(context, NOTIFICATION_ID_FOCUS_LEFT) { text ->
            NotificationCompat.Builder(context, CHANNEL_FOCUS)
                .setContentTitle(text.getString(R.string.focus_left_notification_title))
                .setContentText(text.getString(R.string.focus_left_notification_desc))
                .setSmallIcon(R.drawable.ic_notification_small)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(appPendingIntent(context))
                .build()
        }
    }

    fun showBreakReminderNotification(context: Context, minutes: Int) {
        notifySafely(context, NOTIFICATION_ID_BREAK_REMINDER) { text ->
            NotificationCompat.Builder(context, CHANNEL_REMINDERS)
                .setContentTitle(text.getString(R.string.break_reminder_notice_title))
                .setContentText(text.getString(R.string.break_reminder_notice_message, minutes))
                .setSmallIcon(R.drawable.ic_notification_small)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(appPendingIntent(context))
                .build()
        }
    }

    fun showGoalAlmostReachedNotification(context: Context) {
        notifySafely(context, NOTIFICATION_ID_GOAL) { text ->
            NotificationCompat.Builder(context, CHANNEL_REMINDERS)
                .setContentTitle(text.getString(R.string.goal_almost_reached_title))
                .setContentText(text.getString(R.string.goal_almost_reached_message))
                .setSmallIcon(R.drawable.ic_notification_small)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(appPendingIntent(context))
                .build()
        }
    }

    fun showGoalAchievedNotification(context: Context) {
        notifySafely(context, NOTIFICATION_ID_GOAL) { text ->
            NotificationCompat.Builder(context, CHANNEL_REMINDERS)
                .setContentTitle(text.getString(R.string.notif_goal_done_title))
                .setContentText(text.getString(R.string.notif_goal_done_msg))
                .setSmallIcon(R.drawable.ic_notification_small)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(appPendingIntent(context))
                .build()
        }
    }

    fun showStudyReminderNotification(context: Context) {
        notifySafely(context, NOTIFICATION_ID_STUDY_REMINDER) { text ->
            NotificationCompat.Builder(context, CHANNEL_REMINDERS)
                .setContentTitle(text.getString(R.string.notif_study_reminder_title))
                .setContentText(text.getString(R.string.notif_study_reminder_msg))
                .setSmallIcon(R.drawable.ic_notification_small)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setAutoCancel(true)
                .setContentIntent(appPendingIntent(context))
                .build()
        }
    }

    /** [daysSinceBackup] = null means the user has never exported a backup. */
    fun showBackupReminderNotification(context: Context, daysSinceBackup: Int?) {
        notifySafely(context, NOTIFICATION_ID_BACKUP_REMINDER) { text ->
            val message = if (daysSinceBackup == null) {
                text.getString(R.string.notif_backup_never_msg)
            } else {
                text.getString(R.string.notif_backup_msg, daysSinceBackup)
            }
            NotificationCompat.Builder(context, CHANNEL_REMINDERS)
                .setContentTitle(text.getString(R.string.notif_backup_title))
                .setContentText(message)
                .setSmallIcon(R.drawable.ic_notification_small)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(appPendingIntent(context))
                .build()
        }
    }

    /** The scheduled backup could not write into the chosen folder (deleted, permission lost, signed out of Drive). */
    fun showAutoBackupFailedNotification(context: Context) {
        notifySafely(context, NOTIFICATION_ID_BACKUP_REMINDER) { text ->
            NotificationCompat.Builder(context, CHANNEL_REMINDERS)
                .setContentTitle(text.getString(R.string.notif_autobackup_failed_title))
                .setContentText(text.getString(R.string.notif_autobackup_failed_msg))
                .setStyle(NotificationCompat.BigTextStyle().bigText(text.getString(R.string.notif_autobackup_failed_msg)))
                .setSmallIcon(R.drawable.ic_notification_small)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(appPendingIntent(context))
                .build()
        }
    }
}
