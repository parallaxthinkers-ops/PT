package com.example.ui.components

import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.example.R
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/**
 * Date picker that lives inside the Compose window. Material's picker works in UTC midnight milliseconds,
 * so the conversion to and from a plain [LocalDate] happens here and callers never see UTC.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDatePickerDialog(
    initial: LocalDate,
    onDismiss: () -> Unit,
    onConfirm: (LocalDate) -> Unit
) {
    val state = rememberDatePickerState(
        initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    )
    // Deliberately NOT see-through: Material paints the year list with the picker's colour to hide the calendar under it,
    // so a see-through picker would show the year grid on top of the month grid.
    // The fill stays solid, but it gets the same glass edge and highlight as every other pop-up.
    DatePickerDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.glassEdge(DatePickerDefaults.shape, rememberGlassLook()),
        confirmButton = {
            TextButton(
                onClick = {
                    val picked = state.selectedDateMillis
                    if (picked != null) {
                        onConfirm(Instant.ofEpochMilli(picked).atZone(ZoneOffset.UTC).toLocalDate())
                    } else {
                        onDismiss()
                    }
                }
            ) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    ) {
        DatePicker(state = state)
    }
}
