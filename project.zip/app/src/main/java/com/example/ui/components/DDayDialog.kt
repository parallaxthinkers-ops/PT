package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.DDay
import com.example.ui.theme.SubjectColors
import com.example.util.DateTimeUtils
import java.time.Instant
import java.time.ZoneId

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditDDayDialog(
    initialDDay: DDay? = null,
    onDismiss: () -> Unit,
    onSave: (title: String, targetDateMs: Long, countUp: Boolean, isPinned: Boolean, color: Long) -> Unit
) {
    var title by remember { mutableStateOf(initialDDay?.title ?: "") }
    var countUp by remember { mutableStateOf(initialDDay?.countUp ?: false) }
    var isPinned by remember { mutableStateOf(initialDDay?.isPinned ?: true) }
    var color by remember { mutableLongStateOf(initialDDay?.color ?: SubjectColors.first()) }
    var targetDateMs by remember {
        mutableLongStateOf(
            initialDDay?.targetDate
                ?: DDay.midnightMs(Instant.now().atZone(ZoneId.systemDefault()).toLocalDate().plusDays(30))
        )
    }
    var isError by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }

    AppAlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(stringResource(if (initialDDay == null) R.string.add_dday else R.string.dday_edit))
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it.take(60)
                        isError = it.isBlank()
                    },
                    label = { Text(stringResource(R.string.dday_name_label)) },
                    placeholder = { Text(stringResource(R.string.dday_name_hint)) },
                    isError = isError,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dday_title_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(stringResource(R.string.target_date), style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedButton(
                    onClick = { showDatePicker = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Filled.CalendarMonth, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(DateTimeUtils.formatDate(targetDateMs))
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(stringResource(R.string.dday_color), style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    SubjectColors.forEach { value ->
                        val selected = value == color
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(Color(value))
                                .border(
                                    width = if (selected) 3.dp else 0.dp,
                                    color = if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable { color = value }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { countUp = !countUp }
                ) {
                    Checkbox(checked = countUp, onCheckedChange = { countUp = it })
                    Text(
                        text = stringResource(R.string.dday_count_up_option),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isPinned = !isPinned }
                ) {
                    Checkbox(checked = isPinned, onCheckedChange = { isPinned = it })
                    Text(
                        text = stringResource(R.string.dday_pin_option),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(title.trim(), targetDateMs, countUp, isPinned, color)
                    } else {
                        isError = true
                    }
                },
                modifier = Modifier.testTag("save_dday_button")
            ) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )

    if (showDatePicker) {
        AppDatePickerDialog(
            initial = Instant.ofEpochMilli(targetDateMs).atZone(ZoneId.systemDefault()).toLocalDate(),
            onDismiss = { showDatePicker = false },
            onConfirm = { date ->
                targetDateMs = DDay.midnightMs(date)
                showDatePicker = false
            }
        )
    }
}
