package com.example.util

import com.example.data.model.StudySession
import java.time.DayOfWeek
import java.time.LocalDate

/**
 * Pure study-time maths (no Android, easy to unit test).
 * Daily totals are bucketed ONCE per list of sessions so the screens never re-filter the full history.
 */
object StudyMath {

    /** Calendar.SUNDAY (1) .. Calendar.SATURDAY (7), the weekday numbering used by the Goal table. */
    fun calendarWeekday(date: LocalDate): Int = (date.dayOfWeek.value % 7) + 1

    fun calendarWeekday(day: DayOfWeek): Int = (day.value % 7) + 1

    /**
     * Seconds studied per study-day date. A session that crosses a day-start boundary is split across
     * the study days it touches, so the total of all buckets equals the total of all sessions.
     */
    fun secondsPerStudyDay(sessions: List<StudySession>, dayStartHour: Int): Map<LocalDate, Long> {
        val result = HashMap<LocalDate, Long>()
        for (s in sessions) {
            if (s.endTime <= s.startTime) continue
            var cursor = s.startTime
            var guard = 0
            while (cursor < s.endTime && guard < 400) {
                val date = DateTimeUtils.studyDateOf(cursor, dayStartHour)
                val (_, dayEnd) = DateTimeUtils.studyDayRangeForDate(date, dayStartHour)
                val sliceEnd = minOf(s.endTime, dayEnd)
                val millis = sliceEnd - cursor
                if (millis > 0) {
                    result[date] = (result[date] ?: 0L) + millis / 1000L
                }
                if (sliceEnd <= cursor) break
                cursor = sliceEnd
                guard++
            }
        }
        return result
    }

    /**
     * Consecutive study days ending at [today] (or at yesterday if today's goal is not met yet)
     * on which the goal was reached. [todayLiveSeconds] is time still running in the timer.
     * Days with a goal of 0 minutes never count.
     */
    fun streak(
        secondsByDay: Map<LocalDate, Long>,
        goalSecondsFor: (LocalDate) -> Long,
        today: LocalDate,
        todayLiveSeconds: Long = 0L,
        maxDays: Int = 366
    ): Int {
        var streak = 0
        for (daysAgo in 0 until maxDays) {
            val date = today.minusDays(daysAgo.toLong())
            val goal = goalSecondsFor(date)
            val total = (secondsByDay[date] ?: 0L) + if (daysAgo == 0) todayLiveSeconds else 0L
            val met = goal > 0 && total >= goal
            if (met) {
                streak++
            } else if (daysAgo != 0) {
                break
            }
        }
        return streak
    }
}
