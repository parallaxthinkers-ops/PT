package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.Goal
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals")
    fun getAllGoalsFlow(): Flow<List<Goal>>

    @Query("SELECT * FROM goals")
    suspend fun getAllGoalsList(): List<Goal>

    @Query("SELECT * FROM goals WHERE weekday = :weekday LIMIT 1")
    fun getGoalForWeekdayFlow(weekday: Int): Flow<Goal?>

    @Query("SELECT * FROM goals WHERE weekday = :weekday LIMIT 1")
    suspend fun getGoalForWeekday(weekday: Int): Goal?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(goal: Goal)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(goals: List<Goal>)

    @Query("DELETE FROM goals")
    suspend fun deleteAll()
}
