package com.example

import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.repository.AppSettings
import com.example.service.SessionRecovery
import com.example.service.TimerForegroundService
import com.example.service.TimerStateManager
import com.example.service.TimerStatus
import com.example.ui.StudyMainScreen
import com.example.ui.theme.ParallaxTrackerTheme
import com.example.ui.theme.ThemeLayout
import com.example.ui.theme.ThemeStyle
import com.example.util.CrashReporter
import com.example.util.LocaleHelper
import com.example.util.LocalizedContextWrapper
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var showingCrashReport = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If the last run crashed, show the report instead of starting normally.
        val crash = CrashReporter.pending(this)
        if (crash != null) {
            showingCrashReport = true
            CrashReporter.show(this, crash) { recreate() }
            return
        }

        val app = application as StudyApplication

        setContent {
            val settings by app.settingsRepository.settings.collectAsStateWithLifecycle(initialValue = AppSettings())

            val isDark = when (settings.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            // Status/navigation bar icons follow the app theme, not only the phone theme.
            DisposableEffect(isDark) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT) { isDark },
                    navigationBarStyle = SystemBarStyle.auto(
                        AndroidColor.argb(0xe6, 0xFF, 0xFF, 0xFF),
                        AndroidColor.argb(0x80, 0x1b, 0x1b, 0x1b)
                    ) { isDark }
                )
                onDispose { }
            }

            // Keep the screen on only when the user wants it AND a timer is actually running.
            val timerStatus by remember {
                TimerStateManager.timerState.map { it.status }.distinctUntilChanged()
            }.collectAsStateWithLifecycle(initialValue = TimerStatus.STOPPED)
            val keepOn = settings.keepScreenOn && timerStatus == TimerStatus.RUNNING
            LaunchedEffect(keepOn) {
                if (keepOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            // The app language is applied by wrapping the configuration and context.
            val language = settings.language
            // Set synchronously: formatters that run during THIS composition (dates, weekday names) must
            // already see the new language, not the previous one.
            val locale = remember(language) {
                LocaleHelper.localeFor(language).also { Locale.setDefault(it) }
            }
            LaunchedEffect(language) { LocaleHelper.save(this@MainActivity, language) }
            val baseConfiguration = LocalConfiguration.current
            val baseContext = LocalContext.current
            val localizedConfiguration = remember(baseConfiguration, locale) {
                Configuration(baseConfiguration).apply {
                    setLocale(locale)
                    setLayoutDirection(locale)
                }
            }
            // A wrapper, not createConfigurationContext(): the result must still lead back to the Activity.
            val localizedContext = remember(baseContext, localizedConfiguration) {
                LocalizedContextWrapper(
                    baseContext,
                    baseContext.createConfigurationContext(localizedConfiguration).resources
                )
            }

            CompositionLocalProvider(
                LocalConfiguration provides localizedConfiguration,
                LocalContext provides localizedContext,
                androidx.activity.compose.LocalActivityResultRegistryOwner provides this,
                androidx.activity.compose.LocalOnBackPressedDispatcherOwner provides this
            ) {
                ParallaxTrackerTheme(
                    darkTheme = isDark,
                    themeStyle = ThemeStyle.fromName(settings.themeStyle),
                    accentColor = Color(settings.accentColor),
                    amoled = settings.amoled,
                    cornerStyle = settings.cornerStyle,
                    preset = settings.themePreset,
                    accentCustom = settings.themeAccentCustom,
                    gradient = settings.themeGradient,
                    font = settings.themeFont,
                    ring = settings.themeRing,
                    layout = ThemeLayout.fromName(settings.themeLayout)
                ) {
                    StudyMainScreen(app = app)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (showingCrashReport) return
        resumeTimerIfNeeded()
    }

    /**
     * If the process was killed while a timer ran, the state was restored in the Application. Starting the
     * foreground service from the background can be refused on Android 12+, so it is retried here, where
     * the app is visible and the start is always allowed.
     */
    private fun resumeTimerIfNeeded() {
        try {
            SessionRecovery.restoreStateOnly(this)
            if (TimerStateManager.timerState.value.status != TimerStatus.STOPPED) {
                TimerForegroundService.restoreRunningTimer(this)
            }
        } catch (_: Exception) {
        }
    }
}
