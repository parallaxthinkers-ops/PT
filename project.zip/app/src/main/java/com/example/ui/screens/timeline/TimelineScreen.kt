package com.example.ui.screens.timeline

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.StudySession
import com.example.ui.components.AppCard
import com.example.ui.components.AppDatePickerDialog
import com.example.ui.components.ColorDot
import com.example.ui.components.GlassChip
import com.example.ui.components.GlassProgressBar
import com.example.ui.components.glassAccentEdge
import com.example.ui.components.glassEdge
import com.example.ui.components.rememberGlassLook
import com.example.ui.components.DayNavigator
import com.example.ui.components.EmptyState
import com.example.ui.components.ManualSessionDialog
import com.example.ui.components.PillSelector
import com.example.ui.components.RowDivider
import com.example.ui.components.ScreenHeader
import com.example.ui.components.SectionLabel
import com.example.ui.theme.NumberStyle
import com.example.ui.theme.Ui
import com.example.util.DateTimeUtils
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId

private enum class TimelineView { TIMETABLE, LIST }

private val SlateGrey = Color(0xFF64748B)

/** Height of one hour on the timetable for each zoom level. */
private fun hourHeightFor(zoom: Int): Dp = when (zoom) {
    0 -> 52.dp
    2 -> 112.dp
    else -> 76.dp
}

/** A block is never drawn shorter than this, so a 1 minute session is still a visible, tappable target. */
private val MinBlockHeight = 24.dp

/** Narrowest a column of side-by-side blocks may get: wide enough for a short subject name. */
private val MinColumnWidth = 76.dp

private const val HOUR_MS = 3_600_000L

@Composable
fun TimelineScreen(
    viewModel: TimelineViewModel,
    modifier: Modifier = Modifier
) {
    val ui by viewModel.uiState.collectAsStateWithLifecycle()

    // The subject filter always starts on "All" when this screen opens.
    LaunchedEffect(Unit) { viewModel.resetFilter() }

    var showAddDialog by remember { mutableStateOf(false) }
    var editingSession by remember { mutableStateOf<StudySession?>(null) }
    var view by remember { mutableStateOf(TimelineView.TIMETABLE) }

    var showDatePicker by remember { mutableStateOf(false) }
    val openDatePicker: () -> Unit = { showDatePicker = true }
    val viewLabels = mapOf(
        TimelineView.TIMETABLE to stringResource(R.string.timeline_view_timetable),
        TimelineView.LIST to stringResource(R.string.timeline_view_list)
    )

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = stringResource(R.string.timeline_title),
            trailing = {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = stringResource(R.string.timeline_total_short),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = DateTimeUtils.formatDurationShort(ui.totalStudyMillis / 1000L),
                        style = NumberStyle.copy(fontSize = 18.sp),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.testTag("timeline_day_total")
                    )
                }
                Spacer(Modifier.width(8.dp))
                IconButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.testTag("add_session_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = stringResource(R.string.add_session))
                }
            }
        )

        DayNavigator(
            testTagPrefix = "timeline",
            dateMs = ui.currentDayStartMs,
            isToday = ui.isToday,
            onPrev = { viewModel.prevDay() },
            onNext = { viewModel.nextDay() },
            onToday = { viewModel.goToToday() },
            onPick = openDatePicker
        )

        Spacer(Modifier.height(10.dp))

        FilterRow(ui = ui, onSelect = { viewModel.selectSubjectFilter(it) })

        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PillSelector(
                options = TimelineView.values().toList(),
                selected = view,
                label = { viewLabels[it] ?: "" },
                onSelect = { view = it },
                modifier = Modifier.width(210.dp)
            )
            Spacer(Modifier.weight(1f))
            if (view == TimelineView.TIMETABLE) {
                PillSelector(
                    options = listOf(0, 1, 2),
                    selected = ui.zoom,
                    label = { "${it + 1}×" },
                    onSelect = { viewModel.setZoom(it) },
                    modifier = Modifier.width(132.dp)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        if (ui.sessions.isEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.timeline_no_records),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.testTag("empty_timeline_add_button")
                ) {
                    Text(stringResource(R.string.add_session), fontWeight = FontWeight.SemiBold)
                }
            }
        }

        when (view) {
            TimelineView.TIMETABLE -> Timetable(
                ui = ui,
                onSessionClick = { editingSession = it },
                modifier = Modifier.weight(1f)
            )
            TimelineView.LIST -> SessionListView(
                ui = ui,
                onSessionClick = { editingSession = it },
                modifier = Modifier.weight(1f)
            )
        }
    }

    if (showDatePicker) {
        val zone = ZoneId.systemDefault()
        AppDatePickerDialog(
            initial = Instant.ofEpochMilli(ui.currentDayStartMs).atZone(zone).toLocalDate(),
            onDismiss = { showDatePicker = false },
            onConfirm = { date ->
                // Jump to the START of the picked study day, so the right study day is always selected.
                val picked = date.atTime(ui.dayStartHour, 0).atZone(zone).toInstant().toEpochMilli()
                viewModel.selectDate(picked)
                showDatePicker = false
            }
        )
    }

    if (showAddDialog) {
        ManualSessionDialog(
            baseDayMs = ui.currentDayStartMs,
            subjects = ui.subjects,
            existingSessions = ui.rawSessions,
            dayStartHour = ui.dayStartHour,
            is12Hour = ui.is12Hour,
            onDismiss = { showAddDialog = false },
            onSave = { subjectId, startMs, endMs ->
                viewModel.addManualSession(subjectId, startMs, endMs)
                showAddDialog = false
            }
        )
    }

    editingSession?.let { session ->
        ManualSessionDialog(
            initialSession = session,
            baseDayMs = ui.currentDayStartMs,
            subjects = ui.subjects,
            existingSessions = ui.rawSessions,
            dayStartHour = ui.dayStartHour,
            is12Hour = ui.is12Hour,
            onDismiss = { editingSession = null },
            onSave = { subjectId, startMs, endMs ->
                viewModel.updateSession(session.copy(subjectId = subjectId, startTime = startMs, endTime = endMs))
                editingSession = null
            },
            onDelete = {
                viewModel.deleteSession(session)
                editingSession = null
            }
        )
    }
}

// =================================================================================================
// Top controls
// =================================================================================================

@Composable
private fun FilterRow(ui: TimelineUiState, onSelect: (Long?) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FilterPill(
            label = stringResource(R.string.timeline_all_subjects),
            color = null,
            selected = ui.selectedSubjectFilter == null,
            onClick = { onSelect(null) },
            modifier = Modifier.testTag("timeline_filter_all_subjects")
        )
        ui.subjects.forEach { subject ->
            FilterPill(
                label = subject.name,
                color = Color(subject.color),
                selected = ui.selectedSubjectFilter == subject.id,
                onClick = { onSelect(subject.id) },
                modifier = Modifier.testTag("timeline_filter_subject_${subject.id}")
            )
        }
    }
}

@Composable
private fun FilterPill(
    label: String,
    color: Color?,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassChip(label = label, selected = selected, onClick = onClick, modifier = modifier, dotColor = color)
}

// =================================================================================================
// Timetable
// =================================================================================================

@Composable
private fun Timetable(
    ui: TimelineUiState,
    onSessionClick: (StudySession) -> Unit,
    modifier: Modifier = Modifier
) {
    val hourHeight = hourHeightFor(ui.zoom)
    val totalHeight = hourHeight * 24
    val scroll = rememberScrollState()
    val hScroll = rememberScrollState()
    val density = LocalDensity.current

    // Blocks are laid out on their DRAWN size. This is what makes short sessions show up correctly.
    val minDurationMs = (MinBlockHeight.value / hourHeight.value * HOUR_MS).toLong()
    val layouts = remember(ui.sessions, minDurationMs) {
        TimelineViewModel.computeTimelineLayouts(ui.sessions, minDurationMs)
    }

    // On opening a day (or changing zoom), scroll to the first session, else to "now" on today.
    val firstStart = ui.sessions.firstOrNull()?.effectiveStartMs
    LaunchedEffect(ui.currentDayStartMs, ui.zoom, firstStart == null) {
        val anchorMs = when {
            firstStart != null -> firstStart - ui.currentDayStartMs
            ui.isToday -> System.currentTimeMillis() - ui.currentDayStartMs - 2 * HOUR_MS
            else -> 0L
        }.coerceAtLeast(0L)
        val targetDp = hourHeight * (anchorMs / HOUR_MS.toFloat()) - 16.dp
        val px = with(density) { targetDp.coerceAtLeast(0.dp).roundToPx() }
        scroll.scrollTo(px)
    }

    Box(modifier = modifier.fillMaxWidth().verticalScroll(scroll)) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(totalHeight)
                .padding(horizontal = 20.dp)
                .testTag("timeline_timetable_container")
        ) {
            val labelWidth = 46.dp
            val available = (maxWidth - labelWidth).coerceAtLeast(0.dp)

            // Hour grid
            Column(modifier = Modifier.fillMaxSize()) {
                for (hourOffset in 0 until 24) {
                    val actualHour = (ui.dayStartHour + hourOffset) % 24
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(hourHeight),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = DateTimeUtils.formatHourLabel(actualHour, ui.is12Hour),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(labelWidth)
                        )
                        HorizontalDivider(
                            color = Ui.extra.hairline,
                            modifier = Modifier.padding(top = 7.dp)
                        )
                    }
                }
            }

            // Session blocks. A column is never narrower than MinColumnWidth, so even ten 1-minute sessions
            // in the same minute stay readable. When they do not fit, this layer scrolls sideways
            // (the hour labels and the grid stay in place).
            val columnWidthFor = { cols: Int -> maxOf(available / maxOf(cols, 1), MinColumnWidth) }
            var contentWidth = available
            layouts.forEach { l ->
                val w = columnWidthFor(l.totalCols) * l.totalCols
                if (w > contentWidth) contentWidth = w
            }

            Box(
                modifier = Modifier
                    .offset(x = labelWidth)
                    .width(available)
                    .height(totalHeight)
                    .horizontalScroll(hScroll)
            ) {
                Box(modifier = Modifier.width(contentWidth).height(totalHeight)) {
                    layouts.forEach { layout ->
                        val item = layout.sessionWithSubject
                        val subject = item.subject
                        val archived = subject?.isArchived == true
                        val color = if (subject == null || archived) SlateGrey else Color(subject.color)
                        val name = when {
                            subject == null -> stringResource(R.string.timeline_unknown_subject)
                            archived -> subject.name + " " + stringResource(R.string.timeline_deleted_suffix)
                            else -> subject.name
                        }

                        val top = hourHeight * ((item.effectiveStartMs - ui.currentDayStartMs) / HOUR_MS.toFloat())
                        val realHeight = hourHeight * ((item.effectiveEndMs - item.effectiveStartMs) / HOUR_MS.toFloat())
                        val wantedHeight = if (realHeight < MinBlockHeight) MinBlockHeight else realHeight
                        val room = (totalHeight - top).coerceAtLeast(MinBlockHeight)
                        val blockHeight = if (wantedHeight > room) room else wantedHeight

                        val cols = maxOf(layout.totalCols, 1)
                        val colWidth = columnWidthFor(cols)
                        val gap = if (cols > 1) 2.dp else 0.dp
                        val blockWidth = (colWidth - gap).coerceAtLeast(10.dp)

                        SessionBlock(
                            name = name,
                            color = color,
                            timeText = DateTimeUtils.formatTime(item.effectiveStartMs, ui.is12Hour) + " – " +
                                DateTimeUtils.formatTime(item.effectiveEndMs, ui.is12Hour),
                            durationText = DateTimeUtils.formatDurationShort(item.effectiveDurationSeconds),
                            width = blockWidth,
                            height = blockHeight - 1.dp,
                            modifier = Modifier
                                .offset(x = colWidth * layout.colIndex, y = top)
                                .clickable { onSessionClick(item.session) }
                                .testTag("timeline_session_block_${item.session.id}")
                        )
                    }
                }
            }

            if (ui.isToday) {
                NowLine(dayStartMs = ui.currentDayStartMs, hourHeight = hourHeight, leftOffset = labelWidth - 4.dp)
            }
        }
    }
}

/**
 * One block. What is written inside depends on the room it has, so tiny blocks never show clipped,
 * overlapping text. Anything that does not fit is still available in the List view and by tapping.
 */
@Composable
private fun SessionBlock(
    name: String,
    color: Color,
    timeText: String,
    durationText: String,
    width: Dp,
    height: Dp,
    modifier: Modifier = Modifier
) {
    val shape = MaterialTheme.shapes.small
    val look = rememberGlassLook()
    // Glass block: an opaque base first (so the hour lines do not show through the block), then the subject tint,
    // with the thin glass edge in the subject colour.
    Box(
        modifier = modifier
            .width(width)
            .height(height)
            .glassEdge(shape, look, edge = glassAccentEdge(color))
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .background(color.copy(alpha = 0.22f))
    ) {
        Box(
            modifier = Modifier
                .width(4.dp)
                .fillMaxHeight()
                .background(color)
        )
        val canShowText = width >= 40.dp
        if (canShowText) {
            val twoLines = height >= 40.dp
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 10.dp, end = 4.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (twoLines) name else "$name · $durationText",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (twoLines) {
                    Text(
                        text = if (width >= 150.dp) "$durationText · $timeText" else durationText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/** The red "now" line. Only this small composable re-reads the clock, once every 30 seconds. */
@Composable
private fun NowLine(dayStartMs: Long, hourHeight: Dp, leftOffset: Dp) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000L)
            now = System.currentTimeMillis()
        }
    }
    val sinceStart = now - dayStartMs
    if (sinceStart in 0L..(24 * HOUR_MS)) {
        val y = hourHeight * (sinceStart / HOUR_MS.toFloat()) - 4.dp
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .offset(x = leftOffset, y = y),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.error)
            )
            HorizontalDivider(color = MaterialTheme.colorScheme.error, thickness = 1.5.dp)
        }
    }
}

// =================================================================================================
// List view
// =================================================================================================

@Composable
private fun SessionListView(
    ui: TimelineUiState,
    onSessionClick: (StudySession) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 24.dp)
    ) {
        if (ui.sessions.isEmpty() && ui.subjectTotals.isEmpty()) {
            EmptyState(
                icon = Icons.Outlined.History,
                title = stringResource(R.string.timeline_no_records),
                message = stringResource(R.string.timeline_no_records_hint)
            )
            return@Column
        }

        if (ui.subjectTotals.isNotEmpty()) {
            SectionLabel(stringResource(R.string.timeline_subject_breakdown))
            AppCard(modifier = Modifier.fillMaxWidth()) {
                // One stacked bar for the whole day.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(MaterialTheme.shapes.extraSmall),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    ui.subjectTotals.forEach { item ->
                        Box(
                            modifier = Modifier
                                .weight(item.totalSeconds.toFloat().coerceAtLeast(1f))
                                .fillMaxHeight()
                                .background(Color(item.subject.color))
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                ui.subjectTotals.forEachIndexed { index, item ->
                    if (index > 0) Spacer(Modifier.height(12.dp))
                    SubjectTotalRow(item)
                }
            }
        }

        if (ui.sessions.isNotEmpty()) {
            SectionLabel(stringResource(R.string.timeline_sessions_title))
            AppCard(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                ui.sessions.forEachIndexed { index, item ->
                    if (index > 0) RowDivider(Modifier.padding(horizontal = 16.dp))
                    SessionRow(item = item, is12Hour = ui.is12Hour, onClick = { onSessionClick(item.session) })
                }
            }
        }
    }
}

@Composable
private fun SubjectTotalRow(item: TimelineSubjectTotal) {
    val color = Color(item.subject.color)
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ColorDot(color = color, size = 10.dp)
            Spacer(Modifier.width(8.dp))
            Text(
                text = item.subject.name,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = stringResource(R.string.timeline_sessions_count, item.sessionCount),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = DateTimeUtils.formatDurationShort(item.totalSeconds),
                style = NumberStyle.copy(fontSize = 14.sp),
                color = color
            )
        }
        Spacer(Modifier.height(6.dp))
        GlassProgressBar(progress = item.percentage, color = color, barHeight = 5.dp)
    }
}

@Composable
private fun SessionRow(item: SessionWithSubject, is12Hour: Boolean, onClick: () -> Unit) {
    val subject = item.subject
    val archived = subject?.isArchived == true
    val color = if (subject == null || archived) SlateGrey else Color(subject.color)
    val name = when {
        subject == null -> stringResource(R.string.timeline_unknown_subject)
        archived -> subject.name + " " + stringResource(R.string.timeline_deleted_suffix)
        else -> subject.name
    }
    val modeLabel = when (item.session.mode) {
        "STOPWATCH" -> stringResource(R.string.mode_stopwatch)
        "COUNTDOWN" -> stringResource(R.string.mode_countdown)
        "POMODORO" -> stringResource(R.string.mode_pomodoro)
        else -> stringResource(R.string.timeline_mode_manual)
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(4.dp)
                .height(36.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = name,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = DateTimeUtils.formatTime(item.effectiveStartMs, is12Hour) + " – " +
                    DateTimeUtils.formatTime(item.effectiveEndMs, is12Hour) + " · " + modeLabel,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            text = DateTimeUtils.formatDurationShort(item.effectiveDurationSeconds),
            style = NumberStyle.copy(fontSize = 14.sp),
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
