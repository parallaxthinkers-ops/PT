package com.example.ui.screens.settings

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.StudyApplication
import com.example.data.backup.BackupManager
import com.example.data.backup.BackupSummary
import com.example.data.model.Goal
import com.example.data.model.Subject
import com.example.data.repository.AppSettings
import com.example.receiver.ReminderScheduler
import com.example.service.TimerForegroundService
import com.example.util.LocaleHelper
import com.example.util.StudyMath
import com.example.widget.StudyGlanceWidget
import java.time.LocalDate
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val goals: List<Goal> = emptyList(),
    val activeSubjects: List<Subject> = emptyList(),
    val archivedSubjects: List<Subject> = emptyList(),
    val backupMessage: String? = null,
    val pendingBackupSummary: BackupSummary? = null,
    /** True while a backup is being read or written, so the screen can show progress and block double taps. */
    val busy: Boolean = false
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as StudyApplication
    private val studyRepo = app.studyRepository
    private val settingsRepo = app.settingsRepository

    private val _backupMessage = MutableStateFlow<String?>(null)
    private val _pendingBackupSummary = MutableStateFlow<BackupSummary?>(null)
    private val _busy = MutableStateFlow(false)

    val uiState: StateFlow<SettingsUiState> = combine(
        settingsRepo.settings,
        studyRepo.allGoals,
        studyRepo.activeSubjects,
        studyRepo.archivedSubjects,
        _backupMessage,
        _pendingBackupSummary,
        _busy
    ) { args: Array<Any?> ->
        @Suppress("UNCHECKED_CAST")
        SettingsUiState(
            settings = args[0] as AppSettings,
            goals = args[1] as List<Goal>,
            activeSubjects = args[2] as List<Subject>,
            archivedSubjects = args[3] as List<Subject>,
            backupMessage = args[4] as String?,
            pendingBackupSummary = args[5] as BackupSummary?,
            busy = args[6] as Boolean
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState()
    )

    /** Text in the app language, also for messages created outside Compose. */
    private fun text(resId: Int, vararg args: Any): String {
        val localized = LocaleHelper.localized(getApplication())
        return if (args.isEmpty()) localized.getString(resId) else localized.getString(resId, *args)
    }

    // ---- Appearance --------------------------------------------------------------------------

    fun setThemeMode(mode: String) = launchSet { settingsRepo.setThemeMode(mode) }
    fun setThemeStyle(style: String) = launchSet { settingsRepo.setThemeStyle(style) }
    fun setAccentColor(color: Long) = launchSet { settingsRepo.setAccentColor(color) }
    fun setAmoled(enabled: Boolean) = launchSet { settingsRepo.setAmoled(enabled) }
    fun setCornerStyle(style: String) = launchSet { settingsRepo.setCornerStyle(style) }
    fun setLanguage(lang: String) = launchSet { settingsRepo.setLanguage(lang) }

    // ---- General / timer ---------------------------------------------------------------------

    fun setDayStartHour(hour: Int) = launchSet { settingsRepo.setDayStartHour(hour) }
    fun set12HourFormat(is12Hour: Boolean) = launchSet { settingsRepo.set12HourFormat(is12Hour) }
    fun setFirstDayOfWeek(firstDay: Int) = launchSet { settingsRepo.setFirstDayOfWeek(firstDay) }
    fun setKeepScreenOn(keepOn: Boolean) = launchSet { settingsRepo.setKeepScreenOn(keepOn) }
    fun setSoundEnabled(enabled: Boolean) = launchSet { settingsRepo.setSoundEnabled(enabled) }
    fun setVibrationEnabled(enabled: Boolean) = launchSet { settingsRepo.setVibrationEnabled(enabled) }
    fun setDefaultTimerMode(mode: String) = launchSet { settingsRepo.setDefaultTimerMode(mode) }
    fun setPomoAutoStart(autoStart: Boolean) = launchSet { settingsRepo.setPomoAutoStart(autoStart) }
    fun setAmbientMode(enabled: Boolean) = launchSet { settingsRepo.setAmbientMode(enabled) }
    fun setDndPromptEnabled(enabled: Boolean) = launchSet { settingsRepo.setDndPromptEnabled(enabled) }

    fun setPomodoroDurations(focus: Int, shortBreak: Int, longBreak: Int, interval: Int) =
        launchSet { settingsRepo.setPomoSettings(focus, shortBreak, longBreak, interval) }

    // ---- Goals -------------------------------------------------------------------------------

    /**
     * The goal table always holds one value per weekday, and the rest of the app reads the value of the
     * current weekday. So when "different per weekday" is switched off, every day must take one common
     * value (today's), otherwise the old per-day values would silently stay in effect.
     */
    fun setDifferentGoalPerWeekday(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.setDifferentGoalPerWeekday(enabled)
            if (!enabled) {
                val today = StudyMath.calendarWeekday(LocalDate.now())
                val minutes = studyRepo.getGoalForWeekdayDirect(today)?.targetMinutes ?: 240
                studyRepo.setUniformGoal(minutes)
            }
        }
    }

    fun setUniformGoalMinutes(totalMinutes: Int) {
        viewModelScope.launch { studyRepo.setUniformGoal(totalMinutes.coerceIn(0, 1440)) }
    }

    fun setWeekdayGoalMinutes(weekday: Int, totalMinutes: Int) {
        viewModelScope.launch { studyRepo.setGoalForWeekday(weekday, totalMinutes.coerceIn(0, 1440)) }
    }

    // ---- Reminders ---------------------------------------------------------------------------

    fun setStudyReminder(enabled: Boolean, hour: Int, minute: Int, days: Set<Int>) {
        viewModelScope.launch {
            settingsRepo.setStudyReminder(enabled, hour, minute, days)
            ReminderScheduler.scheduleNext(getApplication(), settingsRepo)
        }
    }

    fun setBreakReminder(enabled: Boolean, minutes: Int) = launchSet { settingsRepo.setBreakReminder(enabled, minutes) }

    fun setAutoBackupReminder(enabled: Boolean, days: Int) {
        viewModelScope.launch {
            settingsRepo.setAutoBackupReminder(enabled, days)
            ReminderScheduler.scheduleBackupCheck(getApplication(), settingsRepo)
        }
    }

    // ---- Subjects ----------------------------------------------------------------------------

    fun moveSubject(subjectId: Long, direction: Int) {
        val ids = uiState.value.activeSubjects.map { it.id }.toMutableList()
        val from = ids.indexOf(subjectId)
        val to = from + direction
        if (from < 0 || to < 0 || to >= ids.size) return
        ids.add(to, ids.removeAt(from))
        viewModelScope.launch { studyRepo.reorderSubjects(ids) }
    }

    fun restoreSubject(subjectId: Long) {
        viewModelScope.launch { studyRepo.unarchiveSubject(subjectId) }
    }

    // ---- Backup ------------------------------------------------------------------------------

    fun exportBackup(uri: Uri) {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            try {
                val result = BackupManager.exportToJson(getApplication(), uri, studyRepo, settingsRepo)
                _backupMessage.value = if (result.isSuccess) {
                    text(R.string.backup_export_success)
                } else {
                    text(R.string.backup_export_failed, result.exceptionOrNull()?.message ?: "")
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun prepareImportFile(uri: Uri) {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            try {
                val result = BackupManager.parseAndValidateBackup(getApplication(), uri)
                if (result.isSuccess) {
                    _pendingBackupSummary.value = result.getOrNull()
                } else {
                    _backupMessage.value = text(R.string.backup_invalid_file, result.exceptionOrNull()?.message ?: "")
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun confirmRestore() {
        val summary = _pendingBackupSummary.value ?: return
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            try {
                val result = BackupManager.restoreFromValidatedSummary(getApplication(), summary, studyRepo, settingsRepo)
                _pendingBackupSummary.value = null
                _backupMessage.value = if (result.isSuccess) {
                    text(R.string.backup_restore_success)
                } else {
                    text(R.string.backup_restore_failed, result.exceptionOrNull()?.message ?: "")
                }
            } finally {
                _busy.value = false
            }
        }
    }

    fun cancelRestore() {
        _pendingBackupSummary.value = null
    }

    fun resetAllData() {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            try {
                // Drop a running timer first, so its session is not saved into the data being wiped.
                TimerForegroundService.discardTimer(getApplication())
                studyRepo.resetAllData()
                settingsRepo.resetAllSettings()
                LocaleHelper.save(getApplication(), "en")
                ReminderScheduler.rescheduleAll(getApplication())
                try {
                    StudyGlanceWidget.updateAll(getApplication())
                } catch (_: Exception) {
                }
                _backupMessage.value = text(R.string.reset_done)
            } finally {
                _busy.value = false
            }
        }
    }

    fun dismissBackupMessage() {
        _backupMessage.value = null
    }

    private fun launchSet(block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }
}
