package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.StudyApplication
import com.example.service.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_STUDY_REMINDER = "com.example.studylocal.ACTION_STUDY_REMINDER"
        const val ACTION_BACKUP_CHECK = "com.example.studylocal.ACTION_BACKUP_CHECK"

        private const val STATE_PREFS = "reminder_state"
        private const val KEY_LAST_BACKUP_NOTIFIED = "last_backup_notified"
        private const val DAY_MS = 24L * 60L * 60L * 1000L
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != ACTION_STUDY_REMINDER && action != ACTION_BACKUP_CHECK) return
        val appContext = context.applicationContext
        val app = appContext as? StudyApplication ?: return

        // The work is asynchronous, so tell the system the receiver is still busy. Without goAsync the
        // process may be frozen before the notification is posted or the next alarm is set.
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = app.settingsRepository.settings.first()
                when (action) {
                    ACTION_STUDY_REMINDER -> {
                        val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
                        if (settings.studyReminderEnabled && settings.studyReminderDays.contains(today)) {
                            NotificationHelper.showStudyReminderNotification(appContext)
                        }
                        ReminderScheduler.scheduleNext(appContext, app.settingsRepository)
                    }
                    ACTION_BACKUP_CHECK -> {
                        if (settings.autoBackupReminderEnabled) {
                            val now = System.currentTimeMillis()
                            val intervalMs = settings.autoBackupReminderDays.coerceAtLeast(1) * DAY_MS
                            val last = settings.lastBackupTime
                            val due = last == 0L || now - last >= intervalMs

                            val prefs = appContext.getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
                            val lastNotified = prefs.getLong(KEY_LAST_BACKUP_NOTIFIED, 0L)
                            // Remind at most once per interval, not every day after it becomes due.
                            if (due && now - lastNotified >= intervalMs) {
                                val daysSince = if (last == 0L) null else ((now - last) / DAY_MS).toInt()
                                NotificationHelper.showBackupReminderNotification(appContext, daysSince)
                                prefs.edit().putLong(KEY_LAST_BACKUP_NOTIFIED, now).apply()
                            }
                        }
                        ReminderScheduler.scheduleBackupCheck(appContext, app.settingsRepository)
                    }
                }
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }
    }
}
