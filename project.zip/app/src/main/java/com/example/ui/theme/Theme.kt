package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import com.example.data.repository.CornerStyleNames
import com.example.data.repository.ThemeStyleNames

/** Two looks. MINIMAL is flat with hairline borders. SOFT has tinted, borderless surfaces and rounder shapes. */
enum class ThemeStyle {
    MINIMAL,
    SOFT;

    companion object {
        fun fromName(raw: String?): ThemeStyle =
            if (ThemeStyleNames.normalize(raw) == ThemeStyleNames.SOFT) SOFT else MINIMAL
    }
}

val LocalThemeStyle = staticCompositionLocalOf { ThemeStyle.MINIMAL }

/** Colours the Material scheme has no slot for. */
@Immutable
data class ExtraColors(
    val hairline: Color,
    val subtle: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val onAccent: Color
)

val LocalExtraColors = staticCompositionLocalOf {
    ExtraColors(
        hairline = Color(0xFFE5E5E0),
        subtle = Color(0xFFF1F1EE),
        success = SuccessGreen,
        warning = WarningAmber,
        danger = DangerRed,
        onAccent = Color.White
    )
}

/** Shortcut: `Ui.extra.hairline`. */
object Ui {
    val extra: ExtraColors
        @Composable @ReadOnlyComposable get() = LocalExtraColors.current
}

private fun onColorFor(color: Color): Color =
    if (color.luminance() > 0.45f) Color(0xFF0B0C10) else Color.White

private fun buildColorScheme(
    dark: Boolean,
    amoled: Boolean,
    style: ThemeStyle,
    accent: Color
): ColorScheme {
    val soft = style == ThemeStyle.SOFT
    val onAccent = onColorFor(accent)

    return if (dark) {
        val bg = if (amoled) Color(0xFF000000) else Color(0xFF0E0F13)
        val surfaceBase = if (amoled) Color(0xFF0B0B0D) else Color(0xFF16181D)
        val surface = if (soft) lerp(surfaceBase, accent, 0.06f) else surfaceBase
        val variant = if (soft) lerp(surfaceBase, accent, 0.12f) else Color(0xFF1F2229)
        darkColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = lerp(surfaceBase, accent, 0.28f),
            onPrimaryContainer = Color(0xFFF4F5F7),
            secondary = accent,
            onSecondary = onAccent,
            secondaryContainer = variant,
            onSecondaryContainer = Color(0xFFF4F5F7),
            tertiary = AccentEmerald,
            background = bg,
            onBackground = Color(0xFFEDEEF1),
            surface = surface,
            onSurface = Color(0xFFEDEEF1),
            surfaceVariant = variant,
            onSurfaceVariant = Color(0xFF9AA0AB),
            surfaceContainerLowest = bg,
            surfaceContainerLow = surfaceBase,
            surfaceContainer = surface,
            surfaceContainerHigh = variant,
            surfaceContainerHighest = lerp(variant, Color.White, 0.04f),
            outline = Color(0xFF3A3E47),
            outlineVariant = Color(0xFF272A31),
            error = Color(0xFFF87171),
            onError = Color(0xFF1A0505)
        )
    } else {
        val bg = if (soft) lerp(Color(0xFFF6F6F3), accent, 0.05f) else Color(0xFFF7F7F5)
        val surface = if (soft) lerp(Color.White, accent, 0.03f) else Color.White
        val variant = if (soft) lerp(Color(0xFFF1F1EE), accent, 0.09f) else Color(0xFFF0F0ED)
        lightColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = lerp(Color.White, accent, 0.16f),
            onPrimaryContainer = Color(0xFF0E0F13),
            secondary = accent,
            onSecondary = onAccent,
            secondaryContainer = variant,
            onSecondaryContainer = Color(0xFF0E0F13),
            tertiary = AccentEmerald,
            background = bg,
            onBackground = Color(0xFF111318),
            surface = surface,
            onSurface = Color(0xFF111318),
            surfaceVariant = variant,
            onSurfaceVariant = Color(0xFF6B7280),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = surface,
            surfaceContainer = variant,
            surfaceContainerHigh = lerp(variant, Color.Black, 0.03f),
            surfaceContainerHighest = lerp(variant, Color.Black, 0.06f),
            outline = Color(0xFFD4D4CE),
            outlineVariant = Color(0xFFE7E7E2),
            error = DangerRed,
            onError = Color.White
        )
    }
}

private fun buildExtras(dark: Boolean, amoled: Boolean, accent: Color, scheme: ColorScheme): ExtraColors =
    ExtraColors(
        hairline = if (dark) (if (amoled) Color(0xFF24262B) else Color(0xFF272A31)) else Color(0xFFE5E5E0),
        subtle = scheme.surfaceVariant,
        success = if (dark) Color(0xFF4ADE80) else SuccessGreen,
        warning = WarningAmber,
        danger = if (dark) Color(0xFFF87171) else DangerRed,
        onAccent = onColorFor(accent)
    )

private fun buildShapes(corner: String, style: ThemeStyle): Shapes {
    // SOFT is a little rounder than MINIMAL for the same corner choice.
    val extra = if (style == ThemeStyle.SOFT) 4 else 0
    return when (CornerStyleNames.normalize(corner)) {
        CornerStyleNames.SHARP -> Shapes(
            extraSmall = RoundedCornerShape(2.dp),
            small = RoundedCornerShape(4.dp),
            medium = RoundedCornerShape((6 + extra).dp),
            large = RoundedCornerShape((8 + extra).dp),
            extraLarge = RoundedCornerShape((12 + extra).dp)
        )
        CornerStyleNames.PILL -> Shapes(
            extraSmall = RoundedCornerShape(10.dp),
            small = RoundedCornerShape(16.dp),
            medium = RoundedCornerShape((22 + extra).dp),
            large = RoundedCornerShape((28 + extra).dp),
            extraLarge = RoundedCornerShape((36 + extra).dp)
        )
        else -> Shapes(
            extraSmall = RoundedCornerShape(6.dp),
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape((14 + extra).dp),
            large = RoundedCornerShape((20 + extra).dp),
            extraLarge = RoundedCornerShape((28 + extra).dp)
        )
    }
}

@Composable
fun ParallaxTrackerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    themeStyle: ThemeStyle = ThemeStyle.MINIMAL,
    accentColor: Color = Color(0xFF3B6EF6),
    amoled: Boolean = false,
    cornerStyle: String = CornerStyleNames.ROUNDED,
    content: @Composable () -> Unit
) {
    // Remembered so a recomposition that changes nothing visible does not rebuild the scheme.
    val colorScheme = remember(darkTheme, amoled, themeStyle, accentColor) {
        buildColorScheme(darkTheme, amoled && darkTheme, themeStyle, accentColor)
    }
    val extras = remember(darkTheme, amoled, accentColor, colorScheme) {
        buildExtras(darkTheme, amoled && darkTheme, accentColor, colorScheme)
    }
    val shapes = remember(cornerStyle, themeStyle) { buildShapes(cornerStyle, themeStyle) }

    CompositionLocalProvider(
        LocalThemeStyle provides themeStyle,
        LocalExtraColors provides extras
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = shapes,
            content = content
        )
    }
}
