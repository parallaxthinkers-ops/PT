package com.example

import android.app.Application
import com.example.data.AppDatabase
import com.example.data.backup.AutoBackupRunner
import com.example.data.repository.SettingsRepository
import com.example.data.repository.StudyRepository
import com.example.receiver.ReminderScheduler
import com.example.service.NotificationHelper
import com.example.service.SessionRecovery
import com.example.util.CrashReporter
import com.example.util.LocaleHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class StudyApplication : Application() {
    // Declared before onCreate so nothing can read them before they exist (Playbook: property order).
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var database: AppDatabase
        private set
    lateinit var studyRepository: StudyRepository
        private set
    lateinit var settingsRepository: SettingsRepository
        private set

    override fun onCreate() {
        super.onCreate()
        // First line after super: a crash during start-up must still be captured.
        CrashReporter.install(this)

        LocaleHelper.applyDefaultLocale(this)

        database = AppDatabase.getInstance(this)
        studyRepository = StudyRepository(database)
        settingsRepository = SettingsRepository(this)

        NotificationHelper.createChannels(this)

        // Restore a timer that was running when the process died. Never throws.
        try {
            SessionRecovery.restoreSessionIfAny(this)
        } catch (_: Exception) {
        }

        // Alarms do not survive an app update or a force stop; re-arm the reminders on every start.
        try {
            ReminderScheduler.rescheduleAll(this)
        } catch (_: Exception) {
        }

        // Catch-up: if the phone was off at 03:00 the scheduled backup is made now instead. Never throws.
        appScope.launch {
            try {
                AutoBackupRunner.run(this@StudyApplication, force = false)
            } catch (_: Exception) {
            }
        }

        // Older installs have the language only in DataStore. Mirror it once so notifications and the
        // widget (which cannot read DataStore synchronously) use the right language.
        appScope.launch {
            try {
                LocaleHelper.save(this@StudyApplication, settingsRepository.languageFlow.first())
            } catch (_: Exception) {
            }
        }
    }
}
