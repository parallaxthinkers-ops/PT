package com.example.ui.screens.planner

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.EventNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.StudyTask
import com.example.ui.components.AddEditTaskDialog
import com.example.ui.components.AppCard
import com.example.ui.components.AppDatePickerDialog
import com.example.ui.components.ColorDot
import com.example.ui.components.DayNavigator
import com.example.ui.components.EmptyState
import com.example.ui.components.ScreenHeader
import com.example.ui.theme.Ui

@Composable
fun PlannerScreen(
    viewModel: PlannerViewModel,
    onStartTimerForSubject: (subjectId: Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val ui by viewModel.uiState.collectAsStateWithLifecycle()
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<StudyTask?>(null) }
    var deletingTask by remember { mutableStateOf<StudyTask?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            ScreenHeader(title = stringResource(R.string.nav_planner))

            DayNavigator(
                testTagPrefix = "planner",
                dateMs = ui.dateMs,
                isToday = ui.isToday,
                onPrev = { viewModel.prevDay() },
                onNext = { viewModel.nextDay() },
                onToday = { viewModel.goToToday() },
                onPick = { showDatePicker = true }
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (ui.totalCount > 0) {
                SummaryCard(ui = ui, modifier = Modifier.padding(horizontal = 16.dp))
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (ui.tasks.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    EmptyState(
                        icon = Icons.Outlined.EventNote,
                        title = stringResource(R.string.planner_empty_title),
                        message = stringResource(R.string.no_tasks_today)
                    )
                    TextButton(
                        onClick = { showAddTaskDialog = true },
                        modifier = Modifier.testTag("empty_add_task_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.add_task))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(ui.tasks, key = { _, item -> item.task.id }) { index, item ->
                        TaskCard(
                            item = item,
                            canMoveUp = index > 0,
                            canMoveDown = index < ui.tasks.lastIndex,
                            onToggle = { viewModel.toggleTask(item) },
                            onMoveUp = { viewModel.moveTask(index, -1) },
                            onMoveDown = { viewModel.moveTask(index, 1) },
                            onEdit = { editingTask = item.task },
                            onStartTimer = { item.subject?.let { onStartTimerForSubject(it.id) } }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showAddTaskDialog = true },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Ui.extra.onAccent,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_task_fab")
        ) {
            Icon(imageVector = Icons.Filled.Add, contentDescription = stringResource(R.string.add_task))
        }
    }

    if (showDatePicker) {
        AppDatePickerDialog(
            initial = ui.date,
            onDismiss = { showDatePicker = false },
            onConfirm = { date ->
                viewModel.selectDate(date)
                showDatePicker = false
            }
        )
    }

    if (showAddTaskDialog) {
        AddEditTaskDialog(
            subjects = ui.subjects,
            onDismiss = { showAddTaskDialog = false },
            onSave = { title, subjectId, minutes, repeatRule ->
                viewModel.addTask(title, subjectId, minutes, repeatRule)
                showAddTaskDialog = false
            }
        )
    }

    editingTask?.let { task ->
        AddEditTaskDialog(
            initialTask = task,
            subjects = ui.subjects,
            onDismiss = { editingTask = null },
            onSave = { title, subjectId, minutes, repeatRule ->
                viewModel.updateTask(
                    task.copy(title = title, subjectId = subjectId, plannedMinutes = minutes, repeatRule = repeatRule)
                )
                editingTask = null
            },
            onDelete = {
                editingTask = null
                deletingTask = task
            }
        )
    }

    deletingTask?.let { task ->
        AlertDialog(
            onDismissRequest = { deletingTask = null },
            title = { Text(stringResource(R.string.planner_delete_title)) },
            text = {
                Column {
                    Text(task.title, style = MaterialTheme.typography.bodyLarge)
                    if (task.repeatRule != "NONE") {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = stringResource(R.string.planner_delete_repeat_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteTask(task)
                        deletingTask = null
                    }
                ) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingTask = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun SummaryCard(ui: PlannerUiState, modifier: Modifier = Modifier) {
    val allDone = ui.completedCount == ui.totalCount && ui.totalCount > 0
    AppCard(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.completed_tasks, ui.completedCount, ui.totalCount),
                style = MaterialTheme.typography.titleSmall,
                color = if (allDone) Ui.extra.success else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.testTag("planner_done_count")
            )
            if (ui.totalPlannedMinutes > 0) {
                Text(
                    text = stringResource(R.string.planner_planned_minutes, ui.totalPlannedMinutes.toString()),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { ui.completedCount.toFloat() / ui.totalCount.toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(MaterialTheme.shapes.extraSmall),
            color = if (allDone) Ui.extra.success else MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
private fun TaskCard(
    item: TaskWithSubject,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onToggle: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onEdit: () -> Unit,
    onStartTimer: () -> Unit
) {
    val task = item.task
    val subject = item.subject
    val isDone = item.isCompletedToday
    val repeatLabel = when (task.repeatRule) {
        "DAILY" -> stringResource(R.string.repeat_daily)
        "WEEKDAYS" -> stringResource(R.string.repeat_weekdays)
        "WEEKLY" -> stringResource(R.string.repeat_weekly)
        else -> null
    }

    AppCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("task_item_${task.id}"),
        contentPadding = PaddingValues(start = 6.dp, end = 6.dp, top = 8.dp, bottom = 8.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onToggle) {
                Icon(
                    imageVector = if (isDone) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircleOutline,
                    contentDescription = stringResource(if (isDone) R.string.cd_task_done else R.string.cd_task_not_done),
                    tint = if (isDone) Ui.extra.success else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(26.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = if (isDone) FontWeight.Normal else FontWeight.SemiBold,
                    textDecoration = if (isDone) TextDecoration.LineThrough else TextDecoration.None,
                    color = if (isDone) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                if (subject != null || task.plannedMinutes > 0 || repeatLabel != null) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (subject != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ColorDot(Color(subject.color), size = 8.dp)
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = subject.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                        if (task.plannedMinutes > 0) {
                            Text(
                                text = stringResource(R.string.settings_n_minutes, task.plannedMinutes.toString()),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        if (repeatLabel != null) {
                            Icon(
                                imageVector = Icons.Filled.Repeat,
                                contentDescription = repeatLabel,
                                modifier = Modifier.size(13.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            IconButton(onClick = onMoveUp, enabled = canMoveUp, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Filled.ArrowUpward, contentDescription = stringResource(R.string.cd_move_up), modifier = Modifier.size(16.dp))
            }
            IconButton(onClick = onMoveDown, enabled = canMoveDown, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Filled.ArrowDownward, contentDescription = stringResource(R.string.cd_move_down), modifier = Modifier.size(16.dp))
            }
            IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                Icon(
                    Icons.Filled.Edit,
                    contentDescription = stringResource(R.string.edit_task),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        if (subject != null && !isDone) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 8.dp),
                horizontalArrangement = Arrangement.Start
            ) {
                TextButton(onClick = onStartTimer) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = Color(subject.color),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.planner_start_subject, subject.name),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}
