package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.StudyApplication
import com.example.ui.navigation.Screen
import com.example.ui.navigation.StudyBottomNavBar
import com.example.ui.screens.dday.DDayScreen
import com.example.ui.screens.dday.DDayViewModel
import com.example.ui.screens.focus.FocusScreen
import com.example.ui.screens.onboarding.OnboardingScreen
import com.example.ui.screens.planner.PlannerScreen
import com.example.ui.screens.planner.PlannerViewModel
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.settings.SettingsViewModel
import com.example.ui.screens.stats.StatsScreen
import com.example.ui.screens.themes.ThemesScreen
import com.example.ui.theme.appBackground
import com.example.ui.screens.stats.StatsViewModel
import com.example.ui.screens.timer.TimerScreen
import com.example.ui.screens.timer.TimerViewModel
import com.example.ui.screens.timeline.TimelineScreen
import com.example.ui.screens.timeline.TimelineViewModel

@Composable
fun StudyMainScreen(
    app: StudyApplication,
    modifier: Modifier = Modifier
) {
    val onboardingCompleted by app.settingsRepository.onboardingCompletedFlow.collectAsStateWithLifecycle(
        // The settings are already loaded here (MainActivity waits for them), so a first-run person never sees the Timer flash by.
        initialValue = app.settingsRepository.lastKnown?.onboardingCompleted ?: true
    )
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Timer) }

    // The notification permission is asked at the end of the first-run set-up, and the Timer screen shows a
    // banner when it is still missing. Asking here as well would put two system prompts on top of each other.
    if (!onboardingCompleted) {
        OnboardingScreen(
            onFinished = {
                currentScreen = Screen.Timer
            },
            modifier = modifier
        )
        return
    }

    val timerViewModel: TimerViewModel = viewModel()
    val plannerViewModel: PlannerViewModel = viewModel()
    val timelineViewModel: TimelineViewModel = viewModel()
    val statsViewModel: StatsViewModel = viewModel()
    val settingsViewModel: SettingsViewModel = viewModel()
    val dDayViewModel: DDayViewModel = viewModel()

    // Handle BackHandler to navigate back to Timer screen
    if (currentScreen != Screen.Timer && currentScreen != Screen.FocusMode && currentScreen != Screen.Themes) {
        BackHandler {
            currentScreen = Screen.Timer
        }
    }

    // Themes is opened from Settings, so Back returns there.
    if (currentScreen == Screen.Themes) {
        BackHandler { currentScreen = Screen.Settings }
        ThemesScreen(
            viewModel = settingsViewModel,
            onBack = { currentScreen = Screen.Settings },
            modifier = modifier
        )
        return
    }

    // Fullscreen Focus Mode
    if (currentScreen == Screen.FocusMode) {
        FocusScreen(
            onExitFocus = { currentScreen = Screen.Timer },
            modifier = modifier
        )
        return
    }

    // Fullscreen D-Day Manager
    if (currentScreen == Screen.DDayManager) {
        DDayScreen(
            viewModel = dDayViewModel,
            onBack = { currentScreen = Screen.Timer },
            modifier = modifier
        )
        return
    }

    // The optional gradient is drawn once behind everything; the Scaffold on top is then transparent.
    Scaffold(
        modifier = modifier.fillMaxSize().appBackground(),
        containerColor = Color.Transparent,
        // Stated on purpose: with a transparent container the default content colour would be black, which is
        // invisible on the dark aesthetics.
        contentColor = MaterialTheme.colorScheme.onBackground,
        bottomBar = {
            StudyBottomNavBar(
                currentScreen = currentScreen,
                onNavigate = { currentScreen = it }
            )
        }
    ) { innerPadding ->
        // No cross-fade on purpose: it kept the old AND the new screen composed for the whole animation,
        // which made tab switches feel slow. An instant switch is what people expect from a bottom bar.
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentScreen) {
                Screen.Timer -> {
                    TimerScreen(
                        viewModel = timerViewModel,
                        onNavigateToFocus = { currentScreen = Screen.FocusMode },
                        onNavigateToDDay = { currentScreen = Screen.DDayManager }
                    )
                }
                Screen.Planner -> {
                    PlannerScreen(
                        viewModel = plannerViewModel,
                        onStartTimerForSubject = { subjectId ->
                            timerViewModel.startTimerForSubject(subjectId)
                            currentScreen = Screen.Timer
                        }
                    )
                }
                Screen.Timeline -> {
                    TimelineScreen(viewModel = timelineViewModel)
                }
                Screen.Stats -> {
                    StatsScreen(
                        viewModel = statsViewModel,
                        onNavigateToTimeline = { dateMs ->
                            timelineViewModel.selectDate(dateMs)
                            currentScreen = Screen.Timeline
                        }
                    )
                }
                Screen.Settings -> {
                    SettingsScreen(
                        viewModel = settingsViewModel,
                        onNavigateToDDay = { currentScreen = Screen.DDayManager },
                        onNavigateToThemes = { currentScreen = Screen.Themes }
                    )
                }
                else -> {
                    TimerScreen(
                        viewModel = timerViewModel,
                        onNavigateToFocus = { currentScreen = Screen.FocusMode },
                        onNavigateToDDay = { currentScreen = Screen.DDayManager }
                    )
                }
            }
        }
    }
}
