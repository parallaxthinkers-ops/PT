package com.example.data.backup

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.example.BuildConfig
import com.example.data.model.DDay
import com.example.data.model.Goal
import com.example.data.model.StudySession
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.TaskCompletion
import com.example.data.repository.SettingsRepository
import com.example.data.repository.StudyRepository
import com.example.receiver.ReminderScheduler
import com.example.service.TimerForegroundService
import com.example.ui.theme.ThemePresets
import com.example.widget.StudyGlanceWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class BackupSummary(
    val schemaVersion: Int,
    val appVersion: String,
    val exportTime: Long,
    val subjectsCount: Int,
    val sessionsCount: Int,
    val goalsCount: Int,
    val dDaysCount: Int,
    val tasksCount: Int,
    val taskCompletionsCount: Int,
    val rawJson: String
)

/**
 * JSON backup. All file work runs on the IO dispatcher, so exporting or importing a big history never
 * freezes the screen. Old backup files (schema 1 and 2, and the old app name) are still accepted.
 */
object BackupManager {
    /** 3 adds the appearance, Pomodoro and reminder settings. Older files simply have fewer settings. */
    const val CURRENT_SCHEMA_VERSION = 3
    const val APP_NAME = "Parallax Tracker"

    /** The version shown in the file always follows the real app version. */
    val APP_VERSION: String get() = BuildConfig.VERSION_NAME

    /** A backup is plain text. Anything bigger than this is not a backup, and reading it could run out of memory. */
    private const val MAX_BACKUP_BYTES = 64L * 1024L * 1024L

    suspend fun exportToJson(
        context: Context,
        uri: Uri,
        studyRepo: StudyRepository,
        settingsRepo: SettingsRepository
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val text = buildBackupText(studyRepo, settingsRepo)
            val stream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("Cannot open destination file"))
            stream.use { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
                out.flush()
            }

            settingsRepo.recordBackupExported()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** The whole backup as JSON text. Shared by the manual export and the scheduled backup. */
    private suspend fun buildBackupText(
        studyRepo: StudyRepository,
        settingsRepo: SettingsRepository
    ): String {
        val payload = studyRepo.getAllDataForBackup()
        val s = settingsRepo.settings.first()

        val root = JSONObject()
        root.put("schemaVersion", CURRENT_SCHEMA_VERSION)
        root.put("app", APP_NAME)
        root.put("appVersion", APP_VERSION)
        root.put("exportTime", System.currentTimeMillis())

        val subjectsArr = JSONArray()
        payload.subjects.forEach { sub ->
            subjectsArr.put(
                JSONObject().apply {
                    put("id", sub.id)
                    put("name", sub.name)
                    put("color", sub.color)
                    put("icon", sub.icon)
                    put("order", sub.order)
                    put("createdAt", sub.createdAt)
                    put("isArchived", sub.isArchived)
                }
            )
        }
        root.put("subjects", subjectsArr)

        val sessionsArr = JSONArray()
        payload.sessions.forEach { sess ->
            sessionsArr.put(
                JSONObject().apply {
                    put("id", sess.id)
                    sess.subjectId?.let { put("subjectId", it) }
                    put("startTime", sess.startTime)
                    put("endTime", sess.endTime)
                    put("mode", sess.mode)
                    put("interruptions", sess.interruptions)
                }
            )
        }
        root.put("sessions", sessionsArr)

        val goalsArr = JSONArray()
        payload.goals.forEach { g ->
            goalsArr.put(JSONObject().apply {
                put("weekday", g.weekday)
                put("targetMinutes", g.targetMinutes)
            })
        }
        root.put("goals", goalsArr)

        val dDaysArr = JSONArray()
        payload.dDays.forEach { d ->
            dDaysArr.put(JSONObject().apply {
                put("id", d.id)
                put("title", d.title)
                put("targetDate", d.targetDate)
                put("countUp", d.countUp)
                put("color", d.color)
                put("isPinned", d.isPinned)
            })
        }
        root.put("ddays", dDaysArr)

        val tasksArr = JSONArray()
        payload.tasks.forEach { t ->
            tasksArr.put(JSONObject().apply {
                put("id", t.id)
                put("title", t.title)
                t.subjectId?.let { put("subjectId", it) }
                put("plannedMinutes", t.plannedMinutes)
                put("date", t.date)
                put("isDone", t.isDone)
                put("repeatRule", t.repeatRule)
                put("order", t.order)
            })
        }
        root.put("tasks", tasksArr)

        val completionsArr = JSONArray()
        payload.taskCompletions.forEach { c ->
            completionsArr.put(JSONObject().apply {
                put("taskId", c.taskId)
                put("date", c.date)
            })
        }
        root.put("taskCompletions", completionsArr)

        val settingsObj = JSONObject().apply {
            put("dayStartHour", s.dayStartHour)
            put("themeMode", s.themeMode)
            put("themeStyle", s.themeStyle)
            put("accentColor", s.accentColor)
            put("amoled", s.amoled)
            put("cornerStyle", s.cornerStyle)
            put("themePreset", s.themePreset)
            put("themeAccentCustom", s.themeAccentCustom)
            put("themeGradient", s.themeGradient)
            put("themeFont", s.themeFont)
            put("themeRing", s.themeRing)
            put("language", s.language)
            put("keepScreenOn", s.keepScreenOn)
            put("soundEnabled", s.soundEnabled)
            put("vibrationEnabled", s.vibrationEnabled)
            put("firstDayOfWeek", s.firstDayOfWeek)
            put("is12HourFormat", s.is12Hour)
            put("defaultTimerMode", s.defaultTimerMode)
            put("pomoFocusMinutes", s.pomoFocusMinutes)
            put("pomoShortBreakMinutes", s.pomoShortBreakMinutes)
            put("pomoLongBreakMinutes", s.pomoLongBreakMinutes)
            put("pomoLongBreakInterval", s.pomoInterval)
            put("pomoAutoStart", s.pomoAutoStart)
            put("countdownSeconds", s.countdownSeconds)
            put("customPresets", s.customPresets.joinToString(","))
            put("timelineZoom", s.timelineZoom)
            put("differentGoalPerWeekday", s.differentGoalPerWeekday)
            put("studyReminderEnabled", s.studyReminderEnabled)
            put("studyReminderHour", s.studyReminderHour)
            put("studyReminderMinute", s.studyReminderMinute)
            put("studyReminderDays", s.studyReminderDays.sorted().joinToString(","))
            put("breakReminderEnabled", s.breakReminderEnabled)
            put("breakReminderMinutes", s.breakReminderMinutes)
            put("autoBackupReminderEnabled", s.autoBackupReminderEnabled)
            put("autoBackupReminderDays", s.autoBackupReminderDays)
        }
        root.put("settings", settingsObj)

        return root.toString(2)
    }

    // ---- Scheduled backup: write into a folder chosen with the system folder picker ----------------

    /** Every scheduled file starts with this. Pruning only ever touches files with this prefix and ".json". */
    const val AUTO_PREFIX = "parallaxtracker-auto-"

    /** The name of the folder the user picked, for showing in Settings. Null when it cannot be read. */
    fun folderDisplayName(context: Context, treeUri: Uri): String? {
        return try {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri))
            context.contentResolver.query(
                docUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Writes one backup file into [treeUri] and then deletes the oldest scheduled files so that only
     * [keep] remain. Returns the new file name. A half-written file is deleted again on failure, so
     * the folder never fills up with broken backups.
     */
    suspend fun exportToTree(
        context: Context,
        treeUri: Uri,
        keep: Int,
        studyRepo: StudyRepository,
        settingsRepo: SettingsRepository
    ): Result<String> = withContext(Dispatchers.IO) {
        var created: Uri? = null
        val resolver = context.contentResolver
        try {
            val text = buildBackupText(studyRepo, settingsRepo)
            val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, DocumentsContract.getTreeDocumentId(treeUri))
            val name = AutoBackupPlan.fileName(System.currentTimeMillis())
            val newFile = DocumentsContract.createDocument(resolver, parent, "application/json", name)
                ?: throw java.io.IOException("The folder refused the new file")
            created = newFile
            // Thrown (not returned) so the catch below removes the empty file again.
            val out = resolver.openOutputStream(newFile, "w")
                ?: throw java.io.IOException("Cannot open the new file")
            out.use {
                it.write(text.toByteArray(Charsets.UTF_8))
                it.flush()
            }
            // Success: from here on the new file stays, even if pruning fails.
            created = null
            try {
                pruneOldAutoBackups(context, treeUri, keep)
            } catch (_: Exception) {
            }
            Result.success(name)
        } catch (e: Exception) {
            try {
                created?.let { DocumentsContract.deleteDocument(resolver, it) }
            } catch (_: Exception) {
            }
            Result.failure(e)
        }
    }

    private fun pruneOldAutoBackups(context: Context, treeUri: Uri, keep: Int) {
        val resolver = context.contentResolver
        val treeId = DocumentsContract.getTreeDocumentId(treeUri)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeId)
        val mine = ArrayList<Pair<String, String>>() // display name to document id
        resolver.query(
            children,
            arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                if (AutoBackupPlan.isOurFile(name)) mine.add(name to id)
            }
        }
        // The date and time are in the name, so sorting by name sorts by age. Newest first.
        val sorted = mine.sortedByDescending { it.first }
        for ((_, id) in sorted.drop(keep.coerceAtLeast(1))) {
            try {
                DocumentsContract.deleteDocument(resolver, DocumentsContract.buildDocumentUriUsingTree(treeUri, id))
            } catch (_: Exception) {
            }
        }
    }

    suspend fun parseAndValidateBackup(context: Context, uri: Uri): Result<BackupSummary> =
        withContext(Dispatchers.IO) {
            try {
                val stream = context.contentResolver.openInputStream(uri)
                    ?: return@withContext Result.failure(Exception("Could not read backup file"))

                val bytes = stream.use { input ->
                    val buffer = java.io.ByteArrayOutputStream()
                    val chunk = ByteArray(16 * 1024)
                    var total = 0L
                    while (true) {
                        val n = input.read(chunk)
                        if (n < 0) break
                        total += n
                        if (total > MAX_BACKUP_BYTES) {
                            return@withContext Result.failure(Exception("File is too large to be a backup"))
                        }
                        buffer.write(chunk, 0, n)
                    }
                    buffer.toByteArray()
                }

                val jsonStr = String(bytes, Charsets.UTF_8)
                val root = JSONObject(jsonStr)

                val schemaVersion = when {
                    root.has("schemaVersion") -> root.getInt("schemaVersion")
                    root.has("version") -> root.getInt("version")
                    else -> return@withContext Result.failure(Exception("Invalid backup format: missing schemaVersion"))
                }
                if (schemaVersion > CURRENT_SCHEMA_VERSION) {
                    return@withContext Result.failure(
                        Exception("Backup file was created with a newer app version (schema $schemaVersion)")
                    )
                }
                if (!root.has("subjects") && !root.has("sessions")) {
                    return@withContext Result.failure(Exception("Invalid backup format: subjects or sessions array missing"))
                }

                Result.success(
                    BackupSummary(
                        schemaVersion = schemaVersion,
                        appVersion = root.optString("appVersion", "1.0.0"),
                        exportTime = root.optLong("exportTime", System.currentTimeMillis()),
                        subjectsCount = root.optJSONArray("subjects")?.length() ?: 0,
                        sessionsCount = root.optJSONArray("sessions")?.length() ?: 0,
                        goalsCount = root.optJSONArray("goals")?.length() ?: 0,
                        dDaysCount = root.optJSONArray("ddays")?.length() ?: 0,
                        tasksCount = root.optJSONArray("tasks")?.length() ?: 0,
                        taskCompletionsCount = root.optJSONArray("taskCompletions")?.length() ?: 0,
                        rawJson = jsonStr
                    )
                )
            } catch (e: Exception) {
                Result.failure(Exception("Failed to parse backup: ${e.message}"))
            }
        }

    suspend fun restoreFromValidatedSummary(
        context: Context,
        summary: BackupSummary,
        studyRepo: StudyRepository,
        settingsRepo: SettingsRepository
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(summary.rawJson)

            val subjectsList = mutableListOf<Subject>()
            val subjectsArr = root.optJSONArray("subjects") ?: JSONArray()
            for (i in 0 until subjectsArr.length()) {
                val obj = subjectsArr.getJSONObject(i)
                val name = obj.optString("name", "").trim()
                if (name.isEmpty()) continue
                subjectsList.add(
                    Subject(
                        id = obj.optLong("id", 0L),
                        name = name,
                        color = obj.optLong("color", 0xFF3B82F6L),
                        icon = obj.optString("icon", "book"),
                        order = obj.optInt("order", i),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        isArchived = obj.optBoolean("isArchived", false)
                    )
                )
            }

            val sessionsList = mutableListOf<StudySession>()
            val sessionsArr = root.optJSONArray("sessions") ?: JSONArray()
            for (i in 0 until sessionsArr.length()) {
                val obj = sessionsArr.getJSONObject(i)
                val start = obj.getLong("startTime")
                val end = obj.getLong("endTime")
                if (end <= start) continue // an empty or negative session is never valid
                val subjectId = if (obj.has("subjectId") && !obj.isNull("subjectId")) obj.getLong("subjectId") else null
                sessionsList.add(
                    StudySession(
                        id = obj.optLong("id", 0L),
                        subjectId = subjectId,
                        startTime = start,
                        endTime = end,
                        mode = obj.optString("mode", "STOPWATCH"),
                        interruptions = obj.optInt("interruptions", 0)
                    )
                )
            }

            val goalsList = mutableListOf<Goal>()
            val goalsArr = root.optJSONArray("goals") ?: JSONArray()
            for (i in 0 until goalsArr.length()) {
                val obj = goalsArr.getJSONObject(i)
                val weekday = obj.getInt("weekday")
                if (weekday !in 1..7) continue
                goalsList.add(Goal(weekday = weekday, targetMinutes = obj.optInt("targetMinutes", 240).coerceIn(0, 1440)))
            }

            val dDaysList = mutableListOf<DDay>()
            val dDaysArr = root.optJSONArray("ddays") ?: JSONArray()
            for (i in 0 until dDaysArr.length()) {
                val obj = dDaysArr.getJSONObject(i)
                dDaysList.add(
                    DDay(
                        id = obj.optLong("id", 0L),
                        title = obj.getString("title"),
                        targetDate = obj.getLong("targetDate"),
                        countUp = obj.optBoolean("countUp", false),
                        color = obj.optLong("color", 0xFF3B82F6L),
                        isPinned = obj.optBoolean("isPinned", false)
                    )
                )
            }

            val tasksList = mutableListOf<StudyTask>()
            val tasksArr = root.optJSONArray("tasks") ?: JSONArray()
            for (i in 0 until tasksArr.length()) {
                val obj = tasksArr.getJSONObject(i)
                val subjectId = if (obj.has("subjectId") && !obj.isNull("subjectId")) obj.getLong("subjectId") else null
                tasksList.add(
                    StudyTask(
                        id = obj.optLong("id", 0L),
                        title = obj.getString("title"),
                        subjectId = subjectId,
                        plannedMinutes = obj.optInt("plannedMinutes", 0),
                        date = obj.getString("date"),
                        isDone = obj.optBoolean("isDone", false),
                        repeatRule = obj.optString("repeatRule", "NONE"),
                        order = obj.optInt("order", i)
                    )
                )
            }

            val completionsList = mutableListOf<TaskCompletion>()
            val completionsArr = root.optJSONArray("taskCompletions") ?: JSONArray()
            for (i in 0 until completionsArr.length()) {
                val obj = completionsArr.getJSONObject(i)
                completionsList.add(TaskCompletion(taskId = obj.getLong("taskId"), date = obj.getString("date")))
            }

            // A running timer belongs to the data that is about to be replaced. Drop it WITHOUT saving it.
            TimerForegroundService.discardTimer(context)

            // One database transaction: either everything is restored or nothing changes.
            studyRepo.restoreAllData(
                subjects = subjectsList,
                sessions = sessionsList,
                goals = goalsList,
                dDays = dDaysList,
                tasks = tasksList,
                completions = completionsList
            )

            root.optJSONObject("settings")?.let { restoreSettings(it, settingsRepo) }

            ReminderScheduler.rescheduleAll(context)
            try {
                StudyGlanceWidget.updateAll(context)
            } catch (_: Exception) {
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception("Failed to restore data: ${e.message}"))
        }
    }

    /** Every setting is optional, so a backup from an older version restores cleanly. */
    private suspend fun restoreSettings(o: JSONObject, repo: SettingsRepository) {
        if (o.has("dayStartHour")) repo.setDayStartHour(o.getInt("dayStartHour").coerceIn(0, 23))
        if (o.has("themeMode")) repo.setThemeMode(o.getString("themeMode").uppercase())
        if (o.has("themeStyle")) repo.setThemeStyle(o.getString("themeStyle"))
        if (o.has("accentColor")) repo.setAccentColor(o.getLong("accentColor"))
        if (o.has("amoled")) repo.setAmoled(o.getBoolean("amoled"))
        if (o.has("cornerStyle")) repo.setCornerStyle(o.getString("cornerStyle"))
        // Appearance added in 2.1.0. Older backups simply do not have these keys.
        if (o.has("themePreset")) {
            repo.applyThemePreset(
                presetId = ThemePresets.normalize(o.getString("themePreset")),
                cardStyle = o.optString("themeStyle", "MINIMAL"),
                corner = o.optString("cornerStyle", "ROUNDED"),
                font = o.optString("themeFont", "SYSTEM"),
                gradient = o.optBoolean("themeGradient", false)
            )
            repo.setThemeAccentCustom(o.optLong("themeAccentCustom", 0L))
            repo.setThemeRing(o.optString("themeRing", "REGULAR"))
        }
        if (o.has("language")) repo.setLanguage(o.getString("language"))
        if (o.has("keepScreenOn")) repo.setKeepScreenOn(o.getBoolean("keepScreenOn"))
        if (o.has("soundEnabled")) repo.setSoundEnabled(o.getBoolean("soundEnabled"))
        if (o.has("vibrationEnabled")) repo.setVibrationEnabled(o.getBoolean("vibrationEnabled"))
        if (o.has("firstDayOfWeek")) repo.setFirstDayOfWeek(o.getInt("firstDayOfWeek"))
        if (o.has("is12HourFormat")) repo.set12HourFormat(o.getBoolean("is12HourFormat"))
        if (o.has("defaultTimerMode")) repo.setDefaultTimerMode(o.getString("defaultTimerMode"))

        if (o.has("pomoFocusMinutes") && o.has("pomoShortBreakMinutes") &&
            o.has("pomoLongBreakMinutes") && o.has("pomoLongBreakInterval")
        ) {
            repo.setPomoSettings(
                o.getInt("pomoFocusMinutes"),
                o.getInt("pomoShortBreakMinutes"),
                o.getInt("pomoLongBreakMinutes"),
                o.getInt("pomoLongBreakInterval")
            )
        }
        if (o.has("pomoAutoStart")) repo.setPomoAutoStart(o.getBoolean("pomoAutoStart"))
        if (o.has("countdownSeconds")) repo.setCountdownSeconds(o.getLong("countdownSeconds"))
        if (o.has("customPresets")) {
            o.getString("customPresets").split(",")
                .mapNotNull { it.trim().toIntOrNull() }
                .filter { it in 1..1440 }
                .forEach { repo.addCustomPreset(it) }
        }
        if (o.has("timelineZoom")) repo.setTimelineZoom(o.getInt("timelineZoom").coerceIn(0, 2))
        if (o.has("differentGoalPerWeekday")) repo.setDifferentGoalPerWeekday(o.getBoolean("differentGoalPerWeekday"))

        if (o.has("studyReminderEnabled") && o.has("studyReminderHour") && o.has("studyReminderMinute")) {
            val days = if (o.has("studyReminderDays")) {
                o.getString("studyReminderDays").split(",")
                    .mapNotNull { it.trim().toIntOrNull() }
                    .filter { it in 1..7 }
                    .toSet()
            } else {
                setOf(1, 2, 3, 4, 5, 6, 7)
            }
            repo.setStudyReminder(
                o.getBoolean("studyReminderEnabled"),
                o.getInt("studyReminderHour"),
                o.getInt("studyReminderMinute"),
                days
            )
        }
        if (o.has("breakReminderEnabled") && o.has("breakReminderMinutes")) {
            repo.setBreakReminder(o.getBoolean("breakReminderEnabled"), o.getInt("breakReminderMinutes"))
        }
        if (o.has("autoBackupReminderEnabled") && o.has("autoBackupReminderDays")) {
            repo.setAutoBackupReminder(o.getBoolean("autoBackupReminderEnabled"), o.getInt("autoBackupReminderDays"))
        }
    }
}
