package com.example.ui.screens.dday

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.theme.appBackground
import com.example.data.model.DDay
import com.example.ui.components.AddEditDDayDialog
import com.example.ui.components.AppCard
import com.example.ui.components.EmptyState
import com.example.ui.theme.Ui
import com.example.util.DateTimeUtils

@Composable
fun DDayScreen(
    viewModel: DDayViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dDays by viewModel.dDays.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var editingDDay by remember { mutableStateOf<DDay?>(null) }
    var deletingDDay by remember { mutableStateOf<DDay?>(null) }

    // This screen is shown without the app scaffold, so it takes care of the system bars itself.
    Box(
        modifier = modifier
            .fillMaxSize()
            .appBackground()
            .systemBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.back),
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Text(
                    text = stringResource(R.string.dday_screen_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(start = 4.dp)
                )
            }

            if (dDays.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    EmptyState(
                        icon = Icons.Filled.CalendarMonth,
                        title = stringResource(R.string.dday_empty_title),
                        message = stringResource(R.string.dday_empty_desc)
                    )
                    TextButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.dday_add_first))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(dDays, key = { it.id }) { dday ->
                        DDayCard(
                            dday = dday,
                            onEdit = { editingDDay = dday },
                            onPin = { viewModel.pinDDay(dday.id) },
                            onDelete = { deletingDDay = dday }
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showAddDialog = true },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Ui.extra.onAccent,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_dday_fab")
        ) {
            Icon(imageVector = Icons.Filled.Add, contentDescription = stringResource(R.string.add_dday))
        }
    }

    if (showAddDialog) {
        AddEditDDayDialog(
            onDismiss = { showAddDialog = false },
            onSave = { title, targetDateMs, countUp, isPinned, color ->
                viewModel.addDDay(title, targetDateMs, countUp, isPinned, color)
                showAddDialog = false
            }
        )
    }

    editingDDay?.let { dday ->
        AddEditDDayDialog(
            initialDDay = dday,
            onDismiss = { editingDDay = null },
            onSave = { title, targetDateMs, countUp, isPinned, color ->
                viewModel.updateDDay(
                    dday.copy(
                        title = title,
                        targetDate = targetDateMs,
                        countUp = countUp,
                        isPinned = isPinned,
                        color = color
                    )
                )
                editingDDay = null
            }
        )
    }

    deletingDDay?.let { dday ->
        AlertDialog(
            onDismissRequest = { deletingDDay = null },
            title = { Text(stringResource(R.string.dday_delete_title)) },
            text = { Text(stringResource(R.string.dday_delete_message, dday.title)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteDDay(dday)
                        deletingDDay = null
                    }
                ) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { deletingDDay = null }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}

@Composable
private fun DDayCard(
    dday: DDay,
    onEdit: () -> Unit,
    onPin: () -> Unit,
    onDelete: () -> Unit
) {
    val accent = Color(dday.color)
    AppCard(
        onClick = onEdit,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dday_card_${dday.id}")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = dday.formattedDDay(),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = accent
                    )
                    if (dday.isPinned) {
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.dday_pinned),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = dday.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Event,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = DateTimeUtils.formatDate(dday.targetDate),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (dday.countUp) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.dday_counting_up),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPin, modifier = Modifier.testTag("pin_dday_${dday.id}")) {
                    Icon(
                        imageVector = if (dday.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                        contentDescription = stringResource(if (dday.isPinned) R.string.dday_unpin else R.string.dday_pin),
                        tint = if (dday.isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = stringResource(R.string.delete),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
