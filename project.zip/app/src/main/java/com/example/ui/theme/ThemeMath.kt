package com.example.ui.theme

import kotlin.math.pow

/**
 * Colour maths on ARGB Longs (0xAARRGGBB). No Android or Compose classes, so it is unit tested on the JVM
 * and the tests check the SAME function the app uses.
 */
object ThemeMath {
    const val NEAR_BLACK = 0xFF0B0C10L
    const val WHITE = 0xFFFFFFFFL

    private fun channel(value: Int): Double {
        val v = value / 255.0
        return if (v <= 0.03928) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    /** Relative luminance 0..1 (WCAG). */
    fun luminance(argb: Long): Double {
        val r = ((argb shr 16) and 0xFFL).toInt()
        val g = ((argb shr 8) and 0xFFL).toInt()
        val b = (argb and 0xFFL).toInt()
        return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b)
    }

    /** Contrast ratio 1..21 between two colours. Normal text needs 4.5, large text and icons 3. */
    fun contrast(a: Long, b: Long): Double {
        val la = luminance(a)
        val lb = luminance(b)
        return (maxOf(la, lb) + 0.05) / (minOf(la, lb) + 0.05)
    }

    /** The colour for text or icons ON [background]: near-black or white, whichever reads better. For any colour the result is at least 4.4 (the worst case is a mid-tone). */
    fun onColorFor(background: Long): Long =
        if (contrast(NEAR_BLACK, background) >= contrast(WHITE, background)) NEAR_BLACK else WHITE
}
