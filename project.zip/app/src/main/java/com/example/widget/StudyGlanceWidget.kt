package com.example.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.Button
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalSize
import androidx.glance.action.Action
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import com.example.MainActivity
import com.example.R
import com.example.StudyApplication
import com.example.data.model.Subject
import com.example.service.SessionRecovery
import com.example.service.TimerForegroundService
import com.example.service.TimerMode
import com.example.service.TimerStateManager
import com.example.service.TimerStatus
import com.example.util.DateTimeUtils
import com.example.util.LocaleHelper
import kotlinx.coroutines.flow.first

/** What the widget shows, read once per refresh. */
private data class WidgetData(
    val todayLabel: String,
    val todayTime: String,
    val status: String,
    val ddayText: String?,
    val isRunning: Boolean,
    /** False when there is no subject to start, in which case the button just opens the app. */
    val canStart: Boolean,
    val startLabel: String,
    val stopLabel: String,
    val appName: String
)

class StudyGlanceWidget : GlanceAppWidget() {
    companion object {
        val SMALL_SIZE = DpSize(100.dp, 80.dp)
        val MEDIUM_SIZE = DpSize(220.dp, 100.dp)

        suspend fun updateAll(context: Context) {
            try {
                val manager = GlanceAppWidgetManager(context)
                val glanceIds = manager.getGlanceIds(StudyGlanceWidget::class.java)
                glanceIds.forEach { id ->
                    StudyGlanceWidget().update(context, id)
                }
            } catch (_: Exception) {
            }
        }
    }

    override val sizeMode = SizeMode.Responsive(setOf(SMALL_SIZE, MEDIUM_SIZE))

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val data = loadData(context)
        provideContent {
            GlanceTheme {
                if (LocalSize.current.width < 180.dp) SmallContent(data) else MediumContent(data)
            }
        }
    }

    private suspend fun loadData(context: Context): WidgetData {
        val app = context.applicationContext as StudyApplication
        // The widget can run before the app has been opened since boot, so the timer state is rebuilt
        // from disk first. Without this a running timer would look stopped.
        try {
            SessionRecovery.restoreStateOnly(context)
        } catch (_: Exception) {
        }

        val text = LocaleHelper.localized(context)
        val settings = try {
            app.settingsRepository.settings.first()
        } catch (_: Exception) {
            null
        }
        val dayStartHour = settings?.dayStartHour ?: 5
        val now = System.currentTimeMillis()
        val (startMs, endMs) = DateTimeUtils.getStudyDayRange(now, dayStartHour)

        val sessions = try {
            app.studyRepository.getSessionsInRangeList(startMs, endMs)
        } catch (_: Exception) {
            emptyList()
        }
        var totalMillis = 0L
        for (s in sessions) totalMillis += DateTimeUtils.getSessionOverlapMillis(s, startMs, endMs)

        val timerState = TimerStateManager.timerState.value
        if (timerState.status != TimerStatus.STOPPED) {
            totalMillis += timerState.currentElapsedSeconds * 1000L
        }

        val pinned = try {
            app.studyRepository.pinnedDDay.first()
        } catch (_: Exception) {
            null
        }

        val subject = resolveSubject(context)
        val status = when {
            timerState.status != TimerStatus.STOPPED ->
                text.getString(R.string.widget_studying) + ": " + timerState.subjectName.ifEmpty { "-" }
            else -> text.getString(R.string.widget_ready)
        }

        return WidgetData(
            todayLabel = text.getString(R.string.widget_today),
            // The widget is not redrawn every second, so seconds would always be stale. Minutes are honest.
            todayTime = DateTimeUtils.formatDurationCompact(totalMillis / 1000L).let {
                if (totalMillis < 60_000L) "0m" else it
            },
            status = status,
            ddayText = pinned?.let { "${it.title}: ${it.formattedDDay(now)}" },
            isRunning = timerState.status != TimerStatus.STOPPED,
            canStart = subject != null || timerState.status != TimerStatus.STOPPED,
            startLabel = text.getString(R.string.start),
            stopLabel = text.getString(R.string.stop),
            appName = text.getString(R.string.app_name)
        )
    }

    @Composable
    private fun ToggleButton(data: WidgetData) {
        val action: Action = if (data.canStart) actionRunCallback<ToggleTimerActionCallback>()
        else actionStartActivity<MainActivity>()
        Button(text = if (data.isRunning) data.stopLabel else data.startLabel, onClick = action)
    }

    @Composable
    private fun SmallContent(data: WidgetData) {
        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(GlanceTheme.colors.widgetBackground)
                .cornerRadius(20.dp)
                .padding(10.dp)
                .clickable(actionStartActivity<MainActivity>()),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = data.todayLabel,
                    style = TextStyle(fontSize = 11.sp, color = GlanceTheme.colors.onSurfaceVariant)
                )
                Text(
                    text = data.todayTime,
                    style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold, color = GlanceTheme.colors.primary)
                )
                Spacer(modifier = GlanceModifier.height(4.dp))
                ToggleButton(data)
            }
        }
    }

    @Composable
    private fun MediumContent(data: WidgetData) {
        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(GlanceTheme.colors.widgetBackground)
                .cornerRadius(20.dp)
                .padding(14.dp)
                .clickable(actionStartActivity<MainActivity>())
        ) {
            Column(modifier = GlanceModifier.fillMaxSize()) {
                Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = data.appName,
                        style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GlanceTheme.colors.primary)
                    )
                    if (data.ddayText != null) {
                        Spacer(modifier = GlanceModifier.width(8.dp))
                        Text(
                            text = data.ddayText,
                            style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, color = GlanceTheme.colors.onSurfaceVariant)
                        )
                    }
                }
                Spacer(modifier = GlanceModifier.height(4.dp))
                Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = GlanceModifier.defaultWeight()) {
                        Text(
                            text = data.todayTime,
                            style = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold, color = GlanceTheme.colors.onSurface)
                        )
                        Text(
                            text = data.status,
                            style = TextStyle(fontSize = 11.sp, color = GlanceTheme.colors.onSurfaceVariant)
                        )
                    }
                    ToggleButton(data)
                }
            }
        }
    }
}

/** The subject the widget starts: the one selected in the app, or the first active one. Null when there is none. */
private suspend fun resolveSubject(context: Context): Subject? {
    val app = context.applicationContext as StudyApplication
    return try {
        val active = app.studyRepository.activeSubjects.first()
        val selectedId = app.settingsRepository.settings.first().selectedSubjectId
        active.firstOrNull { it.id == selectedId } ?: active.firstOrNull()
    } catch (_: Exception) {
        null
    }
}

class ToggleTimerActionCallback : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        try {
            SessionRecovery.restoreStateOnly(context)
        } catch (_: Exception) {
        }
        val current = TimerStateManager.timerState.value
        if (current.status != TimerStatus.STOPPED) {
            TimerForegroundService.stopTimer(context)
        } else {
            val subject = resolveSubject(context)
            if (subject != null) {
                TimerForegroundService.startTimer(
                    context = context,
                    subjectId = subject.id,
                    subjectName = subject.name,
                    subjectColor = subject.color,
                    mode = TimerMode.STOPWATCH
                )
            }
        }
        StudyGlanceWidget.updateAll(context)
    }
}

class StudyWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = StudyGlanceWidget()
}
