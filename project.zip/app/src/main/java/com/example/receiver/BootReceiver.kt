package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.StudyApplication
import com.example.service.TimerForegroundService
import com.example.service.TimerStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Runs after a reboot and after the app was updated. Both wipe all alarms, so they are armed again.
 * After a reboot a timer that was RUNNING is paused at its last heartbeat, otherwise the hours the phone
 * spent switched off would be counted as study time.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val appContext = context.applicationContext
        val app = appContext as? StudyApplication ?: return

        if (action == Intent.ACTION_BOOT_COMPLETED) {
            pauseTimerAfterReboot(appContext)
        }

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                ReminderScheduler.scheduleAll(appContext, app.settingsRepository)
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }
    }

    private fun pauseTimerAfterReboot(context: Context) {
        try {
            val prefs = context.getSharedPreferences(TimerForegroundService.PREFS_NAME, Context.MODE_PRIVATE)
            val status = prefs.getString(TimerForegroundService.PREF_STATUS, null)
            if (status != TimerStatus.RUNNING.name) return

            val lastResume = prefs.getLong(TimerForegroundService.PREF_LAST_RESUME, 0L)
            val accumulated = prefs.getLong(TimerForegroundService.PREF_ACCUMULATED_MS, 0L)
            val heartbeat = prefs.getLong(TimerForegroundService.PREF_HEARTBEAT, 0L)
            val studied = if (heartbeat > lastResume) heartbeat - lastResume else 0L

            prefs.edit()
                .putString(TimerForegroundService.PREF_STATUS, TimerStatus.PAUSED.name)
                .putLong(TimerForegroundService.PREF_ACCUMULATED_MS, accumulated + studied)
                .apply()
        } catch (_: Exception) {
        }
    }
}
