package com.example.util

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File

/**
 * Saves an uncaught crash to a private file and shows it on the next launch with Copy / Share buttons.
 * Plain Android Views only, so it cannot fail the same way Compose, Room or a ViewModel can.
 * Nothing is ever sent anywhere (the app has no INTERNET permission).
 */
object CrashReporter {
    private const val FILE_NAME = "last_crash.txt"
    private const val MAX_CHARS = 20_000

    fun install(context: Context) {
        try {
            val appContext = context.applicationContext
            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, error ->
                try {
                    write(appContext, thread, error)
                } catch (_: Throwable) {
                }
                previous?.uncaughtException(thread, error)
            }
        } catch (_: Throwable) {
        }
    }

    private fun write(context: Context, thread: Thread, error: Throwable) {
        val header = buildString {
            append("Parallax Tracker crash report\n")
            append("Time: ").append(java.util.Date().toString()).append('\n')
            append("Thread: ").append(thread.name).append('\n')
            append("Phone: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
            append("Android: ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n\n")
        }
        File(context.filesDir, FILE_NAME).writeText((header + Log.getStackTraceString(error)).take(MAX_CHARS))
    }

    fun pending(context: Context): String? = try {
        val f = File(context.filesDir, FILE_NAME)
        if (f.exists()) f.readText().ifBlank { null } else null
    } catch (_: Throwable) {
        null
    }

    fun clear(context: Context) {
        try {
            File(context.filesDir, FILE_NAME).delete()
        } catch (_: Throwable) {
        }
    }

    fun show(activity: Activity, text: String, onTryAgain: () -> Unit) {
        val dp = { v: Int ->
            TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), activity.resources.displayMetrics).toInt()
        }
        val title = TextView(activity).apply {
            this.text = "The app crashed last time"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTypeface(typeface, Typeface.BOLD)
        }
        val hint = TextView(activity).apply {
            this.text = "Tap Copy, then paste the text into the chat so the cause can be fixed."
            setTextColor(Color.parseColor("#9AA7B4"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(0, dp(6), 0, dp(12))
        }
        val body = TextView(activity).apply {
            this.text = text
            setTextColor(Color.parseColor("#E6EDF3"))
            typeface = Typeface.MONOSPACE
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(activity).apply { addView(body) }

        fun button(label: String, onClick: () -> Unit) = Button(activity).apply {
            this.text = label
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        val copy = button("Copy") {
            try {
                (activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("crash report", text))
            } catch (_: Throwable) {
            }
        }
        val share = button("Share") {
            try {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                activity.startActivity(Intent.createChooser(send, "Share crash report"))
            } catch (_: Throwable) {
            }
        }
        val again = button("Clear and try again") {
            clear(activity)
            onTryAgain()
        }

        val buttons = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            val lp = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) }
            addView(copy, lp())
            addView(share, lp())
            addView(again, lp())
        }
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0F14"))
            addView(title)
            addView(hint)
            addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(buttons)
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v: View, insets: WindowInsetsCompat ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val pad = dp(16)
            v.setPadding(bars.left + pad, bars.top + pad, bars.right + pad, bars.bottom + pad)
            WindowInsetsCompat.CONSUMED
        }
        activity.setContentView(root)
    }
}
