package com.example.util

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/**
 * The app language ("en" or "bn") is mirrored in a tiny SharedPreferences file so code that has no
 * Compose context (notifications, the service, the widget, receivers) can read it synchronously.
 */
object LocaleHelper {
    private const val PREFS = "ui_locale"
    private const val KEY_LANGUAGE = "language"

    fun save(context: Context, language: String) {
        try {
            context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_LANGUAGE, language).apply()
        } catch (_: Exception) {
        }
    }

    fun language(context: Context): String = try {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LANGUAGE, "en") ?: "en"
    } catch (_: Exception) {
        "en"
    }

    fun localeFor(language: String): Locale = Locale(language)

    /** Makes java formatters (day names, months) follow the app language too. */
    fun applyDefaultLocale(context: Context) {
        try {
            Locale.setDefault(localeFor(language(context)))
        } catch (_: Exception) {
        }
    }

    /** A context whose resources use the app language. Use for notification and widget text. */
    fun localized(context: Context): Context = try {
        val config = Configuration(context.resources.configuration)
        config.setLocale(localeFor(language(context)))
        context.createConfigurationContext(config)
    } catch (_: Exception) {
        context
    }
}
