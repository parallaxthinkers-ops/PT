package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.TaskCompletion
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskCompletionDao {
    @Query("SELECT * FROM task_completions WHERE date = :date")
    fun getCompletionsForDateFlow(date: String): Flow<List<TaskCompletion>>

    @Query("SELECT * FROM task_completions WHERE date = :date")
    suspend fun getCompletionsForDate(date: String): List<TaskCompletion>

    @Query("SELECT * FROM task_completions")
    suspend fun getAllCompletionsList(): List<TaskCompletion>

    @Query("SELECT EXISTS(SELECT 1 FROM task_completions WHERE taskId = :taskId AND date = :date)")
    suspend fun isCompleted(taskId: Long, date: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markCompleted(completion: TaskCompletion)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(completions: List<TaskCompletion>)

    @Query("DELETE FROM task_completions WHERE taskId = :taskId AND date = :date")
    suspend fun unmarkCompleted(taskId: Long, date: String)

    @Query("DELETE FROM task_completions WHERE taskId = :taskId")
    suspend fun deleteForTask(taskId: Long)

    @Query("DELETE FROM task_completions")
    suspend fun deleteAll()
}
