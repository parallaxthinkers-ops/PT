package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.StudyTask
import com.example.data.model.Subject

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditTaskDialog(
    initialTask: StudyTask? = null,
    subjects: List<Subject>,
    onDismiss: () -> Unit,
    onSave: (title: String, subjectId: Long?, plannedMinutes: Int, repeatRule: String) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    var title by remember { mutableStateOf(initialTask?.title ?: "") }
    var selectedSubjectId by remember { mutableStateOf(initialTask?.subjectId) }
    var plannedMinutesStr by remember {
        mutableStateOf(if ((initialTask?.plannedMinutes ?: 0) > 0) initialTask?.plannedMinutes.toString() else "30")
    }
    var selectedRepeat by remember { mutableStateOf(initialTask?.repeatRule ?: "NONE") }
    var isError by remember { mutableStateOf(false) }

    val repeatOptions = listOf(
        "NONE" to stringResource(R.string.repeat_none),
        "DAILY" to stringResource(R.string.repeat_daily),
        "WEEKDAYS" to stringResource(R.string.repeat_weekdays),
        "WEEKLY" to stringResource(R.string.repeat_weekly)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(stringResource(if (initialTask == null) R.string.planner_new_task else R.string.edit_task))
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it.take(120)
                        isError = it.isBlank()
                    },
                    label = { Text(stringResource(R.string.task_title)) },
                    isError = isError,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("task_title_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = plannedMinutesStr,
                    onValueChange = { input ->
                        if (input.length <= 4 && input.all { it.isDigit() }) plannedMinutesStr = input
                    },
                    label = { Text(stringResource(R.string.planned_duration)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(stringResource(R.string.planner_subject_optional), style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    FilterChip(
                        selected = selectedSubjectId == null,
                        onClick = { selectedSubjectId = null },
                        label = { Text(stringResource(R.string.planner_no_subject)) }
                    )
                    subjects.forEach { subject ->
                        FilterChip(
                            selected = selectedSubjectId == subject.id,
                            onClick = { selectedSubjectId = subject.id },
                            leadingIcon = { ColorDot(Color(subject.color)) },
                            label = { Text(subject.name) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(stringResource(R.string.repeat), style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    repeatOptions.forEach { (key, label) ->
                        FilterChip(
                            selected = selectedRepeat == key,
                            onClick = { selectedRepeat = key },
                            label = { Text(label) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(title.trim(), selectedSubjectId, plannedMinutesStr.toIntOrNull() ?: 0, selectedRepeat)
                    } else {
                        isError = true
                    }
                },
                modifier = Modifier.testTag("save_task_button")
            ) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (onDelete != null) {
                    TextButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.testTag("delete_task_button")
                    ) {
                        Text(stringResource(R.string.delete))
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.cancel))
                }
            }
        }
    )
}
