package com.example.ui.screens.settings

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BuildConfig
import com.example.R
import com.example.ui.components.AppCard
import com.example.ui.components.AccentPicker
import com.example.ui.components.AppTimePickerDialog
import com.example.ui.components.PillSelector
import com.example.ui.components.PomodoroSettingsDialog
import com.example.ui.components.RowDivider
import com.example.ui.components.ScreenHeader
import com.example.ui.components.SectionLabel
import com.example.ui.components.SettingNavRow
import com.example.ui.components.SettingSwitchRow
import com.example.ui.theme.Ui
import com.example.util.DateTimeUtils
import com.example.util.StudyMath
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Calendar
import java.util.Locale
import kotlinx.coroutines.launch

/** Where feedback is sent. Shown on screen too, in case the phone has no email app. */
private const val FEEDBACK_EMAIL = "parallaxthinkers@gmail.com"

private sealed interface SettingsDialog {
    data object DayStart : SettingsDialog
    data object Pomodoro : SettingsDialog
    data object UniformGoal : SettingsDialog
    data class WeekdayGoal(val weekday: Int) : SettingsDialog
    data object StudyTime : SettingsDialog
    data object Subjects : SettingsDialog
    data object Reset : SettingsDialog
}

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateToDDay: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val s = state.settings
    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? -> if (uri != null) viewModel.exportBackup(uri) }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> if (uri != null) viewModel.prepareImportFile(uri) }

    // The folder for scheduled backups. The system picker also lists Google Drive, when its app is installed.
    val folderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? -> if (uri != null) viewModel.chooseAutoBackupFolder(uri) }

    // Help and suggestions: text is read here because the click handlers are not composable.
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val mailSubject = stringResource(R.string.help_mail_subject)
    val mailFooter = stringResource(R.string.help_mail_footer, BuildConfig.VERSION_NAME, Build.VERSION.RELEASE.orEmpty(), Build.MODEL.orEmpty())
    val copiedText = stringResource(R.string.help_copied)
    val noMailText = stringResource(R.string.help_no_mail)
    val dailyLabel = stringResource(R.string.autobk_daily)

    fun copyEmail(message: String) {
        clipboard.setText(AnnotatedString(FEEDBACK_EMAIL))
        scope.launch { snackbarHostState.showSnackbar(message) }
    }

    fun sendFeedback() {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, arrayOf(FEEDBACK_EMAIL))
            putExtra(Intent.EXTRA_SUBJECT, mailSubject)
            putExtra(Intent.EXTRA_TEXT, "\n\n--\n" + mailFooter)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            // No email app on this phone: give the address to the person instead of failing silently.
            copyEmail(noMailText)
        }
    }

    // Backup results arrive as a short message. Show it once, then clear it.
    val message = state.backupMessage
    LaunchedEffect(message) {
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            viewModel.dismissBackupMessage()
        }
    }

    // Text that the selector labels need. They are read here because selector label lambdas are not composable.
    val modeLabels = mapOf(
        "SYSTEM" to stringResource(R.string.theme_mode_system),
        "LIGHT" to stringResource(R.string.theme_mode_light),
        "DARK" to stringResource(R.string.theme_mode_dark)
    )
    val styleLabels = mapOf(
        "MINIMAL" to stringResource(R.string.style_minimal),
        "SOFT" to stringResource(R.string.style_soft)
    )
    val cornerLabels = mapOf(
        "SHARP" to stringResource(R.string.corner_sharp),
        "ROUNDED" to stringResource(R.string.corner_rounded),
        "PILL" to stringResource(R.string.corner_pill)
    )
    val timerModeLabels = mapOf(
        "STOPWATCH" to stringResource(R.string.mode_stopwatch),
        "COUNTDOWN" to stringResource(R.string.mode_countdown),
        "POMODORO" to stringResource(R.string.mode_pomodoro)
    )
    val noGoal = stringResource(R.string.settings_goal_none)
    val nMinutes = stringResource(R.string.settings_n_minutes, "%d")
    val nDays = stringResource(R.string.settings_n_days, "%d")

    fun goalMinutes(weekday: Int): Int = state.goals.firstOrNull { it.weekday == weekday }?.targetMinutes ?: 240
    fun goalLabel(minutes: Int): String = if (minutes <= 0) noGoal else DateTimeUtils.formatDurationCompact(minutes * 60L)

    val todayWeekday = StudyMath.calendarWeekday(LocalDate.now())
    val weekdayOrder = (0 until 7).map { ((s.firstDayOfWeek - 1 + it) % 7) + 1 }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            ScreenHeader(title = stringResource(R.string.nav_settings))
            if (state.busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp))
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
            ) {
                // ---- Appearance --------------------------------------------------------------------
                SettingsGroup(stringResource(R.string.settings_appearance)) {
                    ControlBlock(stringResource(R.string.settings_theme_mode)) {
                        PillSelector(
                            options = listOf("SYSTEM", "LIGHT", "DARK"),
                            selected = s.themeMode.uppercase(),
                            label = { modeLabels[it] ?: it },
                            onSelect = { viewModel.setThemeMode(it) }
                        )
                    }
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.settings_amoled),
                        subtitle = stringResource(R.string.settings_amoled_desc),
                        checked = s.amoled,
                        onCheckedChange = { viewModel.setAmoled(it) }
                    )
                    RowDivider()
                    ControlBlock(
                        title = stringResource(R.string.settings_style),
                        subtitle = stringResource(
                            if (s.themeStyle == "SOFT") R.string.settings_style_soft_desc else R.string.settings_style_minimal_desc
                        )
                    ) {
                        PillSelector(
                            options = listOf("MINIMAL", "SOFT"),
                            selected = s.themeStyle,
                            label = { styleLabels[it] ?: it },
                            onSelect = { viewModel.setThemeStyle(it) }
                        )
                    }
                    RowDivider()
                    ControlBlock(stringResource(R.string.settings_corners)) {
                        PillSelector(
                            options = listOf("SHARP", "ROUNDED", "PILL"),
                            selected = s.cornerStyle,
                            label = { cornerLabels[it] ?: it },
                            onSelect = { viewModel.setCornerStyle(it) }
                        )
                    }
                    RowDivider()
                    ControlBlock(stringResource(R.string.settings_accent)) {
                        AccentPicker(selected = s.accentColor, onSelect = { viewModel.setAccentColor(it) })
                    }
                    RowDivider()
                    ControlBlock(stringResource(R.string.settings_language)) {
                        PillSelector(
                            options = listOf("en", "bn"),
                            selected = s.language,
                            // A language is always written in itself, so these two names are not translated.
                            label = { if (it == "bn") "বাংলা" else "English" },
                            onSelect = { viewModel.setLanguage(it) }
                        )
                    }
                }

                // ---- Timer -------------------------------------------------------------------------
                SettingsGroup(stringResource(R.string.settings_timer)) {
                    ControlBlock(stringResource(R.string.settings_default_mode)) {
                        PillSelector(
                            // Stopwatch is still one tap away on the Timer screen; the default is Countdown or Pomodoro.
                            options = listOf("COUNTDOWN", "POMODORO"),
                            selected = if (s.defaultTimerMode == "POMODORO") "POMODORO" else "COUNTDOWN",
                            label = { timerModeLabels[it] ?: it },
                            onSelect = { viewModel.setDefaultTimerMode(it) }
                        )
                    }
                    RowDivider()
                    SettingNavRow(
                        title = stringResource(R.string.pomodoro_settings),
                        value = "${s.pomoFocusMinutes} / ${s.pomoShortBreakMinutes} / ${s.pomoLongBreakMinutes}",
                        onClick = { dialog = SettingsDialog.Pomodoro }
                    )
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.pomo_auto_start),
                        subtitle = stringResource(R.string.pomo_auto_start_desc),
                        checked = s.pomoAutoStart,
                        onCheckedChange = { viewModel.setPomoAutoStart(it) }
                    )
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.keep_screen_on),
                        subtitle = stringResource(R.string.keep_screen_on_desc),
                        checked = s.keepScreenOn,
                        onCheckedChange = { viewModel.setKeepScreenOn(it) }
                    )
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.settings_sound),
                        subtitle = stringResource(R.string.settings_sound_desc),
                        checked = s.soundEnabled,
                        onCheckedChange = { viewModel.setSoundEnabled(it) }
                    )
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.settings_vibration),
                        subtitle = stringResource(R.string.settings_vibration_desc),
                        checked = s.vibrationEnabled,
                        onCheckedChange = { viewModel.setVibrationEnabled(it) }
                    )
                }

                // ---- Focus mode --------------------------------------------------------------------
                SettingsGroup(stringResource(R.string.focus_mode)) {
                    SettingSwitchRow(
                        title = stringResource(R.string.focus_ambient_mode),
                        subtitle = stringResource(R.string.focus_ambient_desc),
                        checked = s.ambientMode,
                        onCheckedChange = { viewModel.setAmbientMode(it) }
                    )
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.focus_dnd_prompt),
                        subtitle = stringResource(R.string.focus_dnd_desc),
                        checked = s.dndPromptEnabled,
                        onCheckedChange = { viewModel.setDndPromptEnabled(it) }
                    )
                }

                // ---- Study day ---------------------------------------------------------------------
                SettingsGroup(stringResource(R.string.settings_study_day)) {
                    SettingNavRow(
                        title = stringResource(R.string.day_start_time),
                        subtitle = stringResource(R.string.day_start_desc),
                        value = DateTimeUtils.formatHourLabel(s.dayStartHour, s.is12Hour),
                        onClick = { dialog = SettingsDialog.DayStart }
                    )
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.settings_12_hour),
                        checked = s.is12Hour,
                        onCheckedChange = { viewModel.set12HourFormat(it) }
                    )
                    RowDivider()
                    ControlBlock(stringResource(R.string.settings_first_day)) {
                        PillSelector(
                            options = listOf(Calendar.MONDAY, Calendar.SUNDAY, Calendar.SATURDAY),
                            selected = s.firstDayOfWeek,
                            label = { weekdayName(it, TextStyle.FULL) },
                            onSelect = { viewModel.setFirstDayOfWeek(it) }
                        )
                    }
                }

                // ---- Goals -------------------------------------------------------------------------
                SettingsGroup(stringResource(R.string.settings_goals)) {
                    SettingSwitchRow(
                        title = stringResource(R.string.different_goal_weekday),
                        checked = s.differentGoalPerWeekday,
                        onCheckedChange = { viewModel.setDifferentGoalPerWeekday(it) }
                    )
                    RowDivider()
                    if (!s.differentGoalPerWeekday) {
                        SettingNavRow(
                            title = stringResource(R.string.settings_goal_every_day),
                            value = goalLabel(goalMinutes(todayWeekday)),
                            onClick = { dialog = SettingsDialog.UniformGoal }
                        )
                    } else {
                        weekdayOrder.forEachIndexed { index, weekday ->
                            if (index > 0) RowDivider()
                            SettingNavRow(
                                title = weekdayName(weekday, TextStyle.FULL),
                                value = goalLabel(goalMinutes(weekday)),
                                onClick = { dialog = SettingsDialog.WeekdayGoal(weekday) }
                            )
                        }
                    }
                }

                // ---- Reminders ---------------------------------------------------------------------
                SettingsGroup(stringResource(R.string.reminders_title)) {
                    SettingSwitchRow(
                        title = stringResource(R.string.study_reminder_title),
                        subtitle = stringResource(R.string.study_reminder_desc),
                        checked = s.studyReminderEnabled,
                        onCheckedChange = {
                            viewModel.setStudyReminder(it, s.studyReminderHour, s.studyReminderMinute, s.studyReminderDays)
                        }
                    )
                    if (s.studyReminderEnabled) {
                        RowDivider()
                        SettingNavRow(
                            title = stringResource(R.string.study_reminder_time),
                            value = clockLabel(s.studyReminderHour, s.studyReminderMinute, s.is12Hour),
                            onClick = { dialog = SettingsDialog.StudyTime }
                        )
                        RowDivider()
                        ControlBlock(stringResource(R.string.study_reminder_days)) {
                            DayChips(
                                order = weekdayOrder,
                                selected = s.studyReminderDays,
                                onToggle = { weekday ->
                                    val updated = if (weekday in s.studyReminderDays) s.studyReminderDays - weekday
                                    else s.studyReminderDays + weekday
                                    // At least one day has to stay on, otherwise the reminder could never fire.
                                    if (updated.isNotEmpty()) {
                                        viewModel.setStudyReminder(true, s.studyReminderHour, s.studyReminderMinute, updated)
                                    }
                                }
                            )
                        }
                    }
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.break_reminder_title),
                        subtitle = stringResource(R.string.break_reminder_desc),
                        checked = s.breakReminderEnabled,
                        onCheckedChange = { viewModel.setBreakReminder(it, s.breakReminderMinutes) }
                    )
                    if (s.breakReminderEnabled) {
                        RowDivider()
                        ControlBlock(stringResource(R.string.break_reminder_interval)) {
                            val options = (listOf(30, 45, 60, 90, 120) + s.breakReminderMinutes).distinct().sorted()
                            PillSelector(
                                options = options,
                                selected = s.breakReminderMinutes,
                                label = { nMinutes.replace("%d", it.toString()) },
                                onSelect = { viewModel.setBreakReminder(true, it) }
                            )
                        }
                    }
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.settings_backup_reminder),
                        subtitle = stringResource(R.string.settings_backup_reminder_desc),
                        checked = s.autoBackupReminderEnabled,
                        onCheckedChange = { viewModel.setAutoBackupReminder(it, s.autoBackupReminderDays) }
                    )
                    if (s.autoBackupReminderEnabled) {
                        RowDivider()
                        ControlBlock(stringResource(R.string.settings_backup_every)) {
                            val options = (listOf(3, 7, 14, 30) + s.autoBackupReminderDays).distinct().sorted()
                            PillSelector(
                                options = options,
                                selected = s.autoBackupReminderDays,
                                label = { nDays.replace("%d", it.toString()) },
                                onSelect = { viewModel.setAutoBackupReminder(true, it) }
                            )
                        }
                    }
                }

                // ---- Subjects and D-Days -----------------------------------------------------------
                SettingsGroup(stringResource(R.string.subjects)) {
                    SettingNavRow(
                        title = stringResource(R.string.settings_manage_subjects),
                        subtitle = stringResource(R.string.settings_manage_subjects_desc),
                        icon = Icons.Filled.Edit,
                        onClick = { dialog = SettingsDialog.Subjects }
                    )
                    RowDivider()
                    SettingNavRow(
                        title = stringResource(R.string.manage_ddays),
                        icon = Icons.Filled.Event,
                        onClick = onNavigateToDDay
                    )
                }

                // ---- Scheduled backup --------------------------------------------------------------
                val hasFolder = s.autoBackupFolderUri.isNotBlank()
                SettingsGroup(stringResource(R.string.autobk_title)) {
                    SettingSwitchRow(
                        title = stringResource(R.string.autobk_switch_title),
                        subtitle = stringResource(R.string.autobk_switch_desc),
                        checked = s.autoBackupEnabled && hasFolder,
                        onCheckedChange = { on ->
                            if (state.busy) return@SettingSwitchRow
                            if (!on) {
                                viewModel.setAutoBackupEnabled(false)
                            } else if (!hasFolder) {
                                folderLauncher.launch(null)
                            } else {
                                viewModel.setAutoBackupEnabled(true)
                            }
                        }
                    )
                    RowDivider()
                    SettingNavRow(
                        title = stringResource(R.string.autobk_folder_title),
                        subtitle = stringResource(R.string.autobk_folder_hint),
                        value = if (hasFolder) s.autoBackupFolderName.ifBlank { "..." } else stringResource(R.string.autobk_folder_none),
                        onClick = { if (!state.busy) folderLauncher.launch(null) }
                    )
                    if (hasFolder) {
                        RowDivider()
                        ControlBlock(stringResource(R.string.autobk_every)) {
                            val options = (listOf(1, 3, 7, 30) + s.autoBackupIntervalDays).distinct().sorted()
                            PillSelector(
                                options = options,
                                selected = s.autoBackupIntervalDays,
                                label = { if (it == 1) dailyLabel else nDays.replace("%d", it.toString()) },
                                onSelect = { viewModel.setAutoBackupPlan(it, s.autoBackupKeep) }
                            )
                        }
                        RowDivider()
                        ControlBlock(stringResource(R.string.autobk_keep), stringResource(R.string.autobk_keep_desc)) {
                            val options = (listOf(3, 7, 14, 30) + s.autoBackupKeep).distinct().sorted()
                            PillSelector(
                                options = options,
                                selected = s.autoBackupKeep,
                                label = { it.toString() },
                                onSelect = { viewModel.setAutoBackupPlan(s.autoBackupIntervalDays, it) }
                            )
                        }
                        RowDivider()
                        SettingNavRow(
                            title = stringResource(R.string.autobk_now),
                            icon = Icons.Filled.Download,
                            showChevron = false,
                            onClick = { if (!state.busy) viewModel.backupNow() }
                        )
                        RowDivider()
                        val failed = s.autoBackupLastError.isNotEmpty()
                        Text(
                            text = when {
                                failed -> stringResource(R.string.autobk_last_fail, s.autoBackupLastError)
                                s.autoBackupLastSuccess > 0L ->
                                    stringResource(R.string.autobk_last_ok, DateTimeUtils.formatDate(s.autoBackupLastSuccess))
                                else -> stringResource(R.string.autobk_none_yet)
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (failed) Ui.extra.danger else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                }

                // ---- Data and backup ---------------------------------------------------------------
                SettingsGroup(stringResource(R.string.settings_data)) {
                    SettingNavRow(
                        title = stringResource(R.string.backup_export),
                        subtitle = stringResource(R.string.settings_export_desc),
                        icon = Icons.Filled.Download,
                        onClick = {
                            if (!state.busy) {
                                exportLauncher.launch("parallaxtracker-backup-${DateTimeUtils.formatDateKey(LocalDate.now())}.json")
                            }
                        }
                    )
                    RowDivider()
                    SettingNavRow(
                        title = stringResource(R.string.backup_import),
                        subtitle = stringResource(R.string.settings_import_desc),
                        icon = Icons.Filled.Upload,
                        onClick = {
                            if (!state.busy) importLauncher.launch(arrayOf("application/json", "*/*"))
                        }
                    )
                    RowDivider()
                    Text(
                        text = if (s.lastBackupTime > 0L) {
                            stringResource(R.string.settings_last_backup, DateTimeUtils.formatDate(s.lastBackupTime))
                        } else {
                            stringResource(R.string.settings_never_backed_up)
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                    RowDivider()
                    DangerRow(
                        title = stringResource(R.string.settings_reset),
                        subtitle = stringResource(R.string.settings_reset_desc),
                        onClick = { if (!state.busy) dialog = SettingsDialog.Reset }
                    )
                }

                // ---- Help and suggestions ------------------------------------------------------------
                SectionLabel(stringResource(R.string.help_title))
                AppCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp)) {
                    Text(
                        text = stringResource(R.string.help_heading),
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.help_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = FEEDBACK_EMAIL,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { sendFeedback() }, modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.help_send))
                        }
                        OutlinedButton(onClick = { copyEmail(copiedText) }, modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.help_copy))
                        }
                    }
                }

                // ---- About -------------------------------------------------------------------------
                SectionLabel(stringResource(R.string.settings_about))
                AboutCard()

                Spacer(Modifier.height(28.dp))
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }

    // ---- Dialogs ---------------------------------------------------------------------------------
    when (val d = dialog) {
        null -> Unit
        SettingsDialog.DayStart -> DayStartDialog(
            initialHour = s.dayStartHour,
            is12Hour = s.is12Hour,
            onDismiss = { dialog = null },
            onSave = { viewModel.setDayStartHour(it); dialog = null }
        )
        SettingsDialog.Pomodoro -> PomodoroSettingsDialog(
            initialFocusMinutes = s.pomoFocusMinutes,
            initialShortBreakMinutes = s.pomoShortBreakMinutes,
            initialLongBreakMinutes = s.pomoLongBreakMinutes,
            initialInterval = s.pomoInterval,
            onDismiss = { dialog = null },
            onSave = { focus, shortBreak, longBreak, interval ->
                viewModel.setPomodoroDurations(focus, shortBreak, longBreak, interval)
                dialog = null
            }
        )
        SettingsDialog.UniformGoal -> GoalDialog(
            title = stringResource(R.string.settings_goal_every_day),
            initialMinutes = goalMinutes(todayWeekday),
            onDismiss = { dialog = null },
            onSave = { viewModel.setUniformGoalMinutes(it); dialog = null }
        )
        is SettingsDialog.WeekdayGoal -> GoalDialog(
            title = weekdayName(d.weekday, TextStyle.FULL),
            initialMinutes = goalMinutes(d.weekday),
            onDismiss = { dialog = null },
            onSave = { viewModel.setWeekdayGoalMinutes(d.weekday, it); dialog = null }
        )
        SettingsDialog.StudyTime -> AppTimePickerDialog(
            title = stringResource(R.string.study_reminder_time),
            initialHour = s.studyReminderHour,
            initialMinute = s.studyReminderMinute,
            is24Hour = !s.is12Hour,
            onDismiss = { dialog = null },
            onConfirm = { hour, minute ->
                viewModel.setStudyReminder(s.studyReminderEnabled, hour, minute, s.studyReminderDays)
                dialog = null
            }
        )
        SettingsDialog.Subjects -> ManageSubjectsDialog(
            active = state.activeSubjects,
            archived = state.archivedSubjects,
            onMove = { id, direction -> viewModel.moveSubject(id, direction) },
            onRestore = { viewModel.restoreSubject(it) },
            onDismiss = { dialog = null }
        )
        SettingsDialog.Reset -> ResetDialog(
            onDismiss = { dialog = null },
            onConfirm = { viewModel.resetAllData(); dialog = null }
        )
    }

    val pending = state.pendingBackupSummary
    if (pending != null) {
        RestoreSummaryDialog(
            summary = pending,
            onDismiss = { viewModel.cancelRestore() },
            onConfirm = { viewModel.confirmRestore() }
        )
    }
}

// ---- Building blocks -----------------------------------------------------------------------------

@Composable
private fun SettingsGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    SectionLabel(title)
    AppCard(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        content = content
    )
}

/** A title (and optional hint) with a control underneath, for selectors that need the full width. */
@Composable
private fun ControlBlock(
    title: String,
    subtitle: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurface)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun DayChips(order: List<Int>, selected: Set<Int>, onToggle: (Int) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        order.forEach { weekday ->
            val on = weekday in selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(MaterialTheme.shapes.small)
                    .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onToggle(weekday) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = weekdayName(weekday, TextStyle.SHORT),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (on) Ui.extra.onAccent else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun DangerRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Delete, contentDescription = null, tint = Ui.extra.danger, modifier = Modifier.size(22.dp))
        Spacer(Modifier.size(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = Ui.extra.danger)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AboutCard() {
    AppCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(20.dp)) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.logo_mark),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(56.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = stringResource(R.string.about_version, BuildConfig.VERSION_NAME),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            RowDivider()
            Spacer(Modifier.height(16.dp))
            Text(
                text = stringResource(R.string.about_offline_title),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = stringResource(R.string.about_offline_desc),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))
            Text(
                text = stringResource(R.string.about_credit),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ---- Helpers -------------------------------------------------------------------------------------

/** Name of a weekday in the app language. [weekday] uses Calendar numbering (Sunday = 1 .. Saturday = 7). */
private fun weekdayName(weekday: Int, style: TextStyle): String {
    val day = if (weekday == Calendar.SUNDAY) DayOfWeek.SUNDAY else DayOfWeek.of(((weekday - 2) % 7 + 7) % 7 + 1)
    return day.getDisplayName(style, Locale.getDefault())
}

/** "07:30" or "7:30 AM" with ASCII digits. */
private fun clockLabel(hour: Int, minute: Int, is12Hour: Boolean): String =
    if (is12Hour) {
        val twelve = if (hour % 12 == 0) 12 else hour % 12
        String.format(Locale.US, "%d:%02d %s", twelve, minute, if (hour < 12) "AM" else "PM")
    } else {
        String.format(Locale.US, "%02d:%02d", hour, minute)
    }
