package com.example.ui.screens.timer

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.Subject
import com.example.service.PomodoroPhase
import com.example.service.TimerMode
import com.example.service.TimerStatus
import com.example.ui.components.AppAlertDialog
import com.example.ui.components.AddEditSubjectDialog
import com.example.ui.components.AppCard
import com.example.ui.components.CircularProgressTimer
import com.example.ui.components.ColorDot
import com.example.ui.components.CountdownDurationPickerDialog
import com.example.ui.components.DeleteSubjectConfirmDialog
import com.example.ui.components.EmptyState
import com.example.ui.components.GlassButton
import com.example.ui.components.glassPanel
import com.example.ui.components.rememberGlassLook
import com.example.ui.components.PillSelector
import com.example.ui.components.PomodoroSettingsDialog
import com.example.ui.components.RowDivider
import com.example.ui.components.SectionLabel
import com.example.ui.theme.NumberStyle
import com.example.ui.theme.rememberBrandFont
import com.example.ui.theme.timerDigitsStyle
import com.example.ui.theme.Ui
import com.example.util.DateTimeUtils
import java.util.Locale

@Composable
fun TimerScreen(
    viewModel: TimerViewModel,
    onNavigateToFocus: () -> Unit,
    onNavigateToDDay: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Coarse state only. The per-second clock is read inside small leaf composables below,
    // so this whole screen is NOT recomposed every second.
    val ui by viewModel.uiState.collectAsStateWithLifecycle()
    val run = ui.run
    val stopped = run.status == TimerStatus.STOPPED

    var selectedMode by remember { mutableStateOf(TimerMode.COUNTDOWN) }
    LaunchedEffect(ui.settings.defaultTimerMode) {
        if (stopped) {
            selectedMode = when (ui.settings.defaultTimerMode) {
                "COUNTDOWN" -> TimerMode.COUNTDOWN
                "POMODORO" -> TimerMode.POMODORO
                else -> TimerMode.STOPWATCH
            }
        }
    }

    var showAddSubjectDialog by remember { mutableStateOf(false) }
    var editingSubject by remember { mutableStateOf<Subject?>(null) }
    var deletingSubject by remember { mutableStateOf<Subject?>(null) }
    var showCannotDeleteRunningAlert by remember { mutableStateOf(false) }
    var showCountdownDurationPicker by remember { mutableStateOf(false) }
    var showPomodoroSettingsDialog by remember { mutableStateOf(false) }

    val primary = MaterialTheme.colorScheme.primary
    val selectedSubject = ui.subjects.find { it.id == ui.selectedSubjectId }
    val activeColor = if (!stopped) {
        Color(ui.subjects.find { it.id == run.subjectId }?.color ?: run.subjectColor)
    } else {
        selectedSubject?.let { Color(it.color) } ?: primary
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp, bottom = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        TopBar(
            ui = ui,
            onNavigateToDDay = onNavigateToDDay,
            onNavigateToFocus = onNavigateToFocus
        )

        NotificationBanner()

        Spacer(Modifier.height(14.dp))

        if (stopped) {
            // PillSelector's label lambda is not composable, so the texts are resolved here first.
            val modeLabels = mapOf(
                TimerMode.STOPWATCH to stringResource(R.string.mode_stopwatch),
                TimerMode.COUNTDOWN to stringResource(R.string.mode_countdown),
                TimerMode.POMODORO to stringResource(R.string.mode_pomodoro)
            )
            PillSelector(
                options = TimerMode.values().toList(),
                selected = selectedMode,
                label = { mode -> modeLabels[mode].orEmpty() },
                onSelect = { selectedMode = it }
            )
        } else {
            RunningModeChip(ui = ui, color = activeColor)
        }

        // Countdown presets (only while stopped in Countdown mode)
        if (stopped && selectedMode == TimerMode.COUNTDOWN) {
            Spacer(Modifier.height(12.dp))
            CountdownPresets(
                ui = ui,
                onSelect = { viewModel.selectPresetMinutes(it) },
                onDelete = { viewModel.deleteCustomPreset(it) },
                onCustom = { showCountdownDurationPicker = true }
            )
        }

        // Pomodoro phase + skip while running
        if (!stopped && run.mode == TimerMode.POMODORO) {
            Spacer(Modifier.height(12.dp))
            PomodoroPhaseRow(
                phase = run.phase,
                cycle = run.cycle,
                interval = ui.settings.pomoInterval,
                color = activeColor,
                onSkip = { viewModel.skipPomodoroPhase() }
            )
        }

        Spacer(Modifier.height(20.dp))

        TimerHero(
            viewModel = viewModel,
            ui = ui,
            selectedMode = selectedMode,
            activeColor = activeColor,
            subjectName = selectedSubject?.name,
            onClockClick = {
                if (selectedMode == TimerMode.COUNTDOWN) showCountdownDurationPicker = true
                else if (selectedMode == TimerMode.POMODORO) showPomodoroSettingsDialog = true
            }
        )

        Spacer(Modifier.height(20.dp))

        // +/- 1 minute while a countdown runs
        if (!stopped && run.mode == TimerMode.COUNTDOWN) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(bottom = 14.dp)
            ) {
                GlassButton(
                    onClick = { viewModel.adjustRunningCountdown(-60L) },
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.testTag("countdown_minus_1m")
                ) { Text(stringResource(R.string.countdown_adjust_minus_1m), fontWeight = FontWeight.SemiBold) }
                GlassButton(
                    onClick = { viewModel.adjustRunningCountdown(60L) },
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.testTag("countdown_adjust_plus_1m")
                ) { Text(stringResource(R.string.countdown_adjust_plus_1m), fontWeight = FontWeight.SemiBold) }
            }
        }

        Controls(
            status = run.status,
            canStart = ui.subjects.isNotEmpty(),
            color = activeColor,
            onStart = { viewModel.startTimer(selectedMode) },
            onPause = { viewModel.pauseTimer() },
            onResume = { viewModel.resumeTimer() },
            onStop = { viewModel.stopTimer() }
        )

        Spacer(Modifier.height(24.dp))

        TodaySummary(viewModel = viewModel, ui = ui)

        // Subjects
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f)) { SectionLabel(stringResource(R.string.subjects)) }
            IconButton(
                onClick = { showAddSubjectDialog = true },
                modifier = Modifier
                    .padding(top = 12.dp)
                    .testTag("add_subject_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = stringResource(R.string.add_subject))
            }
        }

        if (ui.subjectStats.isEmpty()) {
            AppCard(modifier = Modifier.fillMaxWidth()) {
                EmptyState(
                    icon = Icons.Default.Add,
                    title = stringResource(R.string.timer_no_subjects_title),
                    message = stringResource(R.string.timer_no_subjects_desc)
                )
                Button(
                    onClick = { showAddSubjectDialog = true },
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .testTag("empty_add_subject_button"),
                    shape = MaterialTheme.shapes.large
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.add_subject))
                }
            }
        } else {
            SubjectList(
                viewModel = viewModel,
                ui = ui,
                onEdit = { editingSubject = it }
            )
        }
    }

    // ---- Dialogs -------------------------------------------------------------------------------

    if (ui.showCelebrationDialog) {
        AppAlertDialog(
            onDismissRequest = { viewModel.dismissCelebration() },
            icon = {
                Icon(
                    Icons.Default.Celebration,
                    contentDescription = null,
                    tint = Ui.extra.success,
                    modifier = Modifier.size(40.dp)
                )
            },
            title = { Text(stringResource(R.string.goal_reached), fontWeight = FontWeight.Bold) },
            text = { Text(stringResource(R.string.celebration_message, ui.streakBeforeToday + 1)) },
            confirmButton = {
                Button(
                    onClick = { viewModel.dismissCelebration() },
                    colors = ButtonDefaults.buttonColors(containerColor = Ui.extra.success)
                ) { Text(stringResource(R.string.celebration_button)) }
            }
        )
    }

    if (showCannotDeleteRunningAlert) {
        AppAlertDialog(
            onDismissRequest = { showCannotDeleteRunningAlert = false },
            title = { Text(stringResource(R.string.cannot_delete_running_title)) },
            text = { Text(stringResource(R.string.cannot_delete_running_desc)) },
            confirmButton = {
                Button(onClick = { showCannotDeleteRunningAlert = false }) { Text(stringResource(R.string.ok)) }
            }
        )
    }

    if (showCountdownDurationPicker) {
        CountdownDurationPickerDialog(
            initialSeconds = ui.settings.countdownSeconds,
            onDismiss = { showCountdownDurationPicker = false },
            onConfirm = { totalSec, saveAsPreset ->
                viewModel.setCountdownDuration(totalSec)
                if (saveAsPreset) {
                    viewModel.addCustomPreset((totalSec / 60L).toInt().coerceAtLeast(1))
                }
                showCountdownDurationPicker = false
            }
        )
    }

    if (showPomodoroSettingsDialog) {
        PomodoroSettingsDialog(
            initialFocusMinutes = ui.settings.pomoFocusMinutes,
            initialShortBreakMinutes = ui.settings.pomoShortBreakMinutes,
            initialLongBreakMinutes = ui.settings.pomoLongBreakMinutes,
            initialInterval = ui.settings.pomoInterval,
            onDismiss = { showPomodoroSettingsDialog = false },
            onSave = { focus, shortBreak, longBreak, interval ->
                viewModel.updatePomodoroSettings(focus, shortBreak, longBreak, interval)
                showPomodoroSettingsDialog = false
            }
        )
    }

    if (showAddSubjectDialog) {
        AddEditSubjectDialog(
            onDismiss = { showAddSubjectDialog = false },
            onSave = { name, color ->
                viewModel.addSubject(name, color)
                showAddSubjectDialog = false
            }
        )
    }

    editingSubject?.let { subj ->
        AddEditSubjectDialog(
            initialSubject = subj,
            onDismiss = { editingSubject = null },
            onSave = { name, color ->
                viewModel.updateSubject(subj.copy(name = name.trim(), color = color))
                editingSubject = null
            },
            onDelete = {
                editingSubject = null
                val inUse = !stopped && run.subjectId == subj.id
                if (inUse) showCannotDeleteRunningAlert = true else deletingSubject = subj
            }
        )
    }

    deletingSubject?.let { subj ->
        DeleteSubjectConfirmDialog(
            subject = subj,
            onDismiss = { deletingSubject = null },
            onDeleteKeepHistory = {
                viewModel.archiveSubject(subj.id)
                deletingSubject = null
            },
            onDeleteAllHistory = {
                viewModel.deleteSubjectAndHistory(subj.id)
                deletingSubject = null
            }
        )
    }
}

// =================================================================================================
// Pieces
// =================================================================================================

@Composable
private fun TopBar(
    ui: TimerUiState,
    onNavigateToDDay: () -> Unit,
    onNavigateToFocus: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // The logo is not shown here any more; the app name stands on its own, in Ethnocentric when the font file is present.
        val brandFont = rememberBrandFont()
        Text(
            text = stringResource(R.string.app_name),
            style = if (brandFont != null) {
                // Ethnocentric is wide and has no bold, so it is a little smaller and not bold.
                MaterialTheme.typography.titleMedium.copy(
                    fontFamily = brandFont,
                    fontWeight = FontWeight.Normal,
                    fontSize = 15.sp,
                    letterSpacing = 0.4.sp
                )
            } else {
                MaterialTheme.typography.titleMedium
            },
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )

        val dday = ui.pinnedDDay
        if (dday != null) {
            val ddayColor = Color(dday.color)
            Surface(
                color = ddayColor.copy(alpha = 0.14f),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .clip(MaterialTheme.shapes.medium)
                    .clickable { onNavigateToDDay() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = dday.formattedDDay(),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = ddayColor
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = dday.title,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 96.dp)
                    )
                }
            }
        } else {
            IconButton(onClick = onNavigateToDDay) {
                Icon(
                    Icons.Default.Event,
                    contentDescription = stringResource(R.string.manage_ddays),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        IconButton(
            onClick = onNavigateToFocus,
            modifier = Modifier.testTag("focus_mode_button")
        ) {
            Icon(
                Icons.Default.Fullscreen,
                contentDescription = stringResource(R.string.focus_mode),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/** A thin warning when notifications are blocked. Re-checked every time the app comes back to the front. */
@Composable
private fun NotificationBanner() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var enabled by remember { mutableStateOf(notificationsEnabled(context)) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                enabled = notificationsEnabled(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (!enabled) {
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = Ui.extra.warning.copy(alpha = 0.12f),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
        ) {
            Row(
                modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.NotificationsOff,
                    contentDescription = null,
                    tint = Ui.extra.warning,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.notification_permission_banner_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = {
                        try {
                            context.startActivity(
                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                    putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                            )
                        } catch (_: Exception) {
                        }
                    }
                ) {
                    Text(stringResource(R.string.notification_permission_enable_button), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun notificationsEnabled(context: Context): Boolean = try {
    NotificationManagerCompat.from(context).areNotificationsEnabled()
} catch (_: Exception) {
    true
}

@Composable
private fun RunningModeChip(ui: TimerUiState, color: Color) {
    val run = ui.run
    val label = when (run.mode) {
        TimerMode.STOPWATCH -> stringResource(R.string.mode_stopwatch)
        TimerMode.COUNTDOWN -> stringResource(
            R.string.timer_countdown_mode_label,
            DateTimeUtils.formatDurationShort(run.targetSeconds)
        )
        TimerMode.POMODORO -> stringResource(
            R.string.timer_pomodoro_mode_label,
            phaseLabel(run.phase),
            run.cycle
        )
    }
    val look = rememberGlassLook()
    Box(modifier = Modifier.glassPanel(MaterialTheme.shapes.medium, look, accent = color, tint = 0.14f)) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ColorDot(color = color, size = 8.dp)
            Spacer(Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun phaseLabel(phase: PomodoroPhase): String = when (phase) {
    PomodoroPhase.FOCUS -> stringResource(R.string.pomo_phase_focus)
    PomodoroPhase.SHORT_BREAK -> stringResource(R.string.pomo_phase_short_break)
    PomodoroPhase.LONG_BREAK -> stringResource(R.string.pomo_phase_long_break)
}

@Composable
private fun CountdownPresets(
    ui: TimerUiState,
    onSelect: (Int) -> Unit,
    onDelete: (Int) -> Unit,
    onCustom: () -> Unit
) {
    val defaults = remember { listOf(5, 10, 15, 25, 45, 60, 90) }
    val look = rememberGlassLook()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ui.settings.customPresets.forEach { minutes ->
            val isSelected = ui.settings.countdownSeconds == minutes * 60L
            val removable = minutes !in defaults
            // Glass chip; the chosen one is tinted with the accent and gets an accent edge.
            Box(
                modifier = Modifier
                    .then(
                        if (isSelected) {
                            Modifier.glassPanel(MaterialTheme.shapes.medium, look, fill = look.fill, accent = MaterialTheme.colorScheme.primary, tint = 0.22f)
                        } else {
                            Modifier.glassPanel(MaterialTheme.shapes.medium, look, fill = look.control)
                        }
                    )
                    .clickable { onSelect(minutes) }
                    .testTag("preset_chip_${minutes}m")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${minutes}m",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (removable) {
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            Icons.Default.Close,
                            contentDescription = stringResource(R.string.cd_delete_preset),
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { onDelete(minutes) }
                        )
                    }
                }
            }
        }
        Box(
            modifier = Modifier
                .glassPanel(MaterialTheme.shapes.medium, look, fill = Color.Transparent)
                .clickable { onCustom() }
                .testTag("custom_countdown_picker_chip")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text(stringResource(R.string.countdown_custom), style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
private fun PomodoroPhaseRow(
    phase: PomodoroPhase,
    cycle: Int,
    interval: Int,
    color: Color,
    onSkip: () -> Unit
) {
    val phaseColor = if (phase == PomodoroPhase.FOCUS) color else Ui.extra.success
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.glassPanel(MaterialTheme.shapes.medium, rememberGlassLook(), accent = phaseColor, tint = 0.14f)) {
            Text(
                text = phaseLabel(phase) + " • " + stringResource(R.string.pomo_cycle_indicator, cycle, interval),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = phaseColor
            )
        }
        Spacer(Modifier.weight(1f))
        GlassButton(
            onClick = onSkip,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier
                .height(34.dp)
                .testTag("skip_pomo_phase_button")
        ) {
            Icon(Icons.Default.SkipNext, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
            Text(stringResource(R.string.pomo_skip_phase), style = MaterialTheme.typography.labelMedium)
        }
    }
}

/** The ring and the clock. The only big composable that reads the ticking timer state. */
@Composable
private fun TimerHero(
    viewModel: TimerViewModel,
    ui: TimerUiState,
    selectedMode: TimerMode,
    activeColor: Color,
    subjectName: String?,
    onClockClick: () -> Unit
) {
    val timer by viewModel.timerState.collectAsStateWithLifecycle()
    val run = ui.run
    val stopped = run.status == TimerStatus.STOPPED

    val displaySeconds = when {
        !stopped -> when (run.mode) {
            TimerMode.STOPWATCH -> timer.currentElapsedSeconds
            TimerMode.COUNTDOWN, TimerMode.POMODORO -> timer.remainingSeconds
        }
        selectedMode == TimerMode.COUNTDOWN -> ui.settings.countdownSeconds
        selectedMode == TimerMode.POMODORO -> ui.settings.pomoFocusMinutes * 60L
        else -> 0L
    }

    val liveTotal = ui.completedTodaySeconds + viewModel.liveStudySeconds(timer)
    val goal = ui.todayGoalSeconds
    val reached = goal > 0 && liveTotal >= goal
    val progress = if (goal > 0) liveTotal.toFloat() / goal.toFloat() else 0f

    LaunchedEffect(reached) {
        if (reached) viewModel.onGoalReached()
    }

    val clockClickable = stopped && selectedMode != TimerMode.STOPWATCH
    val title = if (!stopped) {
        ui.subjects.find { it.id == run.subjectId }?.name ?: run.subjectName
    } else {
        subjectName ?: stringResource(R.string.no_subject_selected)
    }

    CircularProgressTimer(
        progress = progress,
        primaryColor = activeColor,
        glass = rememberGlassLook(),
        modifier = Modifier
            .size(276.dp)
            .clip(CircleShape)
            .clickable(enabled = clockClickable, onClick = onClockClick)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 28.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ColorDot(color = activeColor, size = 8.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = clockText(displaySeconds),
                style = timerDigitsStyle().copy(fontSize = if (displaySeconds >= 3600L) 46.sp else 60.sp),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.testTag("timer_clock_display")
            )
            Spacer(Modifier.height(6.dp))
            when {
                clockClickable -> Text(
                    text = if (selectedMode == TimerMode.COUNTDOWN) {
                        stringResource(R.string.countdown_tap_to_customize)
                    } else {
                        stringResource(R.string.pomo_tap_to_customize)
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                reached -> Text(
                    text = stringResource(R.string.goal_reached),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = Ui.extra.success,
                    modifier = Modifier.testTag("timer_remaining_goal_text")
                )
                else -> Text(
                    text = stringResource(
                        R.string.goal_remaining,
                        DateTimeUtils.formatDurationShort((goal - liveTotal).coerceAtLeast(0L))
                    ),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.testTag("timer_remaining_goal_text")
                )
            }
        }
    }
}

/** "MM:SS" under an hour (bigger, calmer), "H:MM:SS" beyond. ASCII digits always. */
private fun clockText(totalSeconds: Long): String {
    val s = totalSeconds.coerceAtLeast(0L)
    return if (s < 3600L) {
        String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    } else {
        DateTimeUtils.formatTimerClock(s)
    }
}

@Composable
private fun Controls(
    status: TimerStatus,
    canStart: Boolean,
    color: Color,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit
) {
    val buttonShape = MaterialTheme.shapes.extraLarge
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (status) {
            TimerStatus.STOPPED -> {
                GlassButton(
                    onClick = onStart,
                    enabled = canStart,
                    modifier = Modifier
                        .height(56.dp)
                        .width(180.dp)
                        .testTag("start_timer_button"),
                    shape = buttonShape,
                    accent = color
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.start), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            TimerStatus.RUNNING -> {
                GlassButton(
                    onClick = onPause,
                    modifier = Modifier
                        .height(54.dp)
                        .width(136.dp)
                        .testTag("pause_timer_button"),
                    shape = buttonShape,
                    accent = color
                ) {
                    Icon(Icons.Default.Pause, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.pause), fontWeight = FontWeight.SemiBold)
                }
                StopButton(onStop = onStop, shape = buttonShape)
            }
            TimerStatus.PAUSED -> {
                GlassButton(
                    onClick = onResume,
                    modifier = Modifier
                        .height(54.dp)
                        .width(136.dp)
                        .testTag("resume_timer_button"),
                    shape = buttonShape,
                    accent = color
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.resume), fontWeight = FontWeight.SemiBold)
                }
                StopButton(onStop = onStop, shape = buttonShape)
            }
        }
    }
}

@Composable
private fun StopButton(onStop: () -> Unit, shape: androidx.compose.ui.graphics.Shape) {
    GlassButton(
        onClick = onStop,
        modifier = Modifier
            .height(54.dp)
            .width(136.dp)
            .testTag("stop_timer_button"),
        shape = shape,
        accent = MaterialTheme.colorScheme.error,
        contentColor = MaterialTheme.colorScheme.error
    ) {
        Icon(Icons.Default.Stop, contentDescription = null)
        Spacer(Modifier.width(6.dp))
        Text(stringResource(R.string.stop), fontWeight = FontWeight.SemiBold)
    }
}

/** Today / goal / streak. Reads the live timer so the total keeps moving while studying. */
@Composable
private fun TodaySummary(viewModel: TimerViewModel, ui: TimerUiState) {
    val timer by viewModel.timerState.collectAsStateWithLifecycle()
    val total = ui.completedTodaySeconds + viewModel.liveStudySeconds(timer)
    val goalMet = ui.todayGoalSeconds > 0 && total >= ui.todayGoalSeconds
    val streak = ui.streakBeforeToday + if (goalMet) 1 else 0

    AppCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = 16.dp, horizontal = 8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SummaryStat(
                label = stringResource(R.string.today_study_time),
                value = DateTimeUtils.formatDurationShort(total)
            )
            SummaryStat(
                label = stringResource(R.string.daily_goal),
                value = DateTimeUtils.formatDurationShort(ui.todayGoalSeconds)
            )
            SummaryStat(
                label = stringResource(R.string.timer_streak_label),
                value = stringResource(R.string.timer_streak_days, streak),
                icon = true,
                valueColor = if (streak > 0) Color(0xFFF97316) else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun SummaryStat(
    label: String,
    value: String,
    icon: Boolean = false,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon) {
                Icon(
                    Icons.Default.LocalFireDepartment,
                    contentDescription = null,
                    tint = Color(0xFFF97316),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(3.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = value,
            style = NumberStyle.copy(fontSize = 17.sp),
            color = valueColor,
            maxLines = 1
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SubjectList(
    viewModel: TimerViewModel,
    ui: TimerUiState,
    onEdit: (Subject) -> Unit
) {
    AppCard(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 4.dp)
    ) {
        ui.subjectStats.forEachIndexed { index, stat ->
            val subj = stat.subject
            val isSelected = ui.selectedSubjectId == subj.id
            val subjectColor = Color(subj.color)
            if (index > 0) RowDivider(Modifier.padding(horizontal = 16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .combinedClickable(
                        onClick = { viewModel.selectSubject(subj.id) },
                        onLongClick = { onEdit(subj) }
                    )
                    .padding(start = 16.dp, end = 6.dp, top = 4.dp, bottom = 4.dp)
                    .testTag("subject_chip_${subj.id}"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ColorDot(color = subjectColor, size = 12.dp)
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f).padding(vertical = 8.dp)) {
                    Text(
                        text = subj.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    SubjectTime(viewModel = viewModel, ui = ui, subjectId = subj.id, baseSeconds = stat.todaySeconds)
                }
                if (isSelected) {
                    Icon(
                        Icons.Default.Check,
                        contentDescription = null,
                        tint = subjectColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                IconButton(onClick = { onEdit(subj) }, modifier = Modifier.size(40.dp)) {
                    Icon(
                        Icons.Outlined.Edit,
                        contentDescription = stringResource(R.string.edit_subject),
                        modifier = Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/** Only the row of the subject that is currently running reads the live clock. */
@Composable
private fun SubjectTime(viewModel: TimerViewModel, ui: TimerUiState, subjectId: Long, baseSeconds: Long) {
    val isRunningSubject = ui.run.status != TimerStatus.STOPPED && ui.run.subjectId == subjectId
    if (isRunningSubject) {
        val timer by viewModel.timerState.collectAsStateWithLifecycle()
        SubjectTimeText(baseSeconds + viewModel.liveStudySeconds(timer))
    } else {
        SubjectTimeText(baseSeconds)
    }
}

@Composable
private fun SubjectTimeText(seconds: Long) {
    Text(
        text = DateTimeUtils.formatDurationShort(seconds),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
