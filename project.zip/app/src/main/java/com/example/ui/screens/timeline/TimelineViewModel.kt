package com.example.ui.screens.timeline

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.StudyApplication
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.util.DateTimeUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

data class SessionWithSubject(
    val session: StudySession,
    val subject: Subject?,
    val effectiveStartMs: Long,
    val effectiveEndMs: Long,
    val effectiveDurationSeconds: Long
)

/** Where a block sits horizontally. Blocks that would overlap visually share the width as columns. */
data class TimelineBlockLayout(
    val sessionWithSubject: SessionWithSubject,
    val colIndex: Int,
    val totalCols: Int
)

data class TimelineSubjectTotal(
    val subject: Subject,
    val totalSeconds: Long,
    val sessionCount: Int,
    val percentage: Float
)

data class TimelineUiState(
    val currentDayStartMs: Long = 0L,
    val currentDayEndMs: Long = 0L,
    val dayStartHour: Int = 5,
    val isToday: Boolean = true,
    val selectedSubjectFilter: Long? = null,
    /** Sessions shown (after the optional subject filter), sorted by start. */
    val sessions: List<SessionWithSubject> = emptyList(),
    val rawSessions: List<StudySession> = emptyList(),
    val subjects: List<Subject> = emptyList(),
    val totalStudyMillis: Long = 0L,
    val subjectTotals: List<TimelineSubjectTotal> = emptyList(),
    val is12Hour: Boolean = false,
    /** 0, 1 or 2. Bigger means more height per hour, so short sessions get more room. */
    val zoom: Int = 1
)

class TimelineViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as StudyApplication
    private val studyRepo = app.studyRepository
    private val settingsRepo = app.settingsRepository

    private val _selectedTimestampMs = MutableStateFlow(System.currentTimeMillis())
    val selectedTimestampMs: StateFlow<Long> = _selectedTimestampMs

    private val _selectedSubjectFilter = MutableStateFlow<Long?>(null)
    val selectedSubjectFilter: StateFlow<Long?> = _selectedSubjectFilter

    private data class DayData(
        val dayStartMs: Long,
        val dayEndMs: Long,
        val dayStartHour: Int,
        val isToday: Boolean,
        val filter: Long?,
        val sessions: List<SessionWithSubject>,
        val raw: List<StudySession>,
        val subjects: List<Subject>,
        val totalMs: Long,
        val totals: List<TimelineSubjectTotal>
    )

    @OptIn(ExperimentalCoroutinesApi::class)
    private val dayData = combine(
        _selectedTimestampMs,
        settingsRepo.dayStartHourFlow,
        _selectedSubjectFilter
    ) { timestamp, dayStartHour, filter -> Triple(timestamp, dayStartHour, filter) }
        .flatMapLatest { (timestamp, dayStartHour, filter) ->
            val (dayStartMs, dayEndMs) = DateTimeUtils.getStudyDayRange(timestamp, dayStartHour)
            val (todayStartMs, _) = DateTimeUtils.getStudyDayRange(System.currentTimeMillis(), dayStartHour)
            val isToday = dayStartMs == todayStartMs

            combine(
                studyRepo.getSessionsInRange(dayStartMs, dayEndMs),
                studyRepo.allSubjects
            ) { inRange, subjects ->
                buildDayData(dayStartMs, dayEndMs, dayStartHour, isToday, filter, inRange, subjects)
            }
        }
        .flowOn(Dispatchers.Default)

    private val displaySettings = settingsRepo.settings
        .map { it.is12Hour to it.timelineZoom.coerceIn(0, 2) }
        .distinctUntilChanged()

    val uiState: StateFlow<TimelineUiState> = combine(dayData, displaySettings) { d, display ->
        TimelineUiState(
            currentDayStartMs = d.dayStartMs,
            currentDayEndMs = d.dayEndMs,
            dayStartHour = d.dayStartHour,
            isToday = d.isToday,
            selectedSubjectFilter = d.filter,
            sessions = d.sessions,
            rawSessions = d.raw,
            subjects = d.subjects,
            totalStudyMillis = d.totalMs,
            subjectTotals = d.totals,
            is12Hour = display.first,
            zoom = display.second
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TimelineUiState()
    )

    private fun buildDayData(
        dayStartMs: Long,
        dayEndMs: Long,
        dayStartHour: Int,
        isToday: Boolean,
        filter: Long?,
        inRange: List<StudySession>,
        subjects: List<Subject>
    ): DayData {
        val subjectMap = subjects.associateBy { it.id }

        // Totals always cover ALL sessions of the day. The filter only changes what is drawn.
        var totalMs = 0L
        val durationBySubject = HashMap<Long, Long>()
        val countBySubject = HashMap<Long, Int>()
        for (s in inRange) {
            val effMs = DateTimeUtils.getSessionOverlapMillis(s, dayStartMs, dayEndMs)
            totalMs += effMs
            s.subjectId?.let { id ->
                durationBySubject[id] = (durationBySubject[id] ?: 0L) + effMs / 1000L
                countBySubject[id] = (countBySubject[id] ?: 0) + 1
            }
        }
        val totalSec = totalMs / 1000L

        val totals = subjects.mapNotNull { subj ->
            val sec = durationBySubject[subj.id] ?: 0L
            if (sec > 0L) {
                TimelineSubjectTotal(
                    subject = subj,
                    totalSeconds = sec,
                    sessionCount = countBySubject[subj.id] ?: 0,
                    percentage = if (totalSec > 0) sec.toFloat() / totalSec.toFloat() else 0f
                )
            } else null
        }.sortedByDescending { it.totalSeconds }

        val visible = if (filter != null) inRange.filter { it.subjectId == filter } else inRange
        val mapped = visible.map { session ->
            val effStart = maxOf(session.startTime, dayStartMs)
            val effEnd = minOf(session.endTime, dayEndMs).coerceAtLeast(effStart)
            SessionWithSubject(
                session = session,
                subject = session.subjectId?.let { subjectMap[it] },
                effectiveStartMs = effStart,
                effectiveEndMs = effEnd,
                effectiveDurationSeconds = (effEnd - effStart) / 1000L
            )
        }.sortedBy { it.effectiveStartMs }

        val shownMs = if (filter != null) {
            mapped.sumOf { it.effectiveEndMs - it.effectiveStartMs }
        } else totalMs

        return DayData(
            dayStartMs = dayStartMs,
            dayEndMs = dayEndMs,
            dayStartHour = dayStartHour,
            isToday = isToday,
            filter = filter,
            sessions = mapped,
            raw = inRange,
            subjects = subjects.filter { !it.isArchived },
            totalMs = shownMs,
            totals = totals
        )
    }

    fun selectSubjectFilter(subjectId: Long?) {
        _selectedSubjectFilter.value = subjectId
    }

    fun resetFilter() {
        _selectedSubjectFilter.value = null
    }

    fun selectDate(timestamp: Long) {
        _selectedTimestampMs.value = timestamp
    }

    private fun shiftDays(days: Long) {
        val shifted = Instant.ofEpochMilli(_selectedTimestampMs.value)
            .atZone(ZoneId.systemDefault())
            .plusDays(days)
            .toInstant()
            .toEpochMilli()
        _selectedTimestampMs.value = shifted
    }

    fun nextDay() = shiftDays(1)
    fun prevDay() = shiftDays(-1)

    fun goToToday() {
        _selectedTimestampMs.value = System.currentTimeMillis()
    }

    fun setZoom(zoom: Int) {
        viewModelScope.launch { settingsRepo.setTimelineZoom(zoom.coerceIn(0, 2)) }
    }

    fun addManualSession(subjectId: Long, startMs: Long, endMs: Long) {
        viewModelScope.launch {
            studyRepo.insertSession(
                StudySession(
                    subjectId = subjectId,
                    startTime = startMs,
                    endTime = endMs,
                    mode = "MANUAL",
                    interruptions = 0
                )
            )
        }
    }

    fun updateSession(session: StudySession) {
        viewModelScope.launch { studyRepo.updateSession(session) }
    }

    fun deleteSession(session: StudySession) {
        viewModelScope.launch { studyRepo.deleteSession(session) }
    }

    companion object {
        /**
         * Splits overlapping blocks into side-by-side columns.
         *
         * THE FIX for short sessions: overlap is decided on what is DRAWN, not on the real time span.
         * A 3 minute session is drawn at least as tall as [minDurationMs] worth of timeline, so two short
         * sessions 10 minutes apart used to be drawn on top of each other in the same column and one of
         * them disappeared. Here every block occupies max(real duration, [minDurationMs]), so blocks that
         * would collide get their own column instead.
         */
        fun computeTimelineLayouts(
            sessions: List<SessionWithSubject>,
            minDurationMs: Long = 0L
        ): List<TimelineBlockLayout> {
            if (sessions.isEmpty()) return emptyList()

            fun visualEnd(s: SessionWithSubject): Long =
                maxOf(s.effectiveEndMs, s.effectiveStartMs + minDurationMs)

            val sorted = sessions.sortedWith(
                compareBy<SessionWithSubject> { it.effectiveStartMs }
                    .thenByDescending { visualEnd(it) }
                    .thenBy { it.session.id }
            )

            // Group into clusters of blocks that overlap (visually), directly or through a chain.
            val clusters = mutableListOf<MutableList<SessionWithSubject>>()
            var current = mutableListOf<SessionWithSubject>()
            var clusterEnd = Long.MIN_VALUE
            for (s in sorted) {
                if (current.isEmpty() || s.effectiveStartMs < clusterEnd) {
                    current.add(s)
                    clusterEnd = maxOf(clusterEnd, visualEnd(s))
                } else {
                    clusters.add(current)
                    current = mutableListOf(s)
                    clusterEnd = visualEnd(s)
                }
            }
            if (current.isNotEmpty()) clusters.add(current)

            // Inside a cluster, put each block in the first column that is free.
            val results = mutableListOf<TimelineBlockLayout>()
            for (cluster in clusters) {
                val columnEnds = mutableListOf<Long>()
                val placed = mutableListOf<Pair<SessionWithSubject, Int>>()
                for (s in cluster) {
                    var col = columnEnds.indexOfFirst { it <= s.effectiveStartMs }
                    if (col == -1) {
                        col = columnEnds.size
                        columnEnds.add(visualEnd(s))
                    } else {
                        columnEnds[col] = visualEnd(s)
                    }
                    placed.add(s to col)
                }
                val totalCols = maxOf(columnEnds.size, 1)
                for ((s, col) in placed) results.add(TimelineBlockLayout(s, col, totalCols))
            }
            return results
        }
    }
}
