package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ThemeAccentColors
import com.example.ui.theme.Ui

/** The accent color swatches, five per row. Used by Settings and by the first-run set-up. */
@Composable
fun AccentPicker(
    selected: Long,
    onSelect: (Long) -> Unit,
    modifier: Modifier = Modifier,
    /** When set, the first swatch is the theme's own colour and selecting it sends 0. */
    presetAccent: Long? = null
) {
    val swatches: List<Long> = if (presetAccent != null) listOf(0L) + ThemeAccentColors else ThemeAccentColors
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        swatches.chunked(5).forEachIndexed { rowIndex, rowColors ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                rowColors.forEachIndexed { colIndex, colorValue ->
                    val color = Color(if (colorValue == 0L) (presetAccent ?: colorValue) else colorValue)
                    val isSelected = colorValue == selected
                    val description = if (colorValue == 0L) {
                        stringResource(R.string.cd_accent_preset)
                    } else {
                        stringResource(R.string.cd_accent_color, (rowIndex * 5 + colIndex + 1).toString())
                    }
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(color)
                            .then(
                                if (isSelected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                else Modifier.border(1.dp, Ui.extra.hairline, CircleShape)
                            )
                            .semantics { contentDescription = description }
                            .clickable { onSelect(colorValue) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                tint = if (color.luminance() > 0.45f) Color(0xFF0B0C10) else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
