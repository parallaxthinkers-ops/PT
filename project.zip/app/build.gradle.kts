plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
}

// Release signing comes ONLY from environment variables (the GitHub workflow sets them).
// If anything is missing the release APK stays unsigned. It is never silently signed with a debug key.
val envStoreFile: String? = System.getenv("STORE_FILE")
val envStorePassword: String? = System.getenv("STORE_PASSWORD")
val envKeyAlias: String? = System.getenv("KEY_ALIAS")
val envKeyPassword: String? = System.getenv("KEY_PASSWORD")
val releaseSigningReady: Boolean =
  !envStoreFile.isNullOrEmpty() &&
    !envStorePassword.isNullOrEmpty() &&
    !envKeyAlias.isNullOrEmpty() &&
    !envKeyPassword.isNullOrEmpty() &&
    file(envStoreFile).exists()

// R8 (code shrinking) is OFF by default. It broke the Parallax Compose build once and passes every debug test.
// Turn it on as a deliberate, separate step:  ./gradlew assembleRelease -PenableR8=true
val enableR8: Boolean = (project.findProperty("enableR8") as String?) == "true"

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    // Kept as-is on purpose: changing it makes Android treat the app as a different app and
    // would not keep existing data. Change it only BEFORE a Play Store release (see README).
    applicationId = "com.aistudio.studylocal.krvqpt"
    minSdk = 26
    targetSdk = 36
    versionCode = 10
    versionName = "2.3.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  signingConfigs {
    if (releaseSigningReady) {
      create("release") {
        storeFile = file(envStoreFile!!)
        storePassword = envStorePassword
        keyAlias = envKeyAlias
        keyPassword = envKeyPassword
      }
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = enableR8
      isShrinkResources = enableR8
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      if (releaseSigningReady) {
        signingConfig = signingConfigs.getByName("release")
      }
    }
    // debug uses Android's automatic debug key. Nothing to configure.
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  lint {
    abortOnError = false
    checkReleaseBuilds = false
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.glance.appwidget)
  implementation(libs.androidx.glance.material3)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)

  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)

  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)

  "ksp"(libs.androidx.room.compiler)
}
