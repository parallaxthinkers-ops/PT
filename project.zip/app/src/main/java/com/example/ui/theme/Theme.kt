package com.example.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.repository.CornerStyleNames
import com.example.data.repository.LayoutNames
import com.example.data.repository.RingNames
import com.example.data.repository.ThemeFontNames
import com.example.data.repository.ThemeStyleNames

/** Two looks. MINIMAL is flat with hairline borders. SOFT has tinted, borderless surfaces and rounder shapes. */
enum class ThemeStyle {
    MINIMAL,
    SOFT;

    companion object {
        fun fromName(raw: String?): ThemeStyle =
            if (ThemeStyleNames.normalize(raw) == ThemeStyleNames.SOFT) SOFT else MINIMAL
    }
}

val LocalThemeStyle = staticCompositionLocalOf { ThemeStyle.MINIMAL }

/** The main layout of the cards. CLASSIC is the original look, the other two are the "faked" (blur-free) versions. */
enum class ThemeLayout {
    CLASSIC,
    NEUMORPHISM,
    GLASSMORPHISM;

    companion object {
        fun fromName(raw: String?): ThemeLayout = when (LayoutNames.normalize(raw)) {
            LayoutNames.NEUMORPHISM -> NEUMORPHISM
            LayoutNames.GLASSMORPHISM -> GLASSMORPHISM
            else -> CLASSIC
        }
    }
}

val LocalThemeLayout = staticCompositionLocalOf { ThemeLayout.CLASSIC }

/**
 * The colours a non-classic layout draws with, worked out ONCE per theme (not per frame).
 * [card] is the card fill. Neumorphism uses the four edge colours; glass uses [glassBorder] and [sheen].
 */
@Immutable
class LayoutColors(
    val card: Color,
    val light: Color,
    val dark: Color,
    val lightFar: Color,
    val darkFar: Color,
    val glassBorder: Brush,
    val sheen: Color
)

/** Colours the Material scheme has no slot for. */
@Immutable
data class ExtraColors(
    val hairline: Color,
    val subtle: Color,
    val success: Color,
    val warning: Color,
    val danger: Color,
    val onAccent: Color
)

val LocalExtraColors = staticCompositionLocalOf {
    ExtraColors(
        hairline = Color(0xFFE5E5E0),
        subtle = Color(0xFFF1F1EE),
        success = SuccessGreen,
        warning = WarningAmber,
        danger = DangerRed,
        onAccent = Color.White
    )
}

/** Shortcut: `Ui.extra.hairline`. */
object Ui {
    val extra: ExtraColors
        @Composable @ReadOnlyComposable get() = LocalExtraColors.current
}

/** Text on a coloured surface: near-black or white, whichever has more contrast (at least 4.4 for any colour). */
private fun onColorFor(color: Color): Color =
    Color(ThemeMath.onColorFor(color.toArgb().toLong() and 0xFFFFFFFFL))

/**
 * Things a screen reads that are not colours. [backdrop] is the optional static gradient behind the app;
 * it is one brush drawn once, not an animation, so it costs next to nothing per frame.
 */
@Immutable
data class ThemeLook(
    val ringStroke: Dp,
    val fontFamily: FontFamily,
    val backdrop: Brush?,
    /** Null for the Classic layout. */
    val layoutColors: LayoutColors? = null
)

val LocalThemeLook = staticCompositionLocalOf {
    ThemeLook(ringStroke = 10.dp, fontFamily = FontFamily.Default, backdrop = null)
}

private fun Color.argbLong(): Long = this.toArgb().toLong() and 0xFFFFFFFFL

/**
 * The colours of a layout for the given scheme, or null for Classic. [accent2] is the aesthetic's second colour
 * (null = use the main accent). Used by the theme itself and by the layout previews on the Themes screen.
 */
fun buildLayoutColors(layout: ThemeLayout, scheme: ColorScheme, accent2: Long?, dark: Boolean): LayoutColors? {
    if (layout == ThemeLayout.CLASSIC) return null
    val bg = scheme.background.argbLong()
    return if (layout == ThemeLayout.NEUMORPHISM) {
        val light = LayoutMath.neoLight(bg, dark)
        val shade = LayoutMath.neoDark(bg, dark)
        LayoutColors(
            card = scheme.background,
            light = Color(light),
            dark = Color(shade),
            lightFar = Color(LayoutMath.far(bg, light)),
            darkFar = Color(LayoutMath.far(bg, shade)),
            glassBorder = Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)),
            sheen = Color.Transparent
        )
    } else {
        // Glass: the surface colour at GLASS_ALPHA, a bright edge on the top-left that fades to a faint one.
        val edgeStart = if (dark) Color.White.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.95f)
        val edgeEnd = if (dark) Color.White.copy(alpha = 0.06f) else scheme.onSurface.copy(alpha = 0.10f)
        LayoutColors(
            card = scheme.surface.copy(alpha = LayoutMath.GLASS_ALPHA),
            light = Color.Transparent,
            dark = Color.Transparent,
            lightFar = Color.Transparent,
            darkFar = Color.Transparent,
            glassBorder = Brush.linearGradient(listOf(edgeStart, edgeEnd)),
            sheen = if (dark) Color.White.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.22f)
        )
    }
}

/** The static diagonal gradient behind glass cards: accent tint, plain background, second tint. */
fun buildGlassBackdrop(scheme: ColorScheme, accent2: Long?, dark: Boolean): Brush {
    val stops = LayoutMath.glassStops(
        bg = scheme.background.argbLong(),
        accent = scheme.primary.argbLong(),
        accent2 = accent2 ?: scheme.primary.argbLong(),
        dark = dark
    )
    return Brush.linearGradient(stops.map { Color(it) })
}

/** The screen background: the gradient when the person turned it on, otherwise the plain background colour. */
@Composable
fun Modifier.appBackground(): Modifier {
    val brush = LocalThemeLook.current.backdrop
    return if (brush != null) this.background(brush) else this.background(MaterialTheme.colorScheme.background)
}

private fun fontFamilyFor(font: String): FontFamily = when (ThemeFontNames.normalize(font)) {
    ThemeFontNames.SERIF -> FontFamily.Serif
    ThemeFontNames.MONO -> FontFamily.Monospace
    else -> FontFamily.Default
}

private fun ringStrokeFor(ring: String): Dp = when (RingNames.normalize(ring)) {
    RingNames.THIN -> 6.dp
    RingNames.BOLD -> 16.dp
    else -> 10.dp
}

/** The colour scheme of an aesthetic. Every colour comes from the checked palette, nothing is guessed. */
private fun buildPresetScheme(
    palette: ThemePalette,
    dark: Boolean,
    amoled: Boolean,
    accentOverride: Long
): ColorScheme {
    var bg = Color(palette.bg)
    var surface = Color(palette.surface)
    var variant = Color(palette.variant)
    if (dark && amoled) {
        bg = Color.Black
        surface = lerp(surface, Color.Black, 0.5f)
        variant = lerp(variant, Color.Black, 0.35f)
    }
    val accent = Color(if (accentOverride != 0L) accentOverride else palette.accent)
    val accent2 = Color(palette.accent2)
    val onSurface = Color(palette.onSurface)
    val onVariant = Color(palette.onVariant)
    val container = lerp(surface, accent, if (dark) 0.30f else 0.16f)
    val outline = lerp(variant, onVariant, 0.45f)
    val hairline = Color(palette.hairline)

    return if (dark) {
        darkColorScheme(
            primary = accent,
            onPrimary = onColorFor(accent),
            primaryContainer = container,
            onPrimaryContainer = onSurface,
            secondary = accent2,
            onSecondary = onColorFor(accent2),
            secondaryContainer = variant,
            onSecondaryContainer = onSurface,
            tertiary = accent2,
            onTertiary = onColorFor(accent2),
            background = bg,
            onBackground = onSurface,
            surface = surface,
            onSurface = onSurface,
            surfaceVariant = variant,
            onSurfaceVariant = onVariant,
            surfaceContainerLowest = bg,
            surfaceContainerLow = surface,
            surfaceContainer = surface,
            surfaceContainerHigh = variant,
            surfaceContainerHighest = lerp(variant, onSurface, 0.06f),
            outline = outline,
            outlineVariant = hairline,
            error = Color(0xFFF87171),
            onError = Color(0xFF1A0505)
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = onColorFor(accent),
            primaryContainer = container,
            onPrimaryContainer = onSurface,
            secondary = accent2,
            onSecondary = onColorFor(accent2),
            secondaryContainer = variant,
            onSecondaryContainer = onSurface,
            tertiary = accent2,
            onTertiary = onColorFor(accent2),
            background = bg,
            onBackground = onSurface,
            surface = surface,
            onSurface = onSurface,
            surfaceVariant = variant,
            onSurfaceVariant = onVariant,
            surfaceContainerLowest = surface,
            surfaceContainerLow = surface,
            surfaceContainer = variant,
            surfaceContainerHigh = lerp(variant, onSurface, 0.04f),
            surfaceContainerHighest = lerp(variant, onSurface, 0.08f),
            outline = outline,
            outlineVariant = hairline,
            error = DangerRed,
            onError = Color.White
        )
    }
}

private fun buildColorScheme(
    dark: Boolean,
    amoled: Boolean,
    style: ThemeStyle,
    accent: Color
): ColorScheme {
    val soft = style == ThemeStyle.SOFT
    val onAccent = onColorFor(accent)

    return if (dark) {
        val bg = if (amoled) Color(0xFF000000) else Color(0xFF0E0F13)
        val surfaceBase = if (amoled) Color(0xFF0B0B0D) else Color(0xFF16181D)
        val surface = if (soft) lerp(surfaceBase, accent, 0.06f) else surfaceBase
        val variant = if (soft) lerp(surfaceBase, accent, 0.12f) else Color(0xFF1F2229)
        darkColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = lerp(surfaceBase, accent, 0.28f),
            onPrimaryContainer = Color(0xFFF4F5F7),
            secondary = accent,
            onSecondary = onAccent,
            secondaryContainer = variant,
            onSecondaryContainer = Color(0xFFF4F5F7),
            tertiary = AccentEmerald,
            background = bg,
            onBackground = Color(0xFFEDEEF1),
            surface = surface,
            onSurface = Color(0xFFEDEEF1),
            surfaceVariant = variant,
            onSurfaceVariant = Color(0xFF9AA0AB),
            surfaceContainerLowest = bg,
            surfaceContainerLow = surfaceBase,
            surfaceContainer = surface,
            surfaceContainerHigh = variant,
            surfaceContainerHighest = lerp(variant, Color.White, 0.04f),
            outline = Color(0xFF3A3E47),
            outlineVariant = Color(0xFF272A31),
            error = Color(0xFFF87171),
            onError = Color(0xFF1A0505)
        )
    } else {
        val bg = if (soft) lerp(Color(0xFFF6F6F3), accent, 0.05f) else Color(0xFFF7F7F5)
        val surface = if (soft) lerp(Color.White, accent, 0.03f) else Color.White
        val variant = if (soft) lerp(Color(0xFFF1F1EE), accent, 0.09f) else Color(0xFFF0F0ED)
        lightColorScheme(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = lerp(Color.White, accent, 0.16f),
            onPrimaryContainer = Color(0xFF0E0F13),
            secondary = accent,
            onSecondary = onAccent,
            secondaryContainer = variant,
            onSecondaryContainer = Color(0xFF0E0F13),
            tertiary = AccentEmerald,
            background = bg,
            onBackground = Color(0xFF111318),
            surface = surface,
            onSurface = Color(0xFF111318),
            surfaceVariant = variant,
            onSurfaceVariant = Color(0xFF6B7280),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = surface,
            surfaceContainer = variant,
            surfaceContainerHigh = lerp(variant, Color.Black, 0.03f),
            surfaceContainerHighest = lerp(variant, Color.Black, 0.06f),
            outline = Color(0xFFD4D4CE),
            outlineVariant = Color(0xFFE7E7E2),
            error = DangerRed,
            onError = Color.White
        )
    }
}

private fun buildExtras(
    dark: Boolean,
    amoled: Boolean,
    accent: Color,
    scheme: ColorScheme,
    presetHairline: Color? = null
): ExtraColors =
    ExtraColors(
        hairline = presetHairline
            ?: if (dark) (if (amoled) Color(0xFF24262B) else Color(0xFF272A31)) else Color(0xFFE5E5E0),
        subtle = scheme.surfaceVariant,
        success = if (dark) Color(0xFF4ADE80) else SuccessGreen,
        warning = WarningAmber,
        danger = if (dark) Color(0xFFF87171) else DangerRed,
        onAccent = onColorFor(accent)
    )

private fun buildShapes(corner: String, style: ThemeStyle): Shapes {
    // SOFT is a little rounder than MINIMAL for the same corner choice.
    val extra = if (style == ThemeStyle.SOFT) 4 else 0
    return when (CornerStyleNames.normalize(corner)) {
        CornerStyleNames.SHARP -> Shapes(
            extraSmall = RoundedCornerShape(2.dp),
            small = RoundedCornerShape(4.dp),
            medium = RoundedCornerShape((6 + extra).dp),
            large = RoundedCornerShape((8 + extra).dp),
            extraLarge = RoundedCornerShape((12 + extra).dp)
        )
        CornerStyleNames.PILL -> Shapes(
            extraSmall = RoundedCornerShape(10.dp),
            small = RoundedCornerShape(16.dp),
            medium = RoundedCornerShape((22 + extra).dp),
            large = RoundedCornerShape((28 + extra).dp),
            extraLarge = RoundedCornerShape((36 + extra).dp)
        )
        else -> Shapes(
            extraSmall = RoundedCornerShape(6.dp),
            small = RoundedCornerShape(10.dp),
            medium = RoundedCornerShape((14 + extra).dp),
            large = RoundedCornerShape((20 + extra).dp),
            extraLarge = RoundedCornerShape((28 + extra).dp)
        )
    }
}

@Composable
fun ParallaxTrackerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    themeStyle: ThemeStyle = ThemeStyle.MINIMAL,
    accentColor: Color = Color(0xFF3B6EF6),
    amoled: Boolean = false,
    cornerStyle: String = CornerStyleNames.ROUNDED,
    preset: String = ThemePresets.CLASSIC,
    accentCustom: Long = 0L,
    gradient: Boolean = false,
    font: String = ThemeFontNames.SYSTEM,
    ring: String = RingNames.REGULAR,
    layout: ThemeLayout = ThemeLayout.CLASSIC,
    content: @Composable () -> Unit
) {
    val presetData = remember(preset) { ThemePresets.find(preset) }
    val useAmoled = amoled && darkTheme

    // Remembered so a recomposition that changes nothing visible does not rebuild the scheme.
    val colorScheme = remember(darkTheme, useAmoled, themeStyle, accentColor, presetData, accentCustom) {
        if (presetData != null) {
            buildPresetScheme(presetData.palette(darkTheme), darkTheme, useAmoled, accentCustom)
        } else {
            buildColorScheme(darkTheme, useAmoled, themeStyle, accentColor)
        }
    }
    val extras = remember(darkTheme, useAmoled, accentColor, colorScheme, presetData) {
        val hairline = presetData?.palette(darkTheme)?.hairline?.let { c ->
            val base = Color(c)
            if (useAmoled) lerp(base, Color.Black, 0.35f) else base
        }
        buildExtras(darkTheme, useAmoled, colorScheme.primary, colorScheme, hairline)
    }
    val shapes = remember(cornerStyle, themeStyle) { buildShapes(cornerStyle, themeStyle) }
    val typography = remember(font) { typographyFor(fontFamilyFor(font)) }

    val look = remember(gradient, colorScheme, presetData, darkTheme, font, ring, layout) {
        val accent2 = presetData?.palette(darkTheme)?.accent2
        val backdrop: Brush? = when (layout) {
            // The card is the same colour as the screen, so a gradient behind it would break the illusion.
            ThemeLayout.NEUMORPHISM -> null
            // Glass always has its own backdrop; without it there is nothing to see through the cards.
            ThemeLayout.GLASSMORPHISM -> buildGlassBackdrop(colorScheme, accent2, darkTheme)
            ThemeLayout.CLASSIC -> if (gradient) {
                val second = accent2?.let { Color(it) } ?: colorScheme.primary
                val amount = if (darkTheme) 0.22f else 0.16f
                Brush.verticalGradient(listOf(colorScheme.background, lerp(colorScheme.background, second, amount)))
            } else {
                null
            }
        }
        ThemeLook(
            ringStroke = ringStrokeFor(ring),
            fontFamily = fontFamilyFor(font),
            backdrop = backdrop,
            layoutColors = buildLayoutColors(layout, colorScheme, accent2, darkTheme)
        )
    }

    CompositionLocalProvider(
        LocalThemeStyle provides themeStyle,
        LocalThemeLayout provides layout,
        LocalExtraColors provides extras,
        LocalThemeLook provides look
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            shapes = shapes,
            content = content
        )
    }
}
