package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.ui.theme.Ui
import com.example.util.DateTimeUtils
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

private enum class PickerTarget { START, END }

/**
 * Add or edit a session by hand.
 *
 * The times are picked as a clock time that belongs to the study day on screen ([baseDayMs] is the start of
 * that study day). A time earlier than [dayStartHour] therefore lands on the next calendar day, which is what
 * makes a session like 23:00 to 01:00, or one at 02:00 on a day that starts at 05:00, possible.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ManualSessionDialog(
    initialSession: StudySession? = null,
    baseDayMs: Long,
    subjects: List<Subject>,
    existingSessions: List<StudySession> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (subjectId: Long, startMs: Long, endMs: Long) -> Unit,
    onDelete: (() -> Unit)? = null,
    dayStartHour: Int = 0,
    is12Hour: Boolean = false
) {
    val zone = remember { ZoneId.systemDefault() }
    val studyDate: LocalDate = remember(baseDayMs) { Instant.ofEpochMilli(baseDayMs).atZone(zone).toLocalDate() }

    fun atClock(hour: Int, minute: Int): Long {
        val nextDay = hour * 60 + minute < dayStartHour * 60
        val date = if (nextDay) studyDate.plusDays(1) else studyDate
        return date.atTime(LocalTime.of(hour, minute)).atZone(zone).toInstant().toEpochMilli()
    }

    fun hourOf(ms: Long): Int = Instant.ofEpochMilli(ms).atZone(zone).hour
    fun minuteOf(ms: Long): Int = Instant.ofEpochMilli(ms).atZone(zone).minute

    var selectedSubjectId by remember {
        mutableStateOf(initialSession?.subjectId ?: subjects.firstOrNull()?.id)
    }
    // A new record starts at 09:00, or at the start of the study day when that is later (never past 22:00).
    val defaultStartHour = maxOf(9, dayStartHour).coerceAtMost(22)
    var startTimeMs by remember {
        mutableLongStateOf(initialSession?.startTime ?: atClock(defaultStartHour, 0))
    }
    var endTimeMs by remember {
        mutableLongStateOf(initialSession?.endTime ?: atClock(defaultStartHour + 1, 0))
    }
    var showError by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf<PickerTarget?>(null) }

    val overlappingSession = remember(startTimeMs, endTimeMs, existingSessions, initialSession) {
        existingSessions.firstOrNull { other ->
            other.id != initialSession?.id && other.endTime > startTimeMs && other.startTime < endTimeMs
        }
    }
    val canSave = selectedSubjectId != null

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialSession == null) stringResource(R.string.add_session) else stringResource(R.string.edit_session),
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.subjects), style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(6.dp))
                if (subjects.isEmpty() && initialSession == null) {
                    Text(
                        text = stringResource(R.string.settings_no_subjects),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    subjects.forEach { subject ->
                        FilterChip(
                            selected = selectedSubjectId == subject.id,
                            onClick = { selectedSubjectId = subject.id },
                            leadingIcon = { ColorDot(Color(subject.color)) },
                            label = { Text(subject.name) },
                            modifier = Modifier.testTag("dialog_subject_chip_${subject.id}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.start_time), style = MaterialTheme.typography.labelMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedButton(
                            onClick = { picker = PickerTarget.START },
                            modifier = Modifier.fillMaxWidth().testTag("pick_start_time_button")
                        ) {
                            Icon(Icons.Filled.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(DateTimeUtils.formatTime(startTimeMs, is12Hour), maxLines = 1)
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.end_time), style = MaterialTheme.typography.labelMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedButton(
                            onClick = { picker = PickerTarget.END },
                            modifier = Modifier.fillMaxWidth().testTag("pick_end_time_button")
                        ) {
                            Icon(Icons.Filled.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(DateTimeUtils.formatTime(endTimeMs, is12Hour), maxLines = 1)
                        }
                    }
                }

                val durationSec = ((endTimeMs - startTimeMs) / 1000L).coerceAtLeast(0L)
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "${stringResource(R.string.duration)}: ${DateTimeUtils.formatDurationShort(durationSec)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )

                if (initialSession != null && initialSession.interruptions > 0) {
                    Spacer(modifier = Modifier.height(8.dp))
                    NoticeRow(
                        text = stringResource(R.string.session_interruptions, initialSession.interruptions),
                        color = Ui.extra.danger
                    )
                }

                if (overlappingSession != null && endTimeMs > startTimeMs) {
                    Spacer(modifier = Modifier.height(10.dp))
                    NoticeRow(
                        text = stringResource(
                            R.string.timeline_overlap_warning,
                            DateTimeUtils.formatTime(overlappingSession.startTime, is12Hour),
                            DateTimeUtils.formatTime(overlappingSession.endTime, is12Hour)
                        ),
                        color = Ui.extra.warning
                    )
                }

                if (showError && endTimeMs <= startTimeMs) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.timeline_end_before_start),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val subjectId = selectedSubjectId
                    if (subjectId == null) return@TextButton
                    if (endTimeMs <= startTimeMs) {
                        showError = true
                    } else {
                        onSave(subjectId, startTimeMs, endTimeMs)
                    }
                },
                enabled = canSave,
                modifier = Modifier.testTag("save_manual_session_button")
            ) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (onDelete != null) {
                    TextButton(
                        onClick = onDelete,
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.testTag("delete_manual_session_button")
                    ) {
                        Text(stringResource(R.string.delete))
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.cancel))
                }
            }
        }
    )

    when (picker) {
        PickerTarget.START -> AppTimePickerDialog(
            title = stringResource(R.string.start_time),
            initialHour = hourOf(startTimeMs),
            initialMinute = minuteOf(startTimeMs),
            is24Hour = !is12Hour,
            onDismiss = { picker = null },
            onConfirm = { hour, minute ->
                startTimeMs = atClock(hour, minute)
                showError = false
                picker = null
            }
        )
        PickerTarget.END -> AppTimePickerDialog(
            title = stringResource(R.string.end_time),
            initialHour = hourOf(endTimeMs),
            initialMinute = minuteOf(endTimeMs),
            is24Hour = !is12Hour,
            onDismiss = { picker = null },
            onConfirm = { hour, minute ->
                endTimeMs = atClock(hour, minute)
                showError = false
                picker = null
            }
        )
        null -> Unit
    }
}

@Composable
private fun NoticeRow(text: String, color: Color) {
    Surface(
        shape = MaterialTheme.shapes.small,
        color = color.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
