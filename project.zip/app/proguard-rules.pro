# Used ONLY when you build with -PenableR8=true (see app/build.gradle.kts).
# Rules follow the Parallax playbook (section 6.3): keep what Android creates by name,
# keep Room, and avoid blanket @Stable/@Immutable keep rules.

# Components the system starts by name
-keep class com.example.service.TimerForegroundService { *; }
-keep class * extends android.app.Service { *; }
-keep class * extends android.content.BroadcastReceiver { *; }
-keep class com.example.widget.StudyWidgetReceiver { *; }
-keep class com.example.widget.ToggleTimerActionCallback { *; }

# Room
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keep class com.example.data.model.** { *; }
-dontwarn androidx.room.paging.**

# Glance (widget)
-keep class * extends androidx.glance.appwidget.GlanceAppWidget { *; }
-keep class * extends androidx.glance.appwidget.GlanceAppWidgetReceiver { *; }
-keep class * extends androidx.glance.action.ActionCallback { *; }

# ViewModels are created by reflection
-keepclassmembers class * extends androidx.lifecycle.ViewModel { <init>(...); }
-keepclassmembers class * extends androidx.lifecycle.AndroidViewModel { <init>(android.app.Application); }

# Application class and the crash screen
-keep class com.example.StudyApplication { *; }
-keep class com.example.util.CrashReporter { *; }

# Readable crash reports. Costs little size. Remove only once the app is stable.
-keepattributes SourceFile,LineNumberTable
-dontobfuscate

# Compose + R8 crash seen in Parallax (IncompatibleClassChangeError on Modifier).
# These three were applied together there, which one mattered is UNKNOWN.
-keep interface androidx.compose.ui.Modifier { *; }
-keep interface androidx.compose.ui.Modifier$Element { *; }
-keep interface androidx.compose.ui.modifier.ModifierLocalProvider { *; }
-keep interface androidx.compose.ui.modifier.ModifierLocalConsumer { *; }
-dontoptimize
