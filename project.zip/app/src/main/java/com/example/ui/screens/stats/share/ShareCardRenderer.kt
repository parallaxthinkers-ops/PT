package com.example.ui.screens.stats.share

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.example.R
import com.example.ui.screens.stats.StatsEngine
import com.example.ui.screens.stats.StatsTab
import com.example.ui.theme.HeatMath
import com.example.ui.theme.LayoutMath
import com.example.ui.theme.ThemeMath
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Draws the "Download SS" picture straight onto a bitmap with Android's Canvas.
 *
 * It does NOT capture the Compose screen. Capturing a screen that is not showing depends on frame timing and on how
 * much is on screen, which is fragile. Drawing it by hand is slower to write, but it is the same every time, it never
 * touches the visible screen, and the size of the picture is fixed (1080 wide) whatever the phone is.
 */
object ShareCardRenderer {

    fun render(context: Context, model: ShareModel): Bitmap {
        val layout = ShareLayout.compute(model.layoutInput())
        val bitmap = Bitmap.createBitmap(layout.width, layout.height, Bitmap.Config.ARGB_8888)
        Drawer(context, model, layout, Canvas(bitmap)).draw()
        return bitmap
    }

    // ---- colour helpers ------------------------------------------------------------------------------------------

    private fun argb(c: Long): Int = c.toInt()

    private fun withAlpha(c: Long, alpha: Float): Int {
        val a = (alpha.coerceIn(0f, 1f) * 255f).roundToInt()
        return (a shl 24) or (c.toInt() and 0x00FFFFFF)
    }

    private fun mixed(a: Long, b: Long, t: Float): Int = LayoutMath.mix(a, b, t).toInt()

    private fun fillPaint(color: Int): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        this.color = color
    }

    private fun strokePaint(color: Int, width: Float): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = width
        this.color = color
    }

    private fun textPaint(color: Int, size: Float, face: Typeface, align: Paint.Align = Paint.Align.LEFT): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = face
            textAlign = align
        }

    /** The Ethnocentric font if its file is in assets/fonts (same rule as the Timer screen), otherwise null. */
    private fun brandTypeface(context: Context): Typeface? = try {
        val assets = context.applicationContext.assets
        val file = assets.list("fonts").orEmpty().firstOrNull {
            val n = it.lowercase()
            n.contains("ethnocentric") && (n.endsWith(".ttf") || n.endsWith(".otf"))
        }
        if (file == null) null else Typeface.createFromAsset(assets, "fonts/$file")
    } catch (_: Exception) {
        null
    }

    private fun logoBitmap(context: Context): Bitmap? = try {
        val options = BitmapFactory.Options().apply { inScaled = false }
        BitmapFactory.decodeResource(context.resources, R.drawable.logo_mark, options)
    } catch (_: Throwable) {
        null
    }

    // ---- the drawing ---------------------------------------------------------------------------------------------

    private class Drawer(
        val context: Context,
        val model: ShareModel,
        val layout: ShareLayoutResult,
        val c: Canvas
    ) {
        val col = model.colors
        val w = layout.width.toFloat()
        val h = layout.height.toFloat()
        val m = ShareLayout.MARGIN.toFloat()
        val cardW = w - 2f * m
        val pad = 32f
        val radius = 40f

        val regular: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val bold: Typeface = Typeface.create("sans-serif", Typeface.BOLD)
        val brand: Typeface? = brandTypeface(context)

        val ink = argb(col.onSurface)
        val inkSoft = argb(col.onVariant)
        val accent = argb(col.accent)

        fun draw() {
            background()
            for (box in layout.blocks) {
                val top = box.top.toFloat()
                val height = box.height.toFloat()
                when (box.kind) {
                    ShareBlockKind.BRAND -> brandRow(top, height)
                    ShareBlockKind.HERO -> hero(top, height)
                    ShareBlockKind.CALENDAR -> model.calendar?.let { calendar(it, top, height) }
                    ShareBlockKind.HEAT -> model.heat?.let { heat(it, top, height) }
                    ShareBlockKind.COMPARE -> model.compare?.let { compare(it, top, height) }
                    ShareBlockKind.BARS -> model.bars?.let { bars(it, top, height) }
                    ShareBlockKind.SUBJECTS -> subjects(model.subjects, top, height)
                    ShareBlockKind.FOOTER -> footer(top, height)
                }
            }
        }

        // ---- small tools -----------------------------------------------------------------------------------------

        /** Draws [text], shrinking it a little and then cutting it with "..." so it never leaves [maxWidth]. */
        fun fitText(text: String, x: Float, baseline: Float, maxWidth: Float, paint: Paint, minScale: Float = 0.62f) {
            val original = paint.textSize
            var size = original
            while (paint.measureText(text) > maxWidth && size > original * minScale) {
                size -= 1f
                paint.textSize = size
            }
            var s = text
            if (paint.measureText(s) > maxWidth) {
                while (s.length > 1 && paint.measureText("$s…") > maxWidth) s = s.dropLast(1)
                s += "…"
            }
            c.drawText(s, x, baseline, paint)
            paint.textSize = original
        }

        fun card(top: Float, height: Float) {
            val rect = RectF(m, top, m + cardW, top + height)
            c.drawRoundRect(rect, radius, radius, fillPaint(withAlpha(col.surface, LayoutMath.GLASS_ALPHA)))
            val edge = RectF(rect)
            edge.inset(1.5f, 1.5f)
            c.drawRoundRect(edge, radius, radius, strokePaint(withAlpha(LayoutMath.mix(col.surface, col.onSurface, 0.2f), 0.6f), 3f))
        }

        /** The small accent bar and the title at the top-left of a card; [right] is an optional note at the top-right. */
        fun cardTitle(top: Float, title: String, right: String? = null) {
            val baseline = top + 50f
            val bar = RectF(m + pad, baseline - 26f, m + pad + 8f, baseline + 6f)
            c.drawRoundRect(bar, 4f, 4f, fillPaint(accent))
            val titlePaint = textPaint(ink, 30f, medium)
            val rightWidth = if (right != null) 300f else 0f
            fitText(title, m + pad + 22f, baseline, cardW - 2f * pad - 22f - rightWidth, titlePaint)
            if (right != null) {
                val p = textPaint(inkSoft, 26f, regular, Paint.Align.RIGHT)
                fitText(right, m + cardW - pad, baseline, rightWidth - 16f, p)
            }
        }

        // ---- background, brand, hero ------------------------------------------------------------------------------

        fun background() {
            val stops = LayoutMath.glassStops(col.bg, col.accent, col.accent2, col.dark)
            val colors = IntArray(stops.size) { argb(stops[it]) }
            val positions = FloatArray(stops.size) { if (stops.size == 1) 0f else it / (stops.size - 1).toFloat() }
            val gradient = Paint(Paint.ANTI_ALIAS_FLAG)
            gradient.shader = LinearGradient(0f, 0f, w * 0.85f, h, colors, positions, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, gradient)

            // Two soft glows, one in each colour of the theme, so the page is not a flat gradient.
            val glowA = Paint(Paint.ANTI_ALIAS_FLAG)
            glowA.shader = RadialGradient(w * 0.92f, h * 0.06f, 560f, withAlpha(col.accent, 0.26f), withAlpha(col.accent, 0f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, glowA)
            val glowB = Paint(Paint.ANTI_ALIAS_FLAG)
            glowB.shader = RadialGradient(w * 0.06f, h * 0.94f, 620f, withAlpha(col.accent2, 0.22f), withAlpha(col.accent2, 0f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, glowB)
        }

        fun brandRow(top: Float, height: Float) {
            val logoSize = 72f
            val logoTop = top + (height - logoSize) / 2f
            val logo = logoBitmap(context)
            if (logo != null) {
                val dst = RectF(m, logoTop, m + logoSize, logoTop + logoSize)
                val path = Path()
                path.addRoundRect(dst, 18f, 18f, Path.Direction.CW)
                c.save()
                c.clipPath(path)
                c.drawBitmap(logo, null, dst, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
                c.restore()
                logo.recycle()
            }
            val nameX = m + logoSize + 22f
            val chipPaint = textPaint(argb(ThemeMath.onColorFor(col.accent)), 28f, bold, Paint.Align.CENTER)
            val chipText = model.tabLabel.uppercase()
            val chipW = chipPaint.measureText(chipText) + 56f
            val chipH = 56f
            val chipTop = top + (height - chipH) / 2f
            val chip = RectF(m + cardW - chipW, chipTop, m + cardW, chipTop + chipH)
            c.drawRoundRect(chip, chipH / 2f, chipH / 2f, fillPaint(accent))
            c.drawText(chipText, chip.centerX(), chipTop + 38f, chipPaint)

            val namePaint = textPaint(ink, if (brand != null) 36f else 40f, brand ?: bold)
            fitText(model.appName, nameX, top + height / 2f + 13f, chip.left - nameX - 20f, namePaint)
        }

        fun hero(top: Float, height: Float) {
            card(top, height)
            val cx = m + cardW / 2f
            val inner = cardW - 2f * pad

            val titlePaint = textPaint(ink, 44f, bold, Paint.Align.CENTER)
            fitText(model.periodTitle, cx, top + 78f, inner, titlePaint)

            val labelPaint = textPaint(inkSoft, 28f, regular, Paint.Align.CENTER)
            fitText(model.totalLabel, cx, top + 128f, inner, labelPaint)

            val totalPaint = textPaint(ink, 150f, bold, Paint.Align.CENTER)
            fitText(model.totalText, cx, top + 268f, inner, totalPaint)

            // The change against the previous period: a pill with a small arrow.
            val kindColor = when (model.badgeKind) {
                1 -> col.success
                -1 -> col.danger
                else -> col.onVariant
            }
            val badgePaint = textPaint(argb(kindColor), 28f, bold)
            val arrow = if (model.badgeKind == 0) 0f else 30f
            val badgeText = fitBadge(model.badgeText, badgePaint, inner - 120f)
            val textW = badgePaint.measureText(badgeText)
            val pillW = textW + 56f + arrow
            val pillH = 58f
            val pillTop = top + 300f
            val pill = RectF(cx - pillW / 2f, pillTop, cx + pillW / 2f, pillTop + pillH)
            c.drawRoundRect(pill, pillH / 2f, pillH / 2f, fillPaint(withAlpha(kindColor, 0.16f)))
            var textX = pill.left + 28f
            if (model.badgeKind != 0) {
                val ay = pillTop + pillH / 2f
                val tri = Path()
                if (model.badgeKind > 0) {
                    tri.moveTo(textX, ay + 9f); tri.lineTo(textX + 20f, ay + 9f); tri.lineTo(textX + 10f, ay - 10f)
                } else {
                    tri.moveTo(textX, ay - 9f); tri.lineTo(textX + 20f, ay - 9f); tri.lineTo(textX + 10f, ay + 10f)
                }
                tri.close()
                c.drawPath(tri, fillPaint(argb(kindColor)))
                textX += arrow
            }
            c.drawText(badgeText, textX, pillTop + 39f, badgePaint)

            // A thin line, then up to three small numbers side by side.
            val lineY = top + 378f
            c.drawLine(m + pad, lineY, m + cardW - pad, lineY, strokePaint(withAlpha(col.hairline, 0.9f), 2f))
            val stats = model.stats.take(3)
            if (stats.isNotEmpty()) {
                val colW = inner / stats.size
                stats.forEachIndexed { i, stat ->
                    val sx = m + pad + colW * i + colW / 2f
                    val valuePaint = textPaint(ink, 36f, bold, Paint.Align.CENTER)
                    fitText(stat.value, sx, top + 422f, colW - 16f, valuePaint)
                    val statLabel = textPaint(inkSoft, 22f, regular, Paint.Align.CENTER)
                    fitText(stat.label, sx, top + 452f, colW - 16f, statLabel)
                }
            }
        }

        fun fitBadge(text: String, paint: Paint, maxWidth: Float): String {
            var s = text
            while (s.length > 1 && paint.measureText(s) > maxWidth) s = s.dropLast(1)
            return if (s.length < text.length) "$s…" else s
        }

        // ---- calendar and heatmap ---------------------------------------------------------------------------------

        fun heatFill(level: Int): Int = argb(HeatMath.fill(level.coerceIn(1, 4), col.surface, col.accent, col.dark))

        fun legend(top: Float, height: Float) {
            val y = top + height - ShareLayout.CARD_PAD - ShareLayout.LEGEND_H / 2f
            val lessPaint = textPaint(inkSoft, 22f, regular)
            var x = m + pad
            c.drawText(model.lessLabel, x, y + 8f, lessPaint)
            x += lessPaint.measureText(model.lessLabel) + 14f
            for (level in 0..4) {
                val box = RectF(x, y - 11f, x + 22f, y + 11f)
                val color = if (level == 0) withAlpha(col.variant, 0.7f) else heatFill(level)
                c.drawRoundRect(box, 6f, 6f, fillPaint(color))
                x += 22f + 8f
            }
            c.drawText(model.moreLabel, x + 6f, y + 8f, lessPaint)
        }

        fun gridWidth(): Float = cardW - 2f * pad

        fun calendar(block: ShareCalendarBlock, top: Float, height: Float) {
            card(top, height)
            cardTitle(top, block.title, block.totalText)
            val grid = block.grid
            val cols = grid.columns
            val gap = 8f
            val cellW = (gridWidth() - gap * (cols - 1)) / cols
            val cellH = ShareLayout.calendarCellHeight(grid.tab).toFloat()
            var y = top + ShareLayout.CARD_TITLE_H

            if (grid.tab == StatsTab.DAY && block.weekdayHeaders.size == 7) {
                val p = textPaint(inkSoft, 24f, regular, Paint.Align.CENTER)
                for (i in 0 until 7) {
                    c.drawText(block.weekdayHeaders[i], m + pad + i * (cellW + gap) + cellW / 2f, y + 30f, p)
                }
                y += ShareLayout.WEEKDAY_ROW_H
            }

            val empty = withAlpha(col.variant, 0.7f)
            val labelSize = if (grid.tab == StatsTab.MONTH) 28f else 26f
            val slots = ArrayList<Int>() // index into grid.cells, or -1 for a blank
            repeat(grid.leadingBlanks) { slots.add(-1) }
            grid.cells.indices.forEach { slots.add(it) }

            slots.forEachIndexed { slot, cellIndex ->
                if (cellIndex < 0) return@forEachIndexed
                val cell = grid.cells[cellIndex]
                val row = slot / cols
                val column = slot % cols
                val left = m + pad + column * (cellW + gap)
                val cellTop = y + row * (cellH + ShareLayout.ROW_GAP)
                val rect = RectF(left, cellTop, left + cellW, cellTop + cellH)

                val fill = when {
                    cell.level >= 1 -> heatFill(cell.level)
                    cell.isFuture -> 0
                    else -> empty
                }
                if (fill != 0) c.drawRoundRect(rect, 14f, 14f, fillPaint(fill))
                val textColor = when {
                    cell.level >= 1 -> argb(HeatMath.textOn(fill.toLong() and 0xFFFFFFFFL))
                    cell.isFuture -> withAlpha(col.onVariant, 0.6f)
                    else -> ink
                }
                val selected = cell.date == block.selectedDate
                val cx = rect.centerX()
                val hasTime = cell.seconds >= 60L
                val labelPaint = textPaint(textColor, labelSize, if (selected) bold else medium, Paint.Align.CENTER)
                if (hasTime) {
                    fitText(cell.label, cx, cellTop + cellH * 0.45f, cellW - 8f, labelPaint)
                    val timePaint = textPaint(textColor, 21f, regular, Paint.Align.CENTER)
                    fitText(StatsEngine.clock(cell.seconds), cx, cellTop + cellH * 0.45f + 25f, cellW - 8f, timePaint)
                } else {
                    fitText(cell.label, cx, cellTop + cellH / 2f + labelSize * 0.35f, cellW - 8f, labelPaint)
                }
                if (selected) {
                    val outline = RectF(rect)
                    outline.inset(1.5f, 1.5f)
                    c.drawRoundRect(outline, 14f, 14f, strokePaint(ink, 3f))
                }
            }
            legend(top, height)
        }

        fun heat(block: ShareHeatBlock, top: Float, height: Float) {
            card(top, height)
            cardTitle(top, block.title, block.subtitle)
            val cols = 7
            val gap = 8f
            val cellW = (gridWidth() - gap * (cols - 1)) / cols
            val cellH = ShareLayout.HEAT_CELL_H.toFloat()
            var y = top + ShareLayout.CARD_TITLE_H

            val headerPaint = textPaint(inkSoft, 24f, regular, Paint.Align.CENTER)
            for (i in 0 until 7) {
                val name = block.weekdayHeaders.getOrNull(i) ?: ""
                c.drawText(name, m + pad + i * (cellW + gap) + cellW / 2f, y + 30f, headerPaint)
            }
            y += ShareLayout.WEEKDAY_ROW_H

            val empty = withAlpha(col.variant, 0.85f)
            block.days.forEachIndexed { index, day ->
                val slot = block.leadingBlanks + index
                val row = slot / cols
                val column = slot % cols
                val left = m + pad + column * (cellW + gap)
                val cellTop = y + row * (cellH + ShareLayout.ROW_GAP)
                val rect = RectF(left, cellTop, left + cellW, cellTop + cellH)
                val filled = day.intensity >= 1
                val fill = if (filled) heatFill(day.intensity) else empty
                c.drawRoundRect(rect, 12f, 12f, fillPaint(fill))
                val textColor = if (filled) argb(HeatMath.textOn(fill.toLong() and 0xFFFFFFFFL)) else ink
                val p = textPaint(textColor, 25f, medium, Paint.Align.CENTER)
                c.drawText(day.dayNumber.toString(), rect.centerX(), rect.centerY() + 9f, p)
            }
            legend(top, height)
        }

        // ---- "Up to ..." comparison ---------------------------------------------------------------------------------

        fun compare(block: ShareCompareBlock, top: Float, height: Float) {
            card(top, height)
            cardTitle(top, block.title)
            val chart = block.chart
            val leftX = m + pad
            val leftW = 300f

            fitText(block.upTo, leftX, top + 124f, leftW, textPaint(ink, 32f, medium))
            fitText(block.diffText, leftX, top + 196f, leftW, textPaint(ink, 54f, bold))

            // Legend: today (line and ringed dot) and the record (grey box).
            val legendY1 = top + 252f
            val legendY2 = top + 294f
            val today = textPaint(ink, 26f, regular)
            fitText(block.todayLabel, leftX, legendY1 + 9f, 150f, today)
            val markX = leftX + 168f
            c.drawLine(markX, legendY1, markX + 48f, legendY1, strokePaint(accent, 6f).apply { strokeCap = Paint.Cap.ROUND })
            c.drawCircle(markX + 52f, legendY1, 12f, fillPaint(withAlpha(col.accent, 0.35f)))
            c.drawCircle(markX + 52f, legendY1, 9f, fillPaint(accent))
            c.drawCircle(markX + 52f, legendY1, 3.5f, fillPaint(argb(col.surface)))
            fitText(block.recordLabel, leftX, legendY2 + 9f, 150f, today)
            val greyBox = RectF(markX, legendY2 - 13f, markX + 56f, legendY2 + 13f)
            c.drawRoundRect(greyBox, 6f, 6f, fillPaint(recordGrey()))

            // The chart.
            val chartLeft = leftX + leftW + 30f
            val chartRight = m + cardW - pad
            val chartTop = top + ShareLayout.CARD_TITLE_H + 6f
            val chartBottom = top + height - ShareLayout.CARD_PAD - 44f
            val padX = 14f
            val padY = 14f
            val cw = (chartRight - chartLeft) - 2f * padX
            val ch = (chartBottom - chartTop) - 2f * padY
            val bins = chart.bins.coerceAtLeast(1)
            val maxValue = max(chart.baselineLevels.maxOrNull() ?: 0L, chart.todayLevels.maxOrNull() ?: 0L).coerceAtLeast(1L)
            val slot = cw / bins
            fun yOf(v: Long): Float = chartTop + padY + ch - (v.toFloat() / maxValue.toFloat()) * ch

            val grey = fillPaint(recordGrey())
            chart.baselineLevels.forEachIndexed { i, v ->
                val topY = yOf(v)
                c.drawRect(chartLeft + padX + i * slot, topY, chartLeft + padX + (i + 1) * slot + 0.6f, chartTop + padY + ch, grey)
            }

            val spanX = (chartLeft + padX + (chart.spanBins / bins) * cw).coerceIn(chartLeft + padX, chartLeft + padX + cw)
            val path = Path()
            chart.todayLevels.forEachIndexed { i, v ->
                val y = yOf(v)
                val x0 = min(chartLeft + padX + i * slot, spanX)
                val x1 = min(chartLeft + padX + (i + 1) * slot, spanX)
                if (i == 0) path.moveTo(x0, y) else path.lineTo(x0, y)
                path.lineTo(x1, y)
            }
            val line = strokePaint(accent, 6f)
            line.strokeCap = Paint.Cap.ROUND
            line.strokeJoin = Paint.Join.ROUND
            c.drawPath(path, line)
            val dotY = yOf(chart.todayLevels.lastOrNull() ?: 0L)
            c.drawCircle(spanX, dotY, 17f, fillPaint(withAlpha(col.accent, 0.35f)))
            c.drawCircle(spanX, dotY, 12f, fillPaint(accent))
            c.drawCircle(spanX, dotY, 5f, fillPaint(argb(col.surface)))

            // Axis labels.
            val axis = textPaint(inkSoft, 22f, regular)
            val labels = block.axisLabels
            val axisY = chartBottom + 30f
            if (chart.tab == StatsTab.WEEK && labels.size == 7) {
                axis.textAlign = Paint.Align.CENTER
                val s7 = cw / 7f
                labels.forEachIndexed { i, label -> c.drawText(label, chartLeft + padX + s7 * i + s7 / 2f, axisY, axis) }
            } else if (labels.isNotEmpty()) {
                labels.forEachIndexed { i, label ->
                    when (i) {
                        0 -> { axis.textAlign = Paint.Align.LEFT; c.drawText(label, chartLeft + padX, axisY, axis) }
                        labels.size - 1 -> { axis.textAlign = Paint.Align.RIGHT; c.drawText(label, chartLeft + padX + cw, axisY, axis) }
                        else -> { axis.textAlign = Paint.Align.CENTER; c.drawText(label, chartLeft + padX + cw / 2f, axisY, axis) }
                    }
                }
            }
        }

        /** The record is grey, taken from the text colour so it reads on every theme (same rule as the Stats screen). */
        fun recordGrey(): Int = withAlpha(col.onSurface, if (col.dark) 0.24f else 0.18f)

        // ---- bar chart -----------------------------------------------------------------------------------------------

        fun bars(block: ShareBarsBlock, top: Float, height: Float) {
            card(top, height)
            cardTitle(top, block.title, block.maxText)
            val points = block.points
            if (points.isEmpty()) return
            val left = m + pad
            val right = m + cardW - pad
            val chartTop = top + ShareLayout.CARD_TITLE_H + 6f
            val chartBottom = top + height - ShareLayout.CARD_PAD - 40f
            val ch = chartBottom - chartTop
            val cw = right - left
            val maxSeconds = points.maxOf { it.seconds }.coerceAtLeast(60L)

            val grid = strokePaint(withAlpha(col.hairline, 0.9f), 2f)
            for (i in 0..3) {
                val y = chartTop + ch * (i / 3f)
                c.drawLine(left, y, right, y, grid)
            }
            val slot = cw / points.size
            val barW = slot * 0.62f
            val corner = min(8f, barW / 2f)
            points.forEachIndexed { index, p ->
                val fraction = if (p.seconds <= 0L) 0.03f else (p.seconds.toFloat() / maxSeconds.toFloat()).coerceIn(0.05f, 1f)
                val barH = ch * fraction
                val x = left + index * slot + (slot - barW) / 2f
                val color = when {
                    p.seconds <= 0L -> withAlpha(col.variant, 0.9f)
                    p.isBest -> argb(col.warning)
                    else -> accent
                }
                c.drawRoundRect(RectF(x, chartBottom - barH, x + barW, chartBottom), corner, corner, fillPaint(color))
            }
            val labelPaint = textPaint(inkSoft, 22f, regular, Paint.Align.CENTER)
            val step = block.labelStep.coerceAtLeast(1)
            points.forEachIndexed { index, p ->
                if (index % step == 0) c.drawText(p.label, left + index * slot + slot / 2f, chartBottom + 30f, labelPaint)
            }
        }

        // ---- subjects -----------------------------------------------------------------------------------------------

        fun subjects(block: ShareSubjectsBlock, top: Float, height: Float) {
            card(top, height)
            cardTitle(top, block.title)
            val rows = block.rows
            if (rows.isEmpty()) {
                val p = textPaint(inkSoft, 28f, regular, Paint.Align.CENTER)
                fitText(block.emptyText, m + cardW / 2f, top + ShareLayout.CARD_TITLE_H + 72f, cardW - 2f * pad, p)
                return
            }
            val donut = ShareLayout.DONUT.toFloat()
            val areaTop = top + ShareLayout.CARD_TITLE_H
            val dcx = m + pad + donut / 2f
            val dcy = areaTop + donut / 2f
            val stroke = 40f
            val oval = RectF(dcx - donut / 2f + stroke / 2f, dcy - donut / 2f + stroke / 2f, dcx + donut / 2f - stroke / 2f, dcy + donut / 2f - stroke / 2f)
            val total = rows.sumOf { it.seconds }.coerceAtLeast(1L).toFloat()
            var start = -90f
            val gapDeg = if (rows.size > 1) 2.5f else 0f
            rows.forEach { r ->
                val sweep = r.seconds / total * 360f
                val arc = strokePaint(argb(r.color), stroke)
                c.drawArc(oval, start + gapDeg / 2f, (sweep - gapDeg).coerceAtLeast(0.5f), false, arc)
                start += sweep
            }
            fitText(block.totalText, dcx, dcy + 8f, donut - 2f * stroke - 16f, textPaint(ink, 38f, bold, Paint.Align.CENTER))
            c.drawText(block.totalShort, dcx, dcy + 40f, textPaint(inkSoft, 22f, regular, Paint.Align.CENTER))

            val listX = m + pad + donut + 40f
            val listRight = m + cardW - pad
            val rowH = ShareLayout.SUBJECT_ROW_H.toFloat()
            val listTop = areaTop + (donut - rows.size * rowH) / 2f
            rows.forEachIndexed { i, r ->
                val cy = listTop + i * rowH + rowH / 2f
                c.drawCircle(listX + 11f, cy, 11f, fillPaint(argb(r.color)))
                val timePaint = textPaint(ink, 27f, bold, Paint.Align.RIGHT)
                val pctPaint = textPaint(inkSoft, 23f, regular, Paint.Align.RIGHT)
                c.drawText("${r.percent}%", listRight, cy + 8f, pctPaint)
                val timeRight = listRight - 74f
                c.drawText(com.example.util.DateTimeUtils.formatDurationShort(r.seconds), timeRight, cy + 9f, timePaint)
                val nameMax = timeRight - timePaint.measureText(com.example.util.DateTimeUtils.formatDurationShort(r.seconds)) - 16f - (listX + 36f)
                // A long subject name is cut with "..." rather than shrunk, so every row keeps the same size.
                fitText(r.name, listX + 36f, cy + 9f, nameMax, textPaint(ink, 27f, regular), minScale = 0.92f)
            }
        }

        // ---- footer ------------------------------------------------------------------------------------------------

        fun footer(top: Float, height: Float) {
            val p = textPaint(inkSoft, 24f, regular, Paint.Align.CENTER)
            fitText(model.footer, w / 2f, top + height / 2f + 8f, cardW, p)
        }
    }
}
