package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.util.Calendar

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "studylocal_settings")

class SettingsRepository(private val context: Context) {
    companion object {
        val KEY_DAY_START_HOUR = intPreferencesKey("day_start_hour") // 0..23 (default 5 for 5 AM)
        val KEY_THEME_MODE = stringPreferencesKey("theme_mode") // SYSTEM, LIGHT, DARK
        val KEY_THEME_STYLE = stringPreferencesKey("theme_style") // MINIMAL, SOFT (old: MATERIAL, NEUMORPHISM)
        val KEY_AMOLED = booleanPreferencesKey("amoled_dark")
        val KEY_CORNER_STYLE = stringPreferencesKey("corner_style") // SHARP, ROUNDED, PILL
        // A NEW key on purpose: the old "timeline_zoom" held 1, 2 or 4, this one holds the level 0, 1 or 2.
        val KEY_TIMELINE_ZOOM = intPreferencesKey("timeline_zoom_level")
        val KEY_ACCENT_COLOR = longPreferencesKey("accent_color")
        val KEY_LANGUAGE = stringPreferencesKey("app_language") // "en", "bn"
        val KEY_SELECTED_SUBJECT_ID = longPreferencesKey("selected_subject_id")
        val KEY_DEFAULT_TIMER_MODE = stringPreferencesKey("default_timer_mode") // STOPWATCH, COUNTDOWN, POMODORO
        val KEY_KEEP_SCREEN_ON = booleanPreferencesKey("keep_screen_on")
        val KEY_SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val KEY_VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
        val KEY_FIRST_DAY_OF_WEEK = intPreferencesKey("first_day_of_week") // Calendar.MONDAY (2) or SUNDAY (1)
        val KEY_12_HOUR_FORMAT = booleanPreferencesKey("is_12_hour_format")
        val KEY_POMO_FOCUS_MINUTES = intPreferencesKey("pomo_focus_minutes")
        val KEY_POMO_SHORT_BREAK_MINUTES = intPreferencesKey("pomo_short_break_minutes")
        val KEY_POMO_LONG_BREAK_MINUTES = intPreferencesKey("pomo_long_break_minutes")
        val KEY_POMO_LONG_BREAK_INTERVAL = intPreferencesKey("pomo_long_break_interval")
        val KEY_POMO_AUTO_START = booleanPreferencesKey("pomo_auto_start")
        val KEY_COUNTDOWN_MINUTES = intPreferencesKey("countdown_minutes")
        val KEY_COUNTDOWN_SECONDS = longPreferencesKey("countdown_duration_seconds")
        val KEY_CUSTOM_PRESETS = stringPreferencesKey("custom_countdown_presets")
        val KEY_ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val KEY_DIFFERENT_GOAL_PER_WEEKDAY = booleanPreferencesKey("different_goal_per_weekday")

        // Reminders
        val KEY_STUDY_REMINDER_ENABLED = booleanPreferencesKey("study_reminder_enabled")
        val KEY_STUDY_REMINDER_HOUR = intPreferencesKey("study_reminder_hour")
        val KEY_STUDY_REMINDER_MINUTE = intPreferencesKey("study_reminder_minute")
        val KEY_STUDY_REMINDER_DAYS = stringPreferencesKey("study_reminder_days")
        val KEY_BREAK_REMINDER_ENABLED = booleanPreferencesKey("break_reminder_enabled")
        val KEY_BREAK_REMINDER_MINUTES = intPreferencesKey("break_reminder_minutes")
        val KEY_AUTO_BACKUP_REMINDER_ENABLED = booleanPreferencesKey("auto_backup_reminder_enabled")
        val KEY_AUTO_BACKUP_REMINDER_DAYS = intPreferencesKey("auto_backup_reminder_days")
        val KEY_LAST_BACKUP_TIME = longPreferencesKey("last_backup_time")

        // Scheduled backup
        val KEY_AUTO_BACKUP_ENABLED = booleanPreferencesKey("auto_backup_enabled")
        val KEY_AUTO_BACKUP_FOLDER_URI = stringPreferencesKey("auto_backup_folder_uri")
        val KEY_AUTO_BACKUP_FOLDER_NAME = stringPreferencesKey("auto_backup_folder_name")
        val KEY_AUTO_BACKUP_INTERVAL_DAYS = intPreferencesKey("auto_backup_interval_days")
        val KEY_AUTO_BACKUP_KEEP = intPreferencesKey("auto_backup_keep")
        val KEY_AUTO_BACKUP_LAST_SUCCESS = longPreferencesKey("auto_backup_last_success")
        val KEY_AUTO_BACKUP_LAST_ATTEMPT = longPreferencesKey("auto_backup_last_attempt")
        val KEY_AUTO_BACKUP_LAST_ERROR = stringPreferencesKey("auto_backup_last_error")

        // Focus Mode
        val KEY_AMBIENT_MODE_ENABLED = booleanPreferencesKey("ambient_mode_enabled")
        val KEY_DND_PROMPT_ENABLED = booleanPreferencesKey("dnd_prompt_enabled")
        val KEY_SCREEN_PINNING_EXPLAINED = booleanPreferencesKey("screen_pinning_explained")

        const val DEFAULT_PRESETS = "5,10,15,25,45,60,90"
        const val DEFAULT_REMINDER_DAYS = "1,2,3,4,5,6,7"
        const val DEFAULT_ACCENT_COLOR = 0xFF3B6EF6L // Azure, taken from the logo's blue
    }

    /** Every setting in one snapshot. Emits only when something actually changed. */
    val settings: Flow<AppSettings> = context.dataStore.data
        .map { prefs -> prefs.toAppSettings() }
        .distinctUntilChanged()

    private fun Preferences.toAppSettings(): AppSettings {
        val prefs = this
        val presets = (prefs[KEY_CUSTOM_PRESETS] ?: DEFAULT_PRESETS).split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 1..1440 }
            .distinct()
            .sorted()
        val reminderDays = (prefs[KEY_STUDY_REMINDER_DAYS] ?: DEFAULT_REMINDER_DAYS).split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 1..7 }
            .toSet()
        return AppSettings(
            dayStartHour = prefs[KEY_DAY_START_HOUR] ?: 5,
            themeMode = prefs[KEY_THEME_MODE] ?: "SYSTEM",
            themeStyle = ThemeStyleNames.normalize(prefs[KEY_THEME_STYLE]),
            accentColor = prefs[KEY_ACCENT_COLOR] ?: DEFAULT_ACCENT_COLOR,
            amoled = prefs[KEY_AMOLED] ?: false,
            cornerStyle = CornerStyleNames.normalize(prefs[KEY_CORNER_STYLE]),
            language = prefs[KEY_LANGUAGE] ?: "en",
            keepScreenOn = prefs[KEY_KEEP_SCREEN_ON] ?: true,
            soundEnabled = prefs[KEY_SOUND_ENABLED] ?: true,
            vibrationEnabled = prefs[KEY_VIBRATION_ENABLED] ?: true,
            firstDayOfWeek = prefs[KEY_FIRST_DAY_OF_WEEK] ?: Calendar.MONDAY,
            is12Hour = prefs[KEY_12_HOUR_FORMAT] ?: false,
            // The default is Countdown or Pomodoro. An old saved STOPWATCH (or anything else) opens as Countdown.
            defaultTimerMode = if (prefs[KEY_DEFAULT_TIMER_MODE] == "POMODORO") "POMODORO" else "COUNTDOWN",
            pomoFocusMinutes = prefs[KEY_POMO_FOCUS_MINUTES] ?: 25,
            pomoShortBreakMinutes = prefs[KEY_POMO_SHORT_BREAK_MINUTES] ?: 5,
            pomoLongBreakMinutes = prefs[KEY_POMO_LONG_BREAK_MINUTES] ?: 15,
            pomoInterval = prefs[KEY_POMO_LONG_BREAK_INTERVAL] ?: 4,
            pomoAutoStart = prefs[KEY_POMO_AUTO_START] ?: false,
            countdownSeconds = prefs[KEY_COUNTDOWN_SECONDS] ?: ((prefs[KEY_COUNTDOWN_MINUTES] ?: 30) * 60L),
            customPresets = presets,
            selectedSubjectId = prefs[KEY_SELECTED_SUBJECT_ID],
            timelineZoom = (prefs[KEY_TIMELINE_ZOOM] ?: 1).coerceIn(0, 2),
            onboardingCompleted = prefs[KEY_ONBOARDING_COMPLETED] ?: false,
            differentGoalPerWeekday = prefs[KEY_DIFFERENT_GOAL_PER_WEEKDAY] ?: false,
            studyReminderEnabled = prefs[KEY_STUDY_REMINDER_ENABLED] ?: false,
            studyReminderHour = prefs[KEY_STUDY_REMINDER_HOUR] ?: 20,
            studyReminderMinute = prefs[KEY_STUDY_REMINDER_MINUTE] ?: 0,
            studyReminderDays = reminderDays,
            breakReminderEnabled = prefs[KEY_BREAK_REMINDER_ENABLED] ?: true,
            breakReminderMinutes = prefs[KEY_BREAK_REMINDER_MINUTES] ?: 90,
            autoBackupReminderEnabled = prefs[KEY_AUTO_BACKUP_REMINDER_ENABLED] ?: false,
            autoBackupReminderDays = prefs[KEY_AUTO_BACKUP_REMINDER_DAYS] ?: 7,
            lastBackupTime = prefs[KEY_LAST_BACKUP_TIME] ?: 0L,
            autoBackupEnabled = prefs[KEY_AUTO_BACKUP_ENABLED] ?: false,
            autoBackupFolderUri = prefs[KEY_AUTO_BACKUP_FOLDER_URI] ?: "",
            autoBackupFolderName = prefs[KEY_AUTO_BACKUP_FOLDER_NAME] ?: "",
            autoBackupIntervalDays = (prefs[KEY_AUTO_BACKUP_INTERVAL_DAYS] ?: 1).coerceIn(1, 30),
            autoBackupKeep = (prefs[KEY_AUTO_BACKUP_KEEP] ?: 7).coerceIn(1, 30),
            autoBackupLastSuccess = prefs[KEY_AUTO_BACKUP_LAST_SUCCESS] ?: 0L,
            autoBackupLastAttempt = prefs[KEY_AUTO_BACKUP_LAST_ATTEMPT] ?: 0L,
            autoBackupLastError = prefs[KEY_AUTO_BACKUP_LAST_ERROR] ?: "",
            ambientMode = prefs[KEY_AMBIENT_MODE_ENABLED] ?: false,
            dndPromptEnabled = prefs[KEY_DND_PROMPT_ENABLED] ?: false,
            screenPinningExplained = prefs[KEY_SCREEN_PINNING_EXPLAINED] ?: false
        )
    }

    val dayStartHourFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_DAY_START_HOUR] ?: 5 // Default 5 AM reset time
    }

    val themeModeFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_THEME_MODE] ?: "SYSTEM"
    }

    val themeStyleFlow: Flow<String> = context.dataStore.data.map { prefs ->
        ThemeStyleNames.normalize(prefs[KEY_THEME_STYLE])
    }

    val accentColorFlow: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[KEY_ACCENT_COLOR] ?: DEFAULT_ACCENT_COLOR
    }

    val languageFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_LANGUAGE] ?: "en"
    }

    val selectedSubjectIdFlow: Flow<Long?> = context.dataStore.data.map { prefs ->
        prefs[KEY_SELECTED_SUBJECT_ID]
    }

    val keepScreenOnFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_KEEP_SCREEN_ON] ?: true
    }

    val soundEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_SOUND_ENABLED] ?: true
    }

    val vibrationEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_VIBRATION_ENABLED] ?: true
    }

    val soundVibrationFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        (prefs[KEY_SOUND_ENABLED] ?: true) || (prefs[KEY_VIBRATION_ENABLED] ?: true)
    }

    val firstDayOfWeekFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_FIRST_DAY_OF_WEEK] ?: Calendar.MONDAY
    }

    val is12HourFormatFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_12_HOUR_FORMAT] ?: false
    }

    val pomoFocusMinutesFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_POMO_FOCUS_MINUTES] ?: 25
    }

    val pomoShortBreakMinutesFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_POMO_SHORT_BREAK_MINUTES] ?: 5
    }

    val pomoLongBreakMinutesFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_POMO_LONG_BREAK_MINUTES] ?: 15
    }

    val pomoLongBreakIntervalFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_POMO_LONG_BREAK_INTERVAL] ?: 4
    }

    val pomoAutoStartFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_POMO_AUTO_START] ?: false
    }

    val countdownSecondsFlow: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[KEY_COUNTDOWN_SECONDS] ?: ((prefs[KEY_COUNTDOWN_MINUTES] ?: 30) * 60L)
    }

    val countdownMinutesFlow: Flow<Int> = countdownSecondsFlow.map { (it / 60L).toInt().coerceAtLeast(1) }

    val customPresetsFlow: Flow<List<Int>> = context.dataStore.data.map { prefs ->
        val raw = prefs[KEY_CUSTOM_PRESETS] ?: DEFAULT_PRESETS
        raw.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 1..1440 }
            .distinct()
            .sorted()
    }

    val onboardingCompletedFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_ONBOARDING_COMPLETED] ?: false
    }

    val differentGoalPerWeekdayFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_DIFFERENT_GOAL_PER_WEEKDAY] ?: false
    }

    val studyReminderEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_STUDY_REMINDER_ENABLED] ?: false
    }

    val studyReminderHourFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_STUDY_REMINDER_HOUR] ?: 20 // 8 PM default
    }

    val studyReminderMinuteFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_STUDY_REMINDER_MINUTE] ?: 0
    }

    val studyReminderDaysFlow: Flow<Set<Int>> = context.dataStore.data.map { prefs ->
        val raw = prefs[KEY_STUDY_REMINDER_DAYS] ?: DEFAULT_REMINDER_DAYS
        raw.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 1..7 }
            .toSet()
    }

    val breakReminderEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_BREAK_REMINDER_ENABLED] ?: true
    }

    val breakReminderMinutesFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_BREAK_REMINDER_MINUTES] ?: 90 // 90 min default
    }

    val autoBackupReminderEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_AUTO_BACKUP_REMINDER_ENABLED] ?: false
    }

    val autoBackupReminderDaysFlow: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_AUTO_BACKUP_REMINDER_DAYS] ?: 7
    }

    val lastBackupTimeFlow: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[KEY_LAST_BACKUP_TIME] ?: 0L
    }

    val ambientModeFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_AMBIENT_MODE_ENABLED] ?: false
    }

    val dndPromptEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_DND_PROMPT_ENABLED] ?: false
    }

    val screenPinningExplainedFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_SCREEN_PINNING_EXPLAINED] ?: false
    }

    suspend fun setDayStartHour(hour: Int) {
        context.dataStore.edit { it[KEY_DAY_START_HOUR] = hour.coerceIn(0, 23) }
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { it[KEY_THEME_MODE] = mode }
    }

    suspend fun setThemeStyle(style: String) {
        context.dataStore.edit { it[KEY_THEME_STYLE] = ThemeStyleNames.normalize(style) }
    }

    suspend fun setAmoled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AMOLED] = enabled }
    }

    suspend fun setCornerStyle(style: String) {
        context.dataStore.edit { it[KEY_CORNER_STYLE] = CornerStyleNames.normalize(style) }
    }

    suspend fun setTimelineZoom(zoom: Int) {
        context.dataStore.edit { it[KEY_TIMELINE_ZOOM] = zoom.coerceIn(0, 2) }
    }

    suspend fun setAccentColor(color: Long) {
        context.dataStore.edit { it[KEY_ACCENT_COLOR] = color }
    }

    suspend fun setLanguage(lang: String) {
        com.example.util.LocaleHelper.save(context, lang)
        context.dataStore.edit { it[KEY_LANGUAGE] = lang }
    }

    suspend fun setSelectedSubjectId(id: Long?) {
        context.dataStore.edit {
            if (id != null) {
                it[KEY_SELECTED_SUBJECT_ID] = id
            } else {
                it.remove(KEY_SELECTED_SUBJECT_ID)
            }
        }
    }

    suspend fun setDefaultTimerMode(mode: String) {
        context.dataStore.edit { it[KEY_DEFAULT_TIMER_MODE] = mode }
    }

    suspend fun setKeepScreenOn(keepOn: Boolean) {
        context.dataStore.edit { it[KEY_KEEP_SCREEN_ON] = keepOn }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_SOUND_ENABLED] = enabled }
    }

    suspend fun setVibrationEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_VIBRATION_ENABLED] = enabled }
    }

    suspend fun setSoundVibration(enabled: Boolean) {
        setSoundEnabled(enabled)
        setVibrationEnabled(enabled)
    }

    suspend fun setFirstDayOfWeek(firstDay: Int) {
        context.dataStore.edit { it[KEY_FIRST_DAY_OF_WEEK] = firstDay }
    }

    suspend fun set12HourFormat(is12Hour: Boolean) {
        context.dataStore.edit { it[KEY_12_HOUR_FORMAT] = is12Hour }
    }

    suspend fun setPomoSettings(focus: Int, shortBreak: Int, longBreak: Int, interval: Int) {
        context.dataStore.edit {
            it[KEY_POMO_FOCUS_MINUTES] = focus
            it[KEY_POMO_SHORT_BREAK_MINUTES] = shortBreak
            it[KEY_POMO_LONG_BREAK_MINUTES] = longBreak
            it[KEY_POMO_LONG_BREAK_INTERVAL] = interval
        }
    }

    suspend fun setPomoAutoStart(autoStart: Boolean) {
        context.dataStore.edit { it[KEY_POMO_AUTO_START] = autoStart }
    }

    suspend fun setCountdownSeconds(seconds: Long) {
        val clamped = seconds.coerceIn(1L, 86399L)
        context.dataStore.edit {
            it[KEY_COUNTDOWN_SECONDS] = clamped
            it[KEY_COUNTDOWN_MINUTES] = (clamped / 60L).toInt()
        }
    }

    suspend fun setCountdownMinutes(minutes: Int) {
        setCountdownSeconds(minutes * 60L)
    }

    suspend fun addCustomPreset(minutes: Int) {
        if (minutes !in 1..1440) return
        context.dataStore.edit { prefs ->
            val raw = prefs[KEY_CUSTOM_PRESETS] ?: DEFAULT_PRESETS
            val set = raw.split(",")
                .mapNotNull { it.trim().toIntOrNull() }
                .toMutableSet()
            set.add(minutes)
            prefs[KEY_CUSTOM_PRESETS] = set.sorted().joinToString(",")
        }
    }

    suspend fun deleteCustomPreset(minutes: Int) {
        context.dataStore.edit { prefs ->
            val raw = prefs[KEY_CUSTOM_PRESETS] ?: DEFAULT_PRESETS
            val set = raw.split(",")
                .mapNotNull { it.trim().toIntOrNull() }
                .toMutableSet()
            set.remove(minutes)
            prefs[KEY_CUSTOM_PRESETS] = set.sorted().joinToString(",")
        }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { it[KEY_ONBOARDING_COMPLETED] = completed }
    }

    suspend fun setDifferentGoalPerWeekday(enabled: Boolean) {
        context.dataStore.edit { it[KEY_DIFFERENT_GOAL_PER_WEEKDAY] = enabled }
    }

    suspend fun setStudyReminder(enabled: Boolean, hour: Int, minute: Int, days: Set<Int>) {
        context.dataStore.edit { prefs ->
            prefs[KEY_STUDY_REMINDER_ENABLED] = enabled
            prefs[KEY_STUDY_REMINDER_HOUR] = hour.coerceIn(0, 23)
            prefs[KEY_STUDY_REMINDER_MINUTE] = minute.coerceIn(0, 59)
            prefs[KEY_STUDY_REMINDER_DAYS] = days.sorted().joinToString(",")
        }
    }

    suspend fun setStudyReminderEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_STUDY_REMINDER_ENABLED] = enabled }
    }

    suspend fun setBreakReminder(enabled: Boolean, minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_BREAK_REMINDER_ENABLED] = enabled
            prefs[KEY_BREAK_REMINDER_MINUTES] = minutes.coerceIn(15, 300)
        }
    }

    suspend fun setAutoBackupReminder(enabled: Boolean, days: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_AUTO_BACKUP_REMINDER_ENABLED] = enabled
            prefs[KEY_AUTO_BACKUP_REMINDER_DAYS] = days.coerceIn(1, 30)
        }
    }

    suspend fun setAutoBackupEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_BACKUP_ENABLED] = enabled }
    }

    suspend fun setAutoBackupFolder(uri: String, displayName: String) {
        context.dataStore.edit { prefs ->
            prefs[KEY_AUTO_BACKUP_FOLDER_URI] = uri
            prefs[KEY_AUTO_BACKUP_FOLDER_NAME] = displayName
            prefs[KEY_AUTO_BACKUP_LAST_ERROR] = ""
        }
    }

    suspend fun setAutoBackupPlan(intervalDays: Int, keep: Int) {
        context.dataStore.edit { prefs ->
            prefs[KEY_AUTO_BACKUP_INTERVAL_DAYS] = intervalDays.coerceIn(1, 30)
            prefs[KEY_AUTO_BACKUP_KEEP] = keep.coerceIn(1, 30)
        }
    }

    /** [error] empty = success. A success also counts as "the last backup" for the reminder. */
    suspend fun recordAutoBackupResult(success: Boolean, error: String) {
        val now = System.currentTimeMillis()
        context.dataStore.edit { prefs ->
            prefs[KEY_AUTO_BACKUP_LAST_ATTEMPT] = now
            if (success) {
                prefs[KEY_AUTO_BACKUP_LAST_SUCCESS] = now
                prefs[KEY_LAST_BACKUP_TIME] = now
                prefs[KEY_AUTO_BACKUP_LAST_ERROR] = ""
            } else {
                prefs[KEY_AUTO_BACKUP_LAST_ERROR] = error.take(160)
            }
        }
    }

    suspend fun recordBackupExported() {
        context.dataStore.edit { prefs ->
            prefs[KEY_LAST_BACKUP_TIME] = System.currentTimeMillis()
        }
    }

    suspend fun setAmbientMode(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AMBIENT_MODE_ENABLED] = enabled }
    }

    suspend fun setDndPromptEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_DND_PROMPT_ENABLED] = enabled }
    }

    suspend fun setScreenPinningExplained(explained: Boolean) {
        context.dataStore.edit { it[KEY_SCREEN_PINNING_EXPLAINED] = explained }
    }

    suspend fun resetAllSettings() {
        context.dataStore.edit { it.clear() }
    }
}
