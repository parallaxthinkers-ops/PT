package com.example.ui.screens.themes

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.AccentPicker
import com.example.ui.components.AppCard
import com.example.ui.components.CircularProgressTimer
import com.example.ui.components.ColorDot
import com.example.ui.components.PillSelector
import com.example.ui.components.RowDivider
import com.example.ui.components.SectionLabel
import com.example.ui.components.SettingNavRow
import com.example.ui.components.SettingSwitchRow
import com.example.ui.screens.settings.ControlBlock
import com.example.ui.screens.settings.SettingsViewModel
import com.example.ui.theme.ThemeLayout
import com.example.ui.theme.Ui
import com.example.ui.theme.ThemePresets
import com.example.ui.theme.buildGlassBackdrop
import com.example.ui.theme.buildLayoutColors
import com.example.ui.components.glassSheen
import com.example.ui.components.neoShadows
import com.example.ui.theme.appBackground
import com.example.ui.theme.timerDigitsStyle

/** The display name of an aesthetic, in the app language. Unknown ids show as Classic. */
@Composable
fun presetName(id: String): String = stringResource(
    when (ThemePresets.normalize(id)) {
        "SAKURA" -> R.string.theme_p_sakura
        "COTTON" -> R.string.theme_p_cotton
        "MATCHA" -> R.string.theme_p_matcha
        "LATTE" -> R.string.theme_p_latte
        "ACADEMIA" -> R.string.theme_p_academia
        "NEON" -> R.string.theme_p_neon
        "OCEAN" -> R.string.theme_p_ocean
        "SUNSET" -> R.string.theme_p_sunset
        "LAVENDER" -> R.string.theme_p_lavender
        "INK" -> R.string.theme_p_ink
        "MINT" -> R.string.theme_p_mint
        else -> R.string.theme_p_classic
    }
)

/** One short line that says what the aesthetic feels like. */
@Composable
private fun presetVibe(id: String): String = stringResource(
    when (ThemePresets.normalize(id)) {
        "SAKURA" -> R.string.theme_v_sakura
        "COTTON" -> R.string.theme_v_cotton
        "MATCHA" -> R.string.theme_v_matcha
        "LATTE" -> R.string.theme_v_latte
        "ACADEMIA" -> R.string.theme_v_academia
        "NEON" -> R.string.theme_v_neon
        "OCEAN" -> R.string.theme_v_ocean
        "SUNSET" -> R.string.theme_v_sunset
        "LAVENDER" -> R.string.theme_v_lavender
        "INK" -> R.string.theme_v_ink
        "MINT" -> R.string.theme_v_mint
        else -> R.string.theme_v_classic
    }
)

/**
 * All theme choices on one screen. The list is lazy, so only what is on screen is built, and picking an
 * aesthetic is a single settings write, so the app restyles once.
 */
@Composable
fun ThemesScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val s = state.settings
    val presetId = ThemePresets.normalize(s.themePreset)
    val isClassic = presetId == ThemePresets.CLASSIC
    val isDark = MaterialTheme.colorScheme.surface.luminance() < 0.4f
    val presetAccent = ThemePresets.find(presetId)?.palette(isDark)?.accent
    val presetAccent2 = ThemePresets.find(presetId)?.palette(isDark)?.accent2
    val layout = ThemeLayout.fromName(s.themeLayout)

    // Text that the selector labels need. They are read here because selector label lambdas are not composable.
    val modeLabels = mapOf(
        "SYSTEM" to stringResource(R.string.theme_mode_system),
        "LIGHT" to stringResource(R.string.theme_mode_light),
        "DARK" to stringResource(R.string.theme_mode_dark)
    )
    val styleLabels = mapOf(
        "MINIMAL" to stringResource(R.string.style_minimal),
        "SOFT" to stringResource(R.string.style_soft)
    )
    val cornerLabels = mapOf(
        "SHARP" to stringResource(R.string.corner_sharp),
        "ROUNDED" to stringResource(R.string.corner_rounded),
        "PILL" to stringResource(R.string.corner_pill)
    )
    val fontLabels = mapOf(
        "SYSTEM" to stringResource(R.string.themes_font_system),
        "SERIF" to stringResource(R.string.themes_font_serif),
        "MONO" to stringResource(R.string.themes_font_mono)
    )
    val ringLabels = mapOf(
        "THIN" to stringResource(R.string.themes_ring_thin),
        "REGULAR" to stringResource(R.string.themes_ring_regular),
        "BOLD" to stringResource(R.string.themes_ring_bold)
    )

    // Two cards per row. Classic first, then the aesthetics.
    val rows = remember { (listOf(ThemePresets.CLASSIC) + ThemePresets.all.map { it.id }).chunked(2) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .appBackground()
            .systemBarsPadding()
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 28.dp)
        ) {
            item(key = "header") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back),
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Text(
                        text = stringResource(R.string.themes_title),
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
            }

            item(key = "preview") { PreviewCard() }

            item(key = "layout_label") { SectionLabel(stringResource(R.string.themes_layout)) }

            item(key = "layouts") {
                Column(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf(ThemeLayout.CLASSIC, ThemeLayout.NEUMORPHISM, ThemeLayout.GLASSMORPHISM).forEach { option ->
                            LayoutCard(
                                layout = option,
                                selected = option == layout,
                                isDark = isDark,
                                accent2 = presetAccent2,
                                onClick = { viewModel.setThemeLayout(option.name) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    if (layout != ThemeLayout.CLASSIC) {
                        Text(
                            text = stringResource(R.string.themes_layout_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 4.dp, top = 10.dp)
                        )
                    }
                }
            }

            item(key = "aesthetics_label") { SectionLabel(stringResource(R.string.themes_aesthetics)) }

            items(rows, key = { it.first() }) { pair ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    pair.forEach { id ->
                        PresetCard(
                            id = id,
                            selected = id == presetId,
                            isDark = isDark,
                            classicAccent = s.accentColor,
                            onClick = { viewModel.applyThemePreset(id) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            item(key = "colors") {
                ThemeGroup(stringResource(R.string.themes_colors)) {
                    ControlBlock(stringResource(R.string.settings_theme_mode)) {
                        PillSelector(
                            options = listOf("SYSTEM", "LIGHT", "DARK"),
                            selected = s.themeMode.uppercase(),
                            label = { modeLabels[it] ?: it },
                            onSelect = { viewModel.setThemeMode(it) }
                        )
                    }
                    RowDivider()
                    SettingSwitchRow(
                        title = stringResource(R.string.settings_amoled),
                        subtitle = stringResource(R.string.settings_amoled_desc),
                        checked = s.amoled,
                        onCheckedChange = { viewModel.setAmoled(it) }
                    )
                    RowDivider()
                    ControlBlock(stringResource(R.string.settings_accent)) {
                        AccentPicker(
                            selected = if (isClassic) s.accentColor else s.themeAccentCustom,
                            onSelect = { viewModel.setThemeAccent(it) },
                            presetAccent = if (isClassic) null else presetAccent
                        )
                    }
                    // Only the Classic layout uses these; the other two draw their own background.
                    if (layout == ThemeLayout.CLASSIC) {
                        RowDivider()
                        SettingSwitchRow(
                            title = stringResource(R.string.themes_gradient),
                            subtitle = stringResource(R.string.themes_gradient_desc),
                            checked = s.themeGradient,
                            onCheckedChange = { viewModel.setThemeGradient(it) }
                        )
                    }
                }
            }

            item(key = "shape") {
                ThemeGroup(stringResource(R.string.themes_shape)) {
                    if (layout == ThemeLayout.CLASSIC) {
                        ControlBlock(
                            title = stringResource(R.string.settings_style),
                            subtitle = stringResource(
                                if (s.themeStyle == "SOFT") R.string.settings_style_soft_desc else R.string.settings_style_minimal_desc
                            )
                        ) {
                            PillSelector(
                                options = listOf("MINIMAL", "SOFT"),
                                selected = s.themeStyle,
                                label = { styleLabels[it] ?: it },
                                onSelect = { viewModel.setThemeStyle(it) }
                            )
                        }
                        RowDivider()
                    }
                    ControlBlock(stringResource(R.string.settings_corners)) {
                        PillSelector(
                            options = listOf("SHARP", "ROUNDED", "PILL"),
                            selected = s.cornerStyle,
                            label = { cornerLabels[it] ?: it },
                            onSelect = { viewModel.setCornerStyle(it) }
                        )
                    }
                    RowDivider()
                    ControlBlock(
                        title = stringResource(R.string.themes_font),
                        subtitle = stringResource(R.string.themes_font_desc)
                    ) {
                        PillSelector(
                            options = listOf("SYSTEM", "SERIF", "MONO"),
                            selected = s.themeFont,
                            label = { fontLabels[it] ?: it },
                            onSelect = { viewModel.setThemeFont(it) }
                        )
                    }
                    RowDivider()
                    ControlBlock(stringResource(R.string.themes_ring)) {
                        PillSelector(
                            options = listOf("THIN", "REGULAR", "BOLD"),
                            selected = s.themeRing,
                            label = { ringLabels[it] ?: it },
                            onSelect = { viewModel.setThemeRing(it) }
                        )
                    }
                    RowDivider()
                    SettingNavRow(
                        title = stringResource(R.string.themes_reset),
                        subtitle = stringResource(R.string.themes_reset_desc),
                        showChevron = false,
                        onClick = { viewModel.applyThemePreset(presetId) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ThemeGroup(title: String, content: @Composable ColumnScope.() -> Unit) {
    // One Column per lazy item: an item with several top-level children would stack them on top of each other.
    Column(modifier = Modifier.fillMaxWidth()) {
        SectionLabel(title)
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            content = content
        )
    }
}

/** A live sample of the timer, drawn with the CURRENT theme, so every change is visible at once. */
@Composable
private fun PreviewCard() {
    val primary = MaterialTheme.colorScheme.primary
    Column(modifier = Modifier.fillMaxWidth()) {
        AppCard(modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ColorDot(color = primary, size = 12.dp)
                Spacer(Modifier.size(8.dp))
                Text(
                    text = stringResource(R.string.themes_preview_subject),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = stringResource(R.string.themes_preview),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(14.dp))
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressTimer(
                    progress = 0.64f,
                    primaryColor = primary,
                    modifier = Modifier.size(168.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "25:00",
                            style = timerDigitsStyle().copy(fontSize = 38.sp, lineHeight = 44.sp),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = stringResource(R.string.themes_preview_focus),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            // Drawn by hand instead of a Button, so the sample is not tappable and shows no ripple.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .clip(MaterialTheme.shapes.medium)
                    .background(primary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.themes_preview_start),
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = stringResource(R.string.themes_preview_today),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/** A small swatch of one aesthetic, drawn in ITS OWN colours (for the current light/dark mode). */
@Composable
private fun PresetCard(
    id: String,
    selected: Boolean,
    isDark: Boolean,
    classicAccent: Long,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = ThemePresets.find(id)?.palette(isDark)
    val bg = Color(palette?.bg ?: if (isDark) 0xFF0E0F13L else 0xFFF7F7F5L)
    val surface = Color(palette?.surface ?: if (isDark) 0xFF16181DL else 0xFFFFFFFFL)
    val text = Color(palette?.onSurface ?: if (isDark) 0xFFEDEEF1L else 0xFF111318L)
    val muted = Color(palette?.onVariant ?: if (isDark) 0xFF9AA0ABL else 0xFF6B7280L)
    val accent = Color(palette?.accent ?: classicAccent)
    val accent2 = Color(palette?.accent2 ?: classicAccent)
    val hairline = Color(palette?.hairline ?: if (isDark) 0xFF272A31L else 0xFFE5E5E0L)
    val shape = RoundedCornerShape(20.dp)
    val primary = MaterialTheme.colorScheme.primary

    Box(
        modifier = modifier
            .clip(shape)
            .background(bg)
            .border(width = if (selected) 2.dp else 1.dp, color = if (selected) primary else hairline, shape = shape)
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(surface)
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.55f)
                        .height(6.dp)
                        .clip(CircleShape)
                        .background(accent)
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                ColorDot(color = accent, size = 12.dp)
                ColorDot(color = accent2, size = 12.dp)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = presetName(id),
                style = MaterialTheme.typography.titleSmall,
                color = text,
                maxLines = 1
            )
            Text(
                text = presetVibe(id),
                style = MaterialTheme.typography.bodySmall,
                color = muted,
                maxLines = 2,
                minLines = 2
            )
        }
        if (selected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
private fun layoutName(layout: ThemeLayout): String = stringResource(
    when (layout) {
        ThemeLayout.CLASSIC -> R.string.layout_classic
        ThemeLayout.NEUMORPHISM -> R.string.layout_neu
        ThemeLayout.GLASSMORPHISM -> R.string.layout_glass
    }
)

@Composable
private fun layoutDesc(layout: ThemeLayout): String = stringResource(
    when (layout) {
        ThemeLayout.CLASSIC -> R.string.layout_classic_desc
        ThemeLayout.NEUMORPHISM -> R.string.layout_neu_desc
        ThemeLayout.GLASSMORPHISM -> R.string.layout_glass_desc
    }
)

/**
 * One layout choice with a small sample card drawn the way the real cards will be, in the CURRENT colours.
 * The sample reuses the same drawing code as the app, so what you see here is what you get.
 */
@Composable
private fun LayoutCard(
    layout: ThemeLayout,
    selected: Boolean,
    isDark: Boolean,
    accent2: Long?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val primary = scheme.primary
    val hairline = Ui.extra.hairline
    val outer = RoundedCornerShape(18.dp)
    val sampleShape = MaterialTheme.shapes.medium
    val colors = remember(layout, scheme, accent2, isDark) { buildLayoutColors(layout, scheme, accent2, isDark) }
    val backdrop = remember(layout, scheme, accent2, isDark) {
        if (layout == ThemeLayout.GLASSMORPHISM) buildGlassBackdrop(scheme, accent2, isDark) else null
    }

    Box(
        modifier = modifier
            .clip(outer)
            .then(if (backdrop != null) Modifier.background(backdrop) else Modifier.background(scheme.background))
            .border(width = if (selected) 2.dp else 1.dp, color = if (selected) primary else hairline, shape = outer)
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Spacer(Modifier.height(4.dp))
            // The sample card.
            val sample = Modifier.fillMaxWidth().height(34.dp)
            when {
                layout == ThemeLayout.NEUMORPHISM && colors != null -> Box(
                    modifier = sample
                        .neoShadows(sampleShape, colors)
                        .clip(sampleShape)
                        .background(colors.card)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) { SampleBar(primary) }
                layout == ThemeLayout.GLASSMORPHISM && colors != null -> Box(
                    modifier = sample
                        .clip(sampleShape)
                        .background(colors.card)
                        .glassSheen(colors.sheen)
                        .border(1.dp, colors.glassBorder, sampleShape)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) { SampleBar(primary) }
                else -> Box(
                    modifier = sample
                        .clip(sampleShape)
                        .background(scheme.surface)
                        .border(1.dp, hairline, sampleShape)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) { SampleBar(primary) }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = layoutName(layout),
                style = MaterialTheme.typography.titleSmall,
                color = scheme.onBackground,
                maxLines = 1
            )
            Text(
                text = layoutDesc(layout),
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                maxLines = 3,
                minLines = 3
            )
        }
        if (selected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = null,
                    tint = scheme.onPrimary,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    }
}

@Composable
private fun SampleBar(color: Color) {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.55f)
            .height(6.dp)
            .clip(CircleShape)
            .background(color)
    )
}
