package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.StudyTask
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyTaskDao {
    @Query("SELECT * FROM study_tasks WHERE date = :date ORDER BY `order` ASC, id ASC")
    fun getTasksForDateFlow(date: String): Flow<List<StudyTask>>

    @Query("SELECT * FROM study_tasks WHERE date = :date ORDER BY `order` ASC, id ASC")
    suspend fun getTasksForDate(date: String): List<StudyTask>

    @Query("SELECT * FROM study_tasks ORDER BY date DESC, `order` ASC")
    fun getAllTasksFlow(): Flow<List<StudyTask>>

    @Query("SELECT * FROM study_tasks ORDER BY date DESC, `order` ASC")
    suspend fun getAllTasksList(): List<StudyTask>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: StudyTask): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tasks: List<StudyTask>)

    @Update
    suspend fun update(task: StudyTask)

    @Query("UPDATE study_tasks SET subjectId = NULL WHERE subjectId = :subjectId")
    suspend fun unlinkSubject(subjectId: Long)

    @Delete
    suspend fun delete(task: StudyTask)

    @Query("DELETE FROM study_tasks WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM study_tasks")
    suspend fun deleteAll()
}
