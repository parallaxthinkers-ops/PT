package com.example.ui.theme

import kotlin.math.roundToInt

/**
 * The colour rules of the Neumorphism and Glassmorphism layouts, on ARGB Longs (0xAARRGGBB). No Android or
 * Compose classes, so the unit tests check the SAME numbers the app draws with.
 *
 * Both layouts are "faked" on purpose, with no blur: neumorphism is two pairs of offset shapes, glass is a
 * see-through card over a static gradient. Nothing here animates.
 */
object LayoutMath {
    /** How opaque a glass card is. Tuned so text keeps at least 4.5 contrast over the strongest backdrop tint of every aesthetic (4.4 for the most extreme single accent colours). */
    const val GLASS_ALPHA = 0.82f

    /**
     * How opaque a pop-up (dialog or picker) is. The same 82% as a glass card, so the two look related. Checked against every
     * aesthetic: main text keeps at least 6.5 contrast even over the worst possible backdrop (pure white behind a dark pop-up).
     * There is no blur, so below about 70% the page behind starts to fight with the text.
     */
    const val DIALOG_ALPHA = 0.82f

    /** What a pop-up really looks like: its colour laid over whatever part of the page is behind it. */
    fun dialogComposite(backdrop: Long, container: Long): Long = mix(backdrop, container, DIALOG_ALPHA)

    /** How much of the accent colours the glass backdrop shows at its two corners. */
    const val GLASS_TINT_LIGHT = 0.20f
    const val GLASS_TINT_DARK = 0.28f

    private const val BLACK = 0xFF000000L

    /** [a] towards [b] by [t] (0 = a, 1 = b). The result is opaque. */
    fun mix(a: Long, b: Long, t: Float): Long {
        var out = 0xFF000000L
        for (shift in intArrayOf(16, 8, 0)) {
            val x = ((a shr shift) and 0xFFL).toFloat()
            val y = ((b shr shift) and 0xFFL).toFloat()
            out = out or ((x + (y - x) * t).roundToInt().coerceIn(0, 255).toLong() shl shift)
        }
        return out
    }

    /** The three colours of the glass backdrop, top-left to bottom-right: accent tint, plain background, second tint. */
    fun glassStops(bg: Long, accent: Long, accent2: Long, dark: Boolean): LongArray {
        val t = if (dark) GLASS_TINT_DARK else GLASS_TINT_LIGHT
        return longArrayOf(mix(bg, accent, t), bg, mix(bg, accent2, t))
    }

    /** What a glass card really looks like: the surface laid over whatever part of the backdrop is behind it. */
    fun glassComposite(backdrop: Long, surface: Long): Long = mix(backdrop, surface, GLASS_ALPHA)

    /** The raised edge on the light side of a neumorphic card. */
    fun neoLight(bg: Long, dark: Boolean): Long = mix(bg, 0xFFFFFFFFL, if (dark) 0.07f else 0.75f)

    /** The shaded edge on the far side of a neumorphic card. */
    fun neoDark(bg: Long, dark: Boolean): Long = mix(bg, BLACK, if (dark) 0.55f else 0.17f)

    /** A fainter copy of an edge colour, for the outer step that fakes the soft falloff. */
    fun far(bg: Long, edge: Long): Long = mix(bg, edge, 0.5f)
}
