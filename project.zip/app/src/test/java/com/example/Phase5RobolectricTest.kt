package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.backup.BackupManager
import com.example.data.backup.BackupSummary
import com.example.data.model.DDay
import com.example.data.model.Goal
import com.example.data.model.StudySession
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.TaskCompletion
import com.example.data.repository.SettingsRepository
import com.example.data.repository.StudyRepository
import com.example.service.TimerState
import com.example.service.TimerStateManager
import com.example.service.TimerStatus
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Phase5RobolectricTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase
    private lateinit var studyRepo: StudyRepository
    private lateinit var settingsRepo: SettingsRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        studyRepo = StudyRepository(db)
        settingsRepo = SettingsRepository(context)
    }

    @After
    fun tearDown() {
        db.close()
        TimerStateManager.setState(TimerState())
    }

    @Test
    fun testBackupJsonRoundTrip() {
        runBlocking {
            // 1. Prepare initial data
            val sub1 = Subject(id = 10, name = "Physics", color = 0xFF3B82F6L, icon = "science", order = 0)
            val sub2 = Subject(id = 20, name = "History", color = 0xFFEF4444L, icon = "book", order = 1, isArchived = true)
            val subjDao = db.subjectDao()
            subjDao.insertAll(listOf(sub1, sub2))

            val sess1 = StudySession(id = 100, subjectId = 10, startTime = 1000000L, endTime = 1003600L, mode = "STOPWATCH", interruptions = 1)
            val sess2 = StudySession(id = 200, subjectId = 20, startTime = 2000000L, endTime = 2001800L, mode = "POMODORO", interruptions = 0)
            db.studySessionDao().insertAll(listOf(sess1, sess2))

            val goal1 = Goal(weekday = 2, targetMinutes = 180)
            db.goalDao().insertOrUpdate(goal1)

            val dday1 = DDay(id = 50, title = "Midterms", targetDate = 1700000000L, countUp = false, color = 0xFF10B981L, isPinned = true)
            db.dDayDao().insert(dday1)

            val task1 = StudyTask(id = 80, title = "Read Chapter 4", subjectId = 10, plannedMinutes = 45, date = "2026-10-13", isDone = false)
            db.studyTaskDao().insert(task1)

            val comp1 = TaskCompletion(taskId = 80, date = "2026-10-13")
            db.taskCompletionDao().insertAll(listOf(comp1))

            settingsRepo.setDayStartHour(6)
            settingsRepo.setThemeStyle("SOFT")
            settingsRepo.setThemeMode("DARK")

            // 2. Export to a temporary file via SAF URI simulation
            val tempFile = File(context.cacheDir, "test_backup.json")
            val uri = android.net.Uri.fromFile(tempFile)
            val exportResult = BackupManager.exportToJson(context, uri, studyRepo, settingsRepo)
            assertTrue("Export should succeed", exportResult.isSuccess)
            assertTrue("File should exist", tempFile.exists())

            // 3. Clear database to verify restore
            studyRepo.clearAllData()
            assertEquals(0, subjDao.getAllSubjectsList().size)
            assertEquals(0, db.studySessionDao().getAllSessionsList().size)

            // 4. Validate and Restore
            val validateResult = BackupManager.parseAndValidateBackup(context, uri)
            assertTrue("Validate should succeed", validateResult.isSuccess)
            val summary = validateResult.getOrThrow()
            assertEquals(2, summary.subjectsCount)
            assertEquals(2, summary.sessionsCount)
            assertEquals(1, summary.goalsCount)
            assertEquals(1, summary.dDaysCount)
            assertEquals(1, summary.tasksCount)
            assertEquals(1, summary.taskCompletionsCount)

            val restoreResult = BackupManager.restoreFromValidatedSummary(context, summary, studyRepo, settingsRepo)
            assertTrue("Restore should succeed", restoreResult.isSuccess)

            // 5. Assert identical data
            val restoredSubjects = subjDao.getAllSubjectsList()
            assertEquals(2, restoredSubjects.size)
            val restoredSub1 = restoredSubjects.first { it.id == 10L }
            assertEquals("Physics", restoredSub1.name)
            assertFalse(restoredSub1.isArchived)
            val restoredSub2 = restoredSubjects.first { it.id == 20L }
            assertEquals("History", restoredSub2.name)
            assertTrue(restoredSub2.isArchived)

            val restoredSessions = db.studySessionDao().getAllSessionsList()
            assertEquals(2, restoredSessions.size)
            val restoredSess1 = restoredSessions.first { it.id == 100L }
            assertEquals(10L, restoredSess1.subjectId)
            assertEquals(1000000L, restoredSess1.startTime)
            assertEquals(1003600L, restoredSess1.endTime)
            assertEquals(1, restoredSess1.interruptions)

            val restoredGoals = db.goalDao().getAllGoalsList()
            assertEquals(1, restoredGoals.size)
            assertEquals(180, restoredGoals.first().targetMinutes)

            val restoredDDays = db.dDayDao().getAllDDaysList()
            assertEquals(1, restoredDDays.size)
            assertEquals("Midterms", restoredDDays.first().title)

            val restoredTasks = db.studyTaskDao().getAllTasksList()
            assertEquals(1, restoredTasks.size)
            assertEquals("Read Chapter 4", restoredTasks.first().title)

            assertEquals("SOFT", settingsRepo.themeStyleFlow.first())
            assertEquals(6, settingsRepo.dayStartHourFlow.first())

            tempFile.delete()
        }
    }

    @Test
    fun testInvalidFileRejection() = runBlocking {
        // Missing schemaVersion
        val invalidJson1 = JSONObject().apply {
            put("subjects", org.json.JSONArray())
        }
        val file1 = File(context.cacheDir, "invalid1.json")
        file1.writeText(invalidJson1.toString())
        val res1 = BackupManager.parseAndValidateBackup(context, android.net.Uri.fromFile(file1))
        assertTrue("Should reject missing schemaVersion", res1.isFailure)

        // Newer unsupported schemaVersion
        val invalidJson2 = JSONObject().apply {
            put("schemaVersion", 999)
            put("subjects", org.json.JSONArray())
        }
        val file2 = File(context.cacheDir, "invalid2.json")
        file2.writeText(invalidJson2.toString())
        val res2 = BackupManager.parseAndValidateBackup(context, android.net.Uri.fromFile(file2))
        assertTrue("Should reject future schemaVersion", res2.isFailure)

        // Corrupted JSON syntax
        val file3 = File(context.cacheDir, "invalid3.json")
        file3.writeText("{ corrupted json content [}")
        val res3 = BackupManager.parseAndValidateBackup(context, android.net.Uri.fromFile(file3))
        assertTrue("Should reject malformed JSON", res3.isFailure)

        file1.delete()
        file2.delete()
        file3.delete()
        Unit // runBlocking returns its last expression and JUnit needs a void test
    }

    @Test
    fun testLegacyThemeStylesAreMigrated() = runBlocking {
        settingsRepo.setThemeStyle("NEUMORPHISM")
        assertEquals("SOFT", settingsRepo.themeStyleFlow.first())
        settingsRepo.setThemeStyle("MATERIAL")
        assertEquals("MINIMAL", settingsRepo.themeStyleFlow.first())
        settingsRepo.setThemeStyle("garbage")
        assertEquals("MINIMAL", settingsRepo.themeStyleFlow.first())
    }

    @Test
    fun testRollbackOnFailureKeepsExistingData() {
        runBlocking {
            // Setup initial subject
            studyRepo.insertSubject(Subject(id = 1, name = "Biology", color = 0xFF10B981L))
            studyRepo.insertSession(StudySession(id = 1, subjectId = 1, startTime = 5000L, endTime = 6000L))
            assertEquals(1, db.subjectDao().getAllSubjectsList().size)
            assertEquals(1, db.studySessionDao().getAllSessionsList().size)

            // Attempt a malformed restore payload that causes an error inside transaction
            val malformedSummary = BackupSummary(
                schemaVersion = 1,
                appVersion = "1.0.0",
                exportTime = System.currentTimeMillis(),
                subjectsCount = 1,
                sessionsCount = 1,
                goalsCount = 0,
                dDaysCount = 0,
                tasksCount = 0,
                taskCompletionsCount = 0,
                rawJson = "{\"schemaVersion\": 1, \"subjects\": [\"invalid_not_an_object\"]}"
            )

            val result = BackupManager.restoreFromValidatedSummary(context, malformedSummary, studyRepo, settingsRepo)
            assertTrue("Restore should fail on malformed JSON elements", result.isFailure)

            // Existing data must be preserved due to transaction rollback
            val remainingSubjects = db.subjectDao().getAllSubjectsList()
            val remainingSessions = db.studySessionDao().getAllSessionsList()
            assertEquals("Existing subject must remain", 1, remainingSubjects.size)
            assertEquals("Biology", remainingSubjects.first().name)
            assertEquals("Existing session must remain", 1, remainingSessions.size)
        }
    }

    @Test
    fun testDayStartTimeChangesDoNotAlterStoredData() {
        runBlocking {
            val startTimestamp = 1728800000000L
            val endTimestamp = 1728803600000L
            val subId = studyRepo.insertSubject(Subject(name = "General", color = 0xFF3B82F6L))
            val sessionId = studyRepo.insertSession(
                StudySession(
                    subjectId = subId,
                    startTime = startTimestamp,
                    endTime = endTimestamp
                )
            )

            settingsRepo.setDayStartHour(5)
            var session = db.studySessionDao().getAllSessionsList().first { it.id == sessionId }
            assertEquals(startTimestamp, session.startTime)
            assertEquals(endTimestamp, session.endTime)

            settingsRepo.setDayStartHour(8)
            session = db.studySessionDao().getAllSessionsList().first { it.id == sessionId }
            assertEquals("Start time must not change", startTimestamp, session.startTime)
            assertEquals("End time must not change", endTimestamp, session.endTime)

            settingsRepo.setDayStartHour(0)
            session = db.studySessionDao().getAllSessionsList().first { it.id == sessionId }
            assertEquals(startTimestamp, session.startTime)
            assertEquals(endTimestamp, session.endTime)
        }
    }

    @Test
    fun testArchiveKeepsSessions() {
        runBlocking {
            val subjectId = studyRepo.insertSubject(Subject(name = "Chemistry", color = 0xFF3B82F6L))
            studyRepo.insertSession(StudySession(subjectId = subjectId, startTime = 1000L, endTime = 2000L))
            studyRepo.insertSession(StudySession(subjectId = subjectId, startTime = 3000L, endTime = 4000L))

            // Archive subject
            studyRepo.deleteSubject(Subject(id = subjectId, name = "Chemistry", color = 0xFF3B82F6L), deleteHistory = false)
            val subject = studyRepo.getSubjectById(subjectId)
            assertNotNull(subject)
            assertTrue("Subject must be marked archived", subject!!.isArchived)

            // Active subjects flow does NOT include archived subject
            val active = studyRepo.activeSubjects.first()
            assertFalse(active.any { it.id == subjectId })

            // But sessions are kept!
            val sessions = studyRepo.getSessionsForSubjectInRange(subjectId, 0L, 10000L).first()
            assertEquals(2, sessions.size)
        }
    }

    @Test
    fun testHardDeleteRemovesSessionsAndUnlinksTasks() {
        runBlocking {
            val subjectId = studyRepo.insertSubject(Subject(name = "Literature", color = 0xFFF59E0BL))
            studyRepo.insertSession(StudySession(subjectId = subjectId, startTime = 1000L, endTime = 2000L))
            val taskId = studyRepo.insertTask(
                StudyTask(title = "Read Hamlet", subjectId = subjectId, date = "2026-10-13")
            )

            // Permanently delete subject and its history
            studyRepo.deleteSubject(Subject(id = subjectId, name = "Literature", color = 0xFFF59E0BL), deleteHistory = true)

            // Subject should be gone
            assertNull(studyRepo.getSubjectById(subjectId))

            // Sessions should be gone
            val sessions = db.studySessionDao().getAllSessionsList().filter { it.subjectId == subjectId }
            assertTrue("Sessions must be removed", sessions.isEmpty())

            // Task still exists but unlinked (subjectId = null)
            val task = db.studyTaskDao().getAllTasksList().firstOrNull { it.id == taskId }
            assertNotNull("Task must stay", task)
            assertNull("Task subjectId must be null (unlinked)", task!!.subjectId)
        }
    }

    @Test
    fun testCannotDeleteWhileRunning() {
        val subjectId = 99L
        TimerStateManager.setState(
            TimerState(
                status = TimerStatus.RUNNING,
                subjectId = subjectId,
                subjectName = "Active Running Subject"
            )
        )

        val isTimerActiveWithSubject = (TimerStateManager.timerState.value.status != TimerStatus.STOPPED) &&
                (TimerStateManager.timerState.value.subjectId == subjectId)
        assertTrue("Should detect timer is running with this subject", isTimerActiveWithSubject)

        // Paused state
        TimerStateManager.setState(
            TimerState(
                status = TimerStatus.PAUSED,
                subjectId = subjectId,
                subjectName = "Active Paused Subject"
            )
        )

        val isTimerPausedWithSubject = (TimerStateManager.timerState.value.status != TimerStatus.STOPPED) &&
                (TimerStateManager.timerState.value.subjectId == subjectId)
        assertTrue("Should detect timer is paused with this subject", isTimerPausedWithSubject)

        // Stopped state allows deletion
        TimerStateManager.setState(TimerState(status = TimerStatus.STOPPED, subjectId = subjectId))
        val isTimerStopped = (TimerStateManager.timerState.value.status != TimerStatus.STOPPED) &&
                (TimerStateManager.timerState.value.subjectId == subjectId)
        assertFalse("Stopped timer allows deletion", isTimerStopped)
    }

    @Test
    fun testSelectionFallbackWhenSubjectDeleted() {
        runBlocking {
            val s1 = studyRepo.insertSubject(Subject(name = "Sub1", color = 0xFF111111L))
            val s2 = studyRepo.insertSubject(Subject(name = "Sub2", color = 0xFF222222L))

            var selectedSubjectId = s1
            settingsRepo.setSelectedSubjectId(selectedSubjectId)

            // Delete s1
            studyRepo.deleteSubject(Subject(id = s1, name = "Sub1", color = 0xFF111111L), deleteHistory = true)

            // Fallback calculation: if selected subject no longer in active subjects, pick first active
            val active = studyRepo.activeSubjects.first()
            val newSelection = if (active.none { it.id == selectedSubjectId }) {
                active.firstOrNull()?.id ?: 0L
            } else {
                selectedSubjectId
            }
            assertEquals("Fallback must select the remaining subject s2", s2, newSelection)

            // Delete s2 as well
            studyRepo.deleteSubject(Subject(id = s2, name = "Sub2", color = 0xFF222222L), deleteHistory = true)
            val remainingActive = studyRepo.activeSubjects.first()
            val emptySelection = remainingActive.firstOrNull()?.id ?: 0L
            assertEquals("If no subjects remain, selection is 0L / empty", 0L, emptySelection)
        }
    }
}
