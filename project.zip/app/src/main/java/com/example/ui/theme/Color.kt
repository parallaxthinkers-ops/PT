package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand colours taken from the Parallax Tracker logo.
val LogoElectricBlue = Color(0xFF00E5FF)
val LogoViolet = Color(0xFF7C3AED)
val LogoOrange = Color(0xFFFF6B00)

// Semantic colours that do not change with the accent.
val SuccessGreen = Color(0xFF16A34A)
val WarningAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFDC2626)

val AccentEmerald = Color(0xFF10B981)
val AccentOrange = Color(0xFFF97316)

/** Accent colours the user can pick in Settings. The first one is the default. */
val ThemeAccentColors = listOf(
    0xFF3B6EF6L, // Blue (default)
    0xFF7C3AEDL, // Violet (logo)
    0xFF00B8D4L, // Cyan (logo, slightly deeper so it stays readable on white)
    0xFFFF6B00L, // Orange (logo)
    0xFF10B981L, // Emerald
    0xFFF59E0BL, // Amber
    0xFFF43F5EL, // Rose
    0xFFEC4899L, // Pink
    0xFF14B8A6L, // Teal
    0xFF64748BL  // Slate
)

/** Colours offered when creating a subject. */
val SubjectColors = listOf(
    0xFF3B82F6L, // Blue
    0xFF10B981L, // Emerald
    0xFFF59E0BL, // Amber
    0xFF8B5CF6L, // Violet
    0xFFEC4899L, // Pink
    0xFF06B6D4L, // Cyan
    0xFFEF4444L, // Red
    0xFF14B8A6L, // Teal
    0xFFF97316L, // Orange
    0xFF6366F1L, // Indigo
    0xFF84CC16L, // Lime
    0xFF64748BL  // Slate
)
