package com.example.ui.theme

import com.example.data.repository.CornerStyleNames
import com.example.data.repository.ThemeFontNames
import com.example.data.repository.ThemeStyleNames

/**
 * One colour set (light or dark) of an aesthetic. Colours are ARGB Longs, so this file has no Android or
 * Compose dependency and the contrast rules can be unit tested on the JVM.
 *
 * bg = screen, surface = cards, variant = chips and tracks, onSurface = main text, onVariant = secondary text,
 * accent = buttons and the timer ring, accent2 = the second colour of the aesthetic (gradient, highlights).
 */
class ThemePalette(
    val bg: Long,
    val surface: Long,
    val variant: Long,
    val onSurface: Long,
    val onVariant: Long,
    val accent: Long,
    val accent2: Long,
    val hairline: Long
)

/**
 * A ready-made aesthetic: both palettes plus the look that goes with it (card style, corners, font, gradient).
 * Picking one applies all of it at once. The person can then change any single part.
 */
class ThemePreset(
    val id: String,
    val cardStyle: String,
    val corner: String,
    val font: String,
    val gradient: Boolean,
    val light: ThemePalette,
    val dark: ThemePalette
) {
    fun palette(isDark: Boolean): ThemePalette = if (isDark) dark else light
}

object ThemePresets {
    /** The original look: neutral, with the accent colour chosen by the person. It has no palette of its own. */
    const val CLASSIC = "CLASSIC"

    /** The look "Classic" resets to. */
    const val CLASSIC_CARD_STYLE = ThemeStyleNames.MINIMAL
    const val CLASSIC_CORNER = CornerStyleNames.ROUNDED
    const val CLASSIC_FONT = ThemeFontNames.SYSTEM

    val all: List<ThemePreset> = listOf(
        ThemePreset(
            id = "SAKURA",
            cardStyle = ThemeStyleNames.SOFT,
            corner = CornerStyleNames.PILL,
            font = ThemeFontNames.SYSTEM,
            gradient = true,
            light = ThemePalette(bg = 0xFFFFF6F9L, surface = 0xFFFFFFFFL, variant = 0xFFFDE8EFL, onSurface = 0xFF3B2330L, onVariant = 0xFF85596EL, accent = 0xFFD6336CL, accent2 = 0xFFF59BB6L, hairline = 0xFFF3D6E0L),
            dark = ThemePalette(bg = 0xFF1D1318L, surface = 0xFF281A21L, variant = 0xFF36232CL, onSurface = 0xFFF9E9F0L, onVariant = 0xFFC9A3B4L, accent = 0xFFF48FB1L, accent2 = 0xFFB8688AL, hairline = 0xFF3E2A33L)
        ),
        ThemePreset(
            id = "COTTON",
            cardStyle = ThemeStyleNames.SOFT,
            corner = CornerStyleNames.PILL,
            font = ThemeFontNames.SYSTEM,
            gradient = true,
            light = ThemePalette(bg = 0xFFF2F8FFL, surface = 0xFFFFFFFFL, variant = 0xFFE3EEFBL, onSurface = 0xFF1B2A46L, onVariant = 0xFF55698CL, accent = 0xFFD9488CL, accent2 = 0xFF6CA9F5L, hairline = 0xFFD6E4F6L),
            dark = ThemePalette(bg = 0xFF0F1626L, surface = 0xFF18213AL, variant = 0xFF222E4DL, onSurface = 0xFFE8F0FFL, onVariant = 0xFFA3B5D6L, accent = 0xFFFF8FC0L, accent2 = 0xFF7FB2FFL, hairline = 0xFF2A3759L)
        ),
        ThemePreset(
            id = "MATCHA",
            cardStyle = ThemeStyleNames.SOFT,
            corner = CornerStyleNames.ROUNDED,
            font = ThemeFontNames.SYSTEM,
            gradient = true,
            light = ThemePalette(bg = 0xFFF1F5EAL, surface = 0xFFFBFDF7L, variant = 0xFFE1EAD3L, onSurface = 0xFF24321DL, onVariant = 0xFF5B6B50L, accent = 0xFF4F7A35L, accent2 = 0xFFA8C686L, hairline = 0xFFD3DDC4L),
            dark = ThemePalette(bg = 0xFF11160EL, surface = 0xFF192015L, variant = 0xFF232C1EL, onSurface = 0xFFE7EEDDL, onVariant = 0xFFA5B598L, accent = 0xFF9CCB78L, accent2 = 0xFF5F8A47L, hairline = 0xFF2B3525L)
        ),
        ThemePreset(
            id = "LATTE",
            cardStyle = ThemeStyleNames.SOFT,
            corner = CornerStyleNames.ROUNDED,
            font = ThemeFontNames.SYSTEM,
            gradient = true,
            light = ThemePalette(bg = 0xFFF5EDE2L, surface = 0xFFFBF6EEL, variant = 0xFFEADDCBL, onSurface = 0xFF3A291DL, onVariant = 0xFF7B6552L, accent = 0xFFA55F2EL, accent2 = 0xFFD9A877L, hairline = 0xFFDCCDB7L),
            dark = ThemePalette(bg = 0xFF16100CL, surface = 0xFF211913L, variant = 0xFF2E241CL, onSurface = 0xFFF0E4D6L, onVariant = 0xFFB7A28EL, accent = 0xFFE0A06AL, accent2 = 0xFF9A6A43L, hairline = 0xFF3A2E24L)
        ),
        ThemePreset(
            id = "ACADEMIA",
            cardStyle = ThemeStyleNames.MINIMAL,
            corner = CornerStyleNames.SHARP,
            font = ThemeFontNames.SERIF,
            gradient = false,
            light = ThemePalette(bg = 0xFFEEE5D3L, surface = 0xFFF7F0E2L, variant = 0xFFE2D6BFL, onSurface = 0xFF2A2118L, onVariant = 0xFF6E5F4CL, accent = 0xFF7A2E2EL, accent2 = 0xFFB08D57L, hairline = 0xFFD3C5ABL),
            dark = ThemePalette(bg = 0xFF13100EL, surface = 0xFF1C1714L, variant = 0xFF2A221DL, onSurface = 0xFFEADFCFL, onVariant = 0xFFA39482L, accent = 0xFFC9A25FL, accent2 = 0xFF8E3B3BL, hairline = 0xFF342B24L)
        ),
        ThemePreset(
            id = "NEON",
            cardStyle = ThemeStyleNames.SOFT,
            corner = CornerStyleNames.ROUNDED,
            font = ThemeFontNames.SYSTEM,
            gradient = true,
            light = ThemePalette(bg = 0xFFF3F0FFL, surface = 0xFFFFFFFFL, variant = 0xFFE6E0FBL, onSurface = 0xFF1C1736L, onVariant = 0xFF5F5890L, accent = 0xFF6D28D9L, accent2 = 0xFF06B6D4L, hairline = 0xFFD8D0F4L),
            dark = ThemePalette(bg = 0xFF090818L, surface = 0xFF12102AL, variant = 0xFF1C1940L, onSurface = 0xFFECEAFFL, onVariant = 0xFFA29FD0L, accent = 0xFFB388FFL, accent2 = 0xFF22D3EEL, hairline = 0xFF2A2658L)
        ),
        ThemePreset(
            id = "OCEAN",
            cardStyle = ThemeStyleNames.MINIMAL,
            corner = CornerStyleNames.ROUNDED,
            font = ThemeFontNames.SYSTEM,
            gradient = true,
            light = ThemePalette(bg = 0xFFECF6F8L, surface = 0xFFFFFFFFL, variant = 0xFFD9EBF0L, onSurface = 0xFF0E2830L, onVariant = 0xFF4C6B75L, accent = 0xFF0A7F99L, accent2 = 0xFF5CC4D6L, hairline = 0xFFC9E1E8L),
            dark = ThemePalette(bg = 0xFF08171CL, surface = 0xFF0F252CL, variant = 0xFF173440L, onSurface = 0xFFE3F4F8L, onVariant = 0xFF9DBCC6L, accent = 0xFF4FC3DCL, accent2 = 0xFF2B8FA6L, hairline = 0xFF1F3F4AL)
        ),
        ThemePreset(
            id = "SUNSET",
            cardStyle = ThemeStyleNames.SOFT,
            corner = CornerStyleNames.PILL,
            font = ThemeFontNames.SYSTEM,
            gradient = true,
            light = ThemePalette(bg = 0xFFFFF2EAL, surface = 0xFFFFFFFFL, variant = 0xFFFCE3D6L, onSurface = 0xFF3A2030L, onVariant = 0xFF805A66L, accent = 0xFFE4572EL, accent2 = 0xFF9B6BDFL, hairline = 0xFFF2D5C6L),
            dark = ThemePalette(bg = 0xFF1B1117L, surface = 0xFF261822L, variant = 0xFF33212DL, onSurface = 0xFFFDEDE6L, onVariant = 0xFFC9A5A9L, accent = 0xFFFF8A65L, accent2 = 0xFFB48CF0L, hairline = 0xFF40303AL)
        ),
        ThemePreset(
            id = "LAVENDER",
            cardStyle = ThemeStyleNames.SOFT,
            corner = CornerStyleNames.PILL,
            font = ThemeFontNames.SYSTEM,
            gradient = true,
            light = ThemePalette(bg = 0xFFF5F2FFL, surface = 0xFFFFFFFFL, variant = 0xFFE9E3FBL, onSurface = 0xFF241D3BL, onVariant = 0xFF625A87L, accent = 0xFF7B5CD6L, accent2 = 0xFFC3B3F5L, hairline = 0xFFDDD5F3L),
            dark = ThemePalette(bg = 0xFF14101FL, surface = 0xFF1D1830L, variant = 0xFF29223FL, onSurface = 0xFFEFEAFFL, onVariant = 0xFFAAA1CEL, accent = 0xFFB7A1FFL, accent2 = 0xFF7B5CD6L, hairline = 0xFF342C4DL)
        ),
        ThemePreset(
            id = "INK",
            cardStyle = ThemeStyleNames.MINIMAL,
            corner = CornerStyleNames.SHARP,
            font = ThemeFontNames.MONO,
            gradient = false,
            light = ThemePalette(bg = 0xFFF7F7F4L, surface = 0xFFFFFFFFL, variant = 0xFFECECE8L, onSurface = 0xFF111111L, onVariant = 0xFF5E5E5AL, accent = 0xFF111111L, accent2 = 0xFF8A8A85L, hairline = 0xFFDDDDD8L),
            dark = ThemePalette(bg = 0xFF0B0B0BL, surface = 0xFF141414L, variant = 0xFF1F1F1FL, onSurface = 0xFFF2F2F2L, onVariant = 0xFFA0A0A0L, accent = 0xFFF2F2F2L, accent2 = 0xFF8A8A8AL, hairline = 0xFF2A2A2AL)
        ),
        ThemePreset(
            id = "MINT",
            cardStyle = ThemeStyleNames.SOFT,
            corner = CornerStyleNames.ROUNDED,
            font = ThemeFontNames.SYSTEM,
            gradient = true,
            light = ThemePalette(bg = 0xFFEAFAF3L, surface = 0xFFFFFFFFL, variant = 0xFFD5F2E5L, onSurface = 0xFF0F2B22L, onVariant = 0xFF477164L, accent = 0xFF0E9F6EL, accent2 = 0xFF6EE7B7L, hairline = 0xFFC4E8D8L),
            dark = ThemePalette(bg = 0xFF0A1713L, surface = 0xFF11231DL, variant = 0xFF1A332AL, onSurface = 0xFFE2F7EEL, onVariant = 0xFF9CC0B2L, accent = 0xFF34D399L, accent2 = 0xFF10B981L, hairline = 0xFF21402FL)
        )
    )

    fun find(id: String?): ThemePreset? = all.firstOrNull { it.id == id }

    /** Unknown or missing ids (old installs, a hand-edited backup) become Classic. */
    fun normalize(id: String?): String = find(id)?.id ?: CLASSIC
}
