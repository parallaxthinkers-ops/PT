package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DDay
import kotlinx.coroutines.flow.Flow

@Dao
interface DDayDao {
    @Query("SELECT * FROM ddays ORDER BY isPinned DESC, targetDate ASC")
    fun getAllDDaysFlow(): Flow<List<DDay>>

    @Query("SELECT * FROM ddays ORDER BY isPinned DESC, targetDate ASC")
    suspend fun getAllDDaysList(): List<DDay>

    @Query("SELECT * FROM ddays WHERE isPinned = 1 LIMIT 1")
    fun getPinnedDDayFlow(): Flow<DDay?>

    @Query("SELECT * FROM ddays WHERE isPinned = 1 LIMIT 1")
    suspend fun getPinnedDDay(): DDay?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(dDay: DDay): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(dDays: List<DDay>)

    @Update
    suspend fun update(dDay: DDay)

    @Delete
    suspend fun delete(dDay: DDay)

    @Query("DELETE FROM ddays WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE ddays SET isPinned = 0")
    suspend fun unpinAll()

    @Query("UPDATE ddays SET isPinned = 1 WHERE id = :id")
    suspend fun pinDDay(id: Long)

    @Query("DELETE FROM ddays")
    suspend fun deleteAll()
}
