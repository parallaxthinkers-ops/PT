package com.example

import com.example.data.backup.AutoBackupPlan
import com.example.data.model.StudySession
import com.example.ui.screens.stats.StatsEngine
import com.example.ui.screens.stats.StatsTab
import com.example.ui.screens.timeline.SessionWithSubject
import com.example.ui.screens.timeline.TimelineViewModel
import com.example.util.DateTimeUtils
import com.example.util.StudyMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/** Plain JVM tests for the pure logic: no Android classes are needed, so they run fast. */
class PureLogicTest {

    private fun block(id: Long, startMin: Long, endMin: Long): SessionWithSubject {
        val start = startMin * 60_000L
        val end = endMin * 60_000L
        return SessionWithSubject(
            session = StudySession(id = id, subjectId = 1, startTime = start, endTime = end),
            subject = null,
            effectiveStartMs = start,
            effectiveEndMs = end,
            effectiveDurationSeconds = (end - start) / 1000L
        )
    }

    private fun millis(date: LocalDate, hour: Int, minute: Int = 0): Long =
        LocalDateTime.of(date, java.time.LocalTime.of(hour, minute)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    // ---- Timeline layout (the "short subjects do not show" fix) -------------------------------

    @Test
    fun shortSessionsCloseTogetherGetSeparateColumns() {
        // Two 3-minute sessions 10 minutes apart. Drawn at the 15-minute minimum height they would
        // overlap, so they must not share a column (before the fix one of them was hidden).
        val a = block(1, 0, 3)
        val b = block(2, 10, 13)
        val layouts = TimelineViewModel.computeTimelineLayouts(listOf(a, b), minDurationMs = 15 * 60_000L)
        assertEquals(2, layouts.size)
        assertEquals(setOf(0, 1), layouts.map { it.colIndex }.toSet())
        assertTrue(layouts.all { it.totalCols == 2 })
    }

    @Test
    fun shortSessionsFarApartShareOneColumn() {
        val layouts = TimelineViewModel.computeTimelineLayouts(
            listOf(block(1, 0, 3), block(2, 60, 63)),
            minDurationMs = 15 * 60_000L
        )
        assertTrue(layouts.all { it.colIndex == 0 && it.totalCols == 1 })
    }

    @Test
    fun backToBackSessionsDoNotOverlap() {
        val layouts = TimelineViewModel.computeTimelineLayouts(listOf(block(1, 0, 30), block(2, 30, 60)))
        assertTrue(layouts.all { it.colIndex == 0 && it.totalCols == 1 })
    }

    @Test
    fun chainedOverlapReusesFreeColumn() {
        // A 0-60, B 30-90, C 70-100: C fits under A's finished column, so only two columns are needed.
        val layouts = TimelineViewModel.computeTimelineLayouts(listOf(block(1, 0, 60), block(2, 30, 90), block(3, 70, 100)))
        val byId = layouts.associateBy { it.sessionWithSubject.session.id }
        assertEquals(0, byId.getValue(1L).colIndex)
        assertEquals(1, byId.getValue(2L).colIndex)
        assertEquals(0, byId.getValue(3L).colIndex)
        assertTrue(layouts.all { it.totalCols == 2 })
    }

    @Test
    fun emptyInputGivesEmptyLayout() {
        assertTrue(TimelineViewModel.computeTimelineLayouts(emptyList()).isEmpty())
    }

    // ---- Study maths ---------------------------------------------------------------------------

    @Test
    fun calendarWeekdayMatchesGoalTableNumbering() {
        assertEquals(1, StudyMath.calendarWeekday(DayOfWeek.SUNDAY))
        assertEquals(2, StudyMath.calendarWeekday(DayOfWeek.MONDAY))
        assertEquals(7, StudyMath.calendarWeekday(DayOfWeek.SATURDAY))
        assertEquals(StudyMath.calendarWeekday(LocalDate.of(2026, 10, 16)), 6) // a Friday
    }

    @Test
    fun sessionAcrossDayStartIsSplitBetweenStudyDays() {
        val day = LocalDate.of(2026, 10, 6)
        val session = StudySession(id = 1, subjectId = 1, startTime = millis(day, 4), endTime = millis(day, 6))
        val perDay = StudyMath.secondsPerStudyDay(listOf(session), dayStartHour = 5)
        assertEquals(3600L, perDay[day.minusDays(1)])
        assertEquals(3600L, perDay[day])
        assertEquals(7200L, perDay.values.sum())
    }

    @Test
    fun streakCountsConsecutiveDaysAndSkipsAnUnfinishedToday() {
        val today = LocalDate.of(2026, 10, 16)
        val met = mapOf(today.minusDays(1) to 3600L, today.minusDays(2) to 3600L)
        val goal = { _: LocalDate -> 3600L }
        // Today not reached yet: the streak of the two earlier days is kept.
        assertEquals(2, StudyMath.streak(met, goal, today))
        // Time still running in the timer completes today's goal and extends the streak.
        assertEquals(3, StudyMath.streak(met, goal, today, todayLiveSeconds = 3600L))
        // A gap ends the streak.
        assertEquals(0, StudyMath.streak(mapOf(today.minusDays(3) to 3600L), goal, today))
    }

    @Test
    fun goalOfZeroNeverCountsAsMet() {
        val today = LocalDate.of(2026, 10, 16)
        assertEquals(0, StudyMath.streak(mapOf(today to 9999L), { 0L }, today))
    }

    // ---- Stats periods -------------------------------------------------------------------------

    @Test
    fun calendarDayConvertsToDayOfWeek() {
        assertEquals(DayOfWeek.SUNDAY, StatsEngine.dayOfWeekFromCalendar(1))
        assertEquals(DayOfWeek.MONDAY, StatsEngine.dayOfWeekFromCalendar(2))
        assertEquals(DayOfWeek.SATURDAY, StatsEngine.dayOfWeekFromCalendar(7))
    }

    @Test
    fun weekPeriodStartsOnTheChosenFirstDay() {
        val friday = LocalDate.of(2026, 10, 16)
        val (monStart, monEnd) = StatsEngine.periodOf(StatsTab.WEEK, friday, DayOfWeek.MONDAY)
        assertEquals(LocalDate.of(2026, 10, 12), monStart)
        assertEquals(LocalDate.of(2026, 10, 18), monEnd)
        val (satStart, _) = StatsEngine.periodOf(StatsTab.WEEK, friday, DayOfWeek.SATURDAY)
        assertEquals(LocalDate.of(2026, 10, 10), satStart)
    }

    @Test
    fun monthAndYearPeriodsCoverWholeRange() {
        val (ms, me) = StatsEngine.periodOf(StatsTab.MONTH, LocalDate.of(2028, 2, 10), DayOfWeek.MONDAY)
        assertEquals(LocalDate.of(2028, 2, 1), ms)
        assertEquals(LocalDate.of(2028, 2, 29), me) // leap year
        val (ys, ye) = StatsEngine.periodOf(StatsTab.YEAR, LocalDate.of(2026, 7, 4), DayOfWeek.MONDAY)
        assertEquals(LocalDate.of(2026, 1, 1), ys)
        assertEquals(LocalDate.of(2026, 12, 31), ye)
    }

    @Test
    fun elapsedDaysIgnoresFutureDays() {
        val start = LocalDate.of(2026, 10, 12)
        val end = LocalDate.of(2026, 10, 18)
        assertEquals(5, StatsEngine.elapsedDays(start, end, LocalDate.of(2026, 10, 16)))
        assertEquals(7, StatsEngine.elapsedDays(start, end, LocalDate.of(2026, 11, 1)))
        assertEquals(0, StatsEngine.elapsedDays(start, end, LocalDate.of(2026, 10, 1)))
    }

    // ---- Formatting ------------------------------------------------------------------------------

    @Test
    fun compactDurationNeverShowsSecondsAfterAMinute() {
        assertEquals("30s", DateTimeUtils.formatDurationCompact(30L))
        assertEquals("45m", DateTimeUtils.formatDurationCompact(2700L + 59L))
        assertEquals("2h", DateTimeUtils.formatDurationCompact(7200L))
        assertEquals("2h 15m", DateTimeUtils.formatDurationCompact(8100L))
    }

    // ---- Scheduled backup rules --------------------------------------------------------------------

    private val dhaka: ZoneId = ZoneId.of("Asia/Dhaka")

    private fun at(y: Int, m: Int, d: Int, h: Int, min: Int): Long =
        LocalDateTime.of(y, m, d, h, min).atZone(dhaka).toInstant().toEpochMilli()

    @Test
    fun backupIsDueWhenNeverDone() {
        assertTrue(AutoBackupPlan.isDue(0L, at(2026, 10, 17, 3, 0), 1, dhaka))
    }

    @Test
    fun backupIsNotDueTwiceOnTheSameDay() {
        val last = at(2026, 10, 17, 3, 2)
        assertFalse(AutoBackupPlan.isDue(last, at(2026, 10, 17, 22, 0), 1, dhaka))
    }

    @Test
    fun dailyBackupRunsEvenIfTheNextCheckIsAFewMinutesEarly() {
        // Yesterday 03:02, today 03:00 is only 23h58m later, but it is the next calendar day.
        assertTrue(AutoBackupPlan.isDue(at(2026, 10, 16, 3, 2), at(2026, 10, 17, 3, 0), 1, dhaka))
    }

    @Test
    fun multiDayIntervalWaitsForEnoughDays() {
        val last = at(2026, 10, 10, 3, 0)
        assertFalse(AutoBackupPlan.isDue(last, at(2026, 10, 12, 3, 0), 3, dhaka))
        assertTrue(AutoBackupPlan.isDue(last, at(2026, 10, 13, 3, 0), 3, dhaka))
    }

    @Test
    fun backupIsDueWhenTheClockMovedBackwards() {
        assertTrue(AutoBackupPlan.isDue(at(2026, 10, 20, 3, 0), at(2026, 10, 17, 3, 0), 7, dhaka))
    }

    @Test
    fun autoBackupFileNamesSortByAgeAndAreRecognised() {
        val older = AutoBackupPlan.fileName(at(2026, 10, 9, 23, 59), dhaka)
        val newer = AutoBackupPlan.fileName(at(2026, 10, 17, 3, 0), dhaka)
        assertEquals("parallaxtracker-auto-2026-10-17-0300.json", newer)
        assertTrue(older < newer)
        assertTrue(AutoBackupPlan.isOurFile(newer))
        // Files the person made by hand must never be pruned.
        assertFalse(AutoBackupPlan.isOurFile("parallaxtracker-backup-2026-10-17.json"))
        assertFalse(AutoBackupPlan.isOurFile("holiday-photos.json"))
        assertFalse(AutoBackupPlan.isOurFile("parallaxtracker-auto-2026-10-17-0300.json.bak"))
    }
}
