package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PomodoroSettingsDialog(
    initialFocusMinutes: Int,
    initialShortBreakMinutes: Int,
    initialLongBreakMinutes: Int,
    initialInterval: Int,
    onDismiss: () -> Unit,
    onSave: (focus: Int, shortBreak: Int, longBreak: Int, interval: Int) -> Unit
) {
    var focusMinutes by remember { mutableIntStateOf(initialFocusMinutes.coerceIn(1, 120)) }
    var shortBreakMinutes by remember { mutableIntStateOf(initialShortBreakMinutes.coerceIn(1, 30)) }
    var longBreakMinutes by remember { mutableIntStateOf(initialLongBreakMinutes.coerceIn(1, 60)) }
    var interval by remember { mutableIntStateOf(initialInterval.coerceIn(1, 12)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.pomo_customize_title),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // FlowRow instead of Row: with a large font or Bengali text three chips no longer fit one line.
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SuggestionChip(
                        onClick = {
                            focusMinutes = 25; shortBreakMinutes = 5; longBreakMinutes = 15; interval = 4
                        },
                        label = { Text(stringResource(R.string.dlg_pomo_classic)) }
                    )
                    SuggestionChip(
                        onClick = {
                            focusMinutes = 50; shortBreakMinutes = 10; longBreakMinutes = 30; interval = 4
                        },
                        label = { Text(stringResource(R.string.dlg_pomo_deep)) }
                    )
                    SuggestionChip(
                        onClick = {
                            focusMinutes = 20; shortBreakMinutes = 5; longBreakMinutes = 10; interval = 3
                        },
                        label = { Text(stringResource(R.string.dlg_pomo_sprint)) }
                    )
                }

                StepperSlider(
                    title = stringResource(R.string.dlg_pomo_focus),
                    valueText = stringResource(R.string.dlg_minutes_value, focusMinutes.toString()),
                    value = focusMinutes,
                    range = 1..120,
                    tagPrefix = "focus",
                    sliderTag = "pomo_focus_slider",
                    onChange = { focusMinutes = it }
                )
                StepperSlider(
                    title = stringResource(R.string.pomo_phase_short_break),
                    valueText = stringResource(R.string.dlg_minutes_value, shortBreakMinutes.toString()),
                    value = shortBreakMinutes,
                    range = 1..30,
                    tagPrefix = "short_break",
                    sliderTag = "pomo_short_break_slider",
                    onChange = { shortBreakMinutes = it }
                )
                StepperSlider(
                    title = stringResource(R.string.pomo_phase_long_break),
                    valueText = stringResource(R.string.dlg_minutes_value, longBreakMinutes.toString()),
                    value = longBreakMinutes,
                    range = 1..60,
                    tagPrefix = "long_break",
                    sliderTag = "pomo_long_break_slider",
                    onChange = { longBreakMinutes = it }
                )
                StepperSlider(
                    title = stringResource(R.string.dlg_pomo_every),
                    valueText = stringResource(R.string.dlg_cycles_value, interval.toString()),
                    value = interval,
                    range = 1..12,
                    tagPrefix = "interval",
                    sliderTag = "pomo_interval_slider",
                    onChange = { interval = it }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(focusMinutes, shortBreakMinutes, longBreakMinutes, interval) },
                modifier = Modifier.testTag("save_pomodoro_settings")
            ) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

/** One labelled value with minus/plus buttons and a slider underneath. */
@Composable
private fun StepperSlider(
    title: String,
    valueText: String,
    value: Int,
    range: IntRange,
    tagPrefix: String,
    sliderTag: String,
    onChange: (Int) -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                FilledTonalIconButton(
                    onClick = { if (value > range.first) onChange(value - 1) },
                    modifier = Modifier.size(30.dp).testTag("${tagPrefix}_minus_button")
                ) {
                    Icon(
                        Icons.Default.Remove,
                        contentDescription = stringResource(R.string.dlg_decrease),
                        modifier = Modifier.size(16.dp)
                    )
                }
                Text(
                    text = valueText,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
                FilledTonalIconButton(
                    onClick = { if (value < range.last) onChange(value + 1) },
                    modifier = Modifier.size(30.dp).testTag("${tagPrefix}_plus_button")
                ) {
                    Icon(
                        Icons.Default.Add,
                        contentDescription = stringResource(R.string.dlg_increase),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Slider(
                value = value.toFloat(),
                onValueChange = { onChange(it.toInt().coerceIn(range.first, range.last)) },
                valueRange = range.first.toFloat()..range.last.toFloat(),
                // No tick marks: 100+ ticks look noisy; the value is rounded to a whole number anyway.
                modifier = Modifier.testTag(sliderTag)
            )
        }
    }
}
