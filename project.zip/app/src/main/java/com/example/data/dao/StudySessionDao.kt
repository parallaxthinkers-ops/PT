package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.StudySession
import kotlinx.coroutines.flow.Flow

@Dao
interface StudySessionDao {
    @Query("SELECT * FROM study_sessions ORDER BY startTime DESC")
    fun getAllSessionsFlow(): Flow<List<StudySession>>

    @Query("SELECT * FROM study_sessions ORDER BY startTime DESC")
    suspend fun getAllSessionsList(): List<StudySession>

    @Query("SELECT * FROM study_sessions WHERE id = :id LIMIT 1")
    suspend fun getSessionById(id: Long): StudySession?

    // Query for sessions that overlap with a time range [startMs, endMs]
    @Query("SELECT * FROM study_sessions WHERE endTime > :startMs AND startTime < :endMs ORDER BY startTime ASC")
    fun getSessionsInRangeFlow(startMs: Long, endMs: Long): Flow<List<StudySession>>

    @Query("SELECT * FROM study_sessions WHERE endTime > :startMs AND startTime < :endMs ORDER BY startTime ASC")
    suspend fun getSessionsInRangeList(startMs: Long, endMs: Long): List<StudySession>

    @Query("SELECT * FROM study_sessions WHERE subjectId = :subjectId AND endTime > :startMs AND startTime < :endMs ORDER BY startTime ASC")
    fun getSessionsForSubjectInRangeFlow(subjectId: Long, startMs: Long, endMs: Long): Flow<List<StudySession>>

    @Query("SELECT * FROM study_sessions WHERE subjectId = :subjectId AND endTime > :startMs AND startTime < :endMs ORDER BY startTime ASC")
    suspend fun getSessionsForSubjectInRangeList(subjectId: Long, startMs: Long, endMs: Long): List<StudySession>

    @Query("SELECT * FROM study_sessions WHERE subjectId = :subjectId ORDER BY startTime DESC")
    fun getSessionsForSubjectFlow(subjectId: Long): Flow<List<StudySession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: StudySession): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(sessions: List<StudySession>)

    @Update
    suspend fun update(session: StudySession)

    @Delete
    suspend fun delete(session: StudySession)

    @Query("DELETE FROM study_sessions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM study_sessions WHERE subjectId = :subjectId")
    suspend fun deleteBySubjectId(subjectId: Long)

    @Query("SELECT COUNT(*) FROM study_sessions WHERE subjectId = :subjectId")
    suspend fun countForSubject(subjectId: Long): Int

    @Query("UPDATE study_sessions SET subjectId = NULL WHERE subjectId = :subjectId")
    suspend fun unlinkSubject(subjectId: Long)

    @Query("DELETE FROM study_sessions")
    suspend fun deleteAll()
}
