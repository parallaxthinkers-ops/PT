package com.example.ui.screens.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.AppCard
import com.example.ui.components.AppDatePickerDialog
import com.example.ui.components.ColorDot
import com.example.ui.components.DayNavigator
import com.example.ui.components.PillSelector
import com.example.ui.components.ScreenHeader
import com.example.ui.components.SectionLabel
import com.example.ui.theme.Ui
import com.example.util.DateTimeUtils
import java.time.DayOfWeek
import java.time.format.TextStyle
import java.util.Locale

private val UnknownSubjectColor = Color(0xFF64748B)

@Composable
fun StatsScreen(
    viewModel: StatsViewModel,
    onNavigateToTimeline: ((Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val ui by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedHeatmapDay by remember { mutableStateOf<HeatmapDay?>(null) }
    var showDatePicker by remember { mutableStateOf(false) }

    // The subject filter always starts on "All" when this screen opens.
    LaunchedEffect(Unit) { viewModel.selectSubjectFilter(null) }

    val tabLabels = mapOf(
        StatsTab.DAY to stringResource(R.string.stats_day),
        StatsTab.WEEK to stringResource(R.string.stats_week),
        StatsTab.MONTH to stringResource(R.string.stats_month),
        StatsTab.YEAR to stringResource(R.string.stats_year)
    )

    val periodLabel = when (ui.selectedTab) {
        StatsTab.DAY -> DateTimeUtils.formatDayHeader(ui.periodStartMs)
        StatsTab.WEEK -> stringResource(R.string.stats_week_of, DateTimeUtils.formatDate(ui.periodStartMs))
        StatsTab.MONTH -> DateTimeUtils.formatMonth(ui.periodStartMs)
        StatsTab.YEAR -> stringResource(R.string.stats_year_label, ui.periodStart.year.toString())
    }
    val previousName = stringResource(
        when (ui.selectedTab) {
            StatsTab.DAY -> R.string.stats_prev_day
            StatsTab.WEEK -> R.string.stats_prev_week
            StatsTab.MONTH -> R.string.stats_prev_month
            StatsTab.YEAR -> R.string.stats_prev_year
        }
    )
    val diff = ui.totalSeconds - ui.previousPeriodSeconds
    val comparisonText = when {
        diff > 0 -> stringResource(R.string.stats_vs_up, DateTimeUtils.formatDurationShort(diff), previousName)
        diff < 0 -> stringResource(R.string.stats_vs_down, DateTimeUtils.formatDurationShort(-diff), previousName)
        else -> stringResource(R.string.stats_vs_same, previousName)
    }

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(title = stringResource(R.string.stats_title))

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            PillSelector(
                options = StatsTab.values().toList(),
                selected = ui.selectedTab,
                label = { tabLabels[it] ?: "" },
                onSelect = { viewModel.selectTab(it) }
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = ui.selectedSubjectId == null,
                    onClick = { viewModel.selectSubjectFilter(null) },
                    label = { Text(stringResource(R.string.stats_all_subjects)) },
                    modifier = Modifier.testTag("stats_filter_all_subjects")
                )
                ui.subjects.forEach { subject ->
                    FilterChip(
                        selected = ui.selectedSubjectId == subject.id,
                        onClick = { viewModel.selectSubjectFilter(subject.id) },
                        leadingIcon = { ColorDot(Color(subject.color)) },
                        label = { Text(subject.name) },
                        modifier = Modifier.testTag("stats_filter_subject_${subject.id}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            DayNavigator(
                testTagPrefix = "stats",
                dateMs = ui.periodStartMs,
                label = periodLabel,
                isToday = ui.isCurrentPeriod,
                onPrev = { viewModel.previousPeriod() },
                onNext = { viewModel.nextPeriod() },
                onToday = { viewModel.goToToday() },
                onPick = { showDatePicker = true }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // ---- Total -----------------------------------------------------------------------------
            AppCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = stringResource(R.string.stats_total_time),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = DateTimeUtils.formatDurationShort(ui.totalSeconds),
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.testTag("stats_total_time_text")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    val positive = diff > 0
                    val badgeColor = if (positive) Ui.extra.success else if (diff < 0) Ui.extra.warning else MaterialTheme.colorScheme.onSurfaceVariant
                    Row(
                        modifier = Modifier
                            .clip(MaterialTheme.shapes.medium)
                            .background(badgeColor.copy(alpha = 0.14f))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (diff != 0L) {
                            Icon(
                                imageVector = if (positive) Icons.Filled.TrendingUp else Icons.Filled.TrendingDown,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = comparisonText,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = badgeColor,
                            modifier = Modifier.testTag("stats_comparison_badge")
                        )
                    }
                }
            }

            // ---- Trend -----------------------------------------------------------------------------
            SectionLabel(stringResource(R.string.stats_activity_breakdown))
            AppCard(modifier = Modifier.fillMaxWidth()) {
                BarChart(points = ui.barChartPoints, tab = ui.selectedTab)
            }

            // ---- Distribution ----------------------------------------------------------------------
            SectionLabel(stringResource(R.string.stats_subject_breakdown))
            AppCard(modifier = Modifier.fillMaxWidth()) {
                if (ui.distribution.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = stringResource(R.string.stats_no_data),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        if (onNavigateToTimeline != null) {
                            TextButton(
                                onClick = { onNavigateToTimeline(System.currentTimeMillis()) },
                                modifier = Modifier.testTag("stats_empty_view_timeline_button")
                            ) {
                                Text(stringResource(R.string.stats_view_timeline))
                            }
                        }
                    }
                } else {
                    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Donut(ui = ui)
                        Spacer(modifier = Modifier.height(16.dp))
                        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            ui.distribution.forEach { item -> DistributionRow(item) }
                        }
                    }
                }
            }

            // ---- Summary ---------------------------------------------------------------------------
            SectionLabel(stringResource(R.string.stats_summary_title))
            val bestText = ui.bestLabel?.let {
                stringResource(R.string.stats_best_format, it, DateTimeUtils.formatDurationCompact(ui.bestSeconds))
            } ?: "-"
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(stringResource(R.string.stats_daily_average), DateTimeUtils.formatDurationShort(ui.dailyAverageSeconds))
                    StatTile(stringResource(R.string.stats_best_day), bestText)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        stringResource(R.string.stats_total_sessions),
                        stringResource(R.string.stats_sessions_recorded, ui.totalSessionsCount.toString())
                    )
                    StatTile(stringResource(R.string.stats_longest_session), DateTimeUtils.formatDurationShort(ui.longestSessionSeconds))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(
                        stringResource(R.string.stats_goal_achieved_days),
                        stringResource(R.string.stats_days_of, ui.goalAchievedDaysCount.toString(), ui.elapsedDays.toString()),
                        valueColor = Ui.extra.success
                    )
                    StatTile(stringResource(R.string.stats_previous_period), DateTimeUtils.formatDurationShort(ui.previousPeriodSeconds))
                }
                if (ui.selectedTab == StatsTab.DAY || ui.totalInterruptions > 0) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile(
                            stringResource(R.string.stats_interruptions),
                            ui.totalInterruptions.toString(),
                            valueColor = if (ui.totalInterruptions > 0) Ui.extra.danger else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // ---- Heatmap ---------------------------------------------------------------------------
            SectionLabel(stringResource(R.string.stats_monthly_heatmap))
            AppCard(modifier = Modifier.fillMaxWidth()) {
                Heatmap(ui = ui, onDayClick = { selectedHeatmapDay = it })
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }

    if (showDatePicker) {
        AppDatePickerDialog(
            initial = ui.periodStart,
            onDismiss = { showDatePicker = false },
            onConfirm = { date ->
                viewModel.setAnchorDate(date)
                showDatePicker = false
            }
        )
    }

    selectedHeatmapDay?.let { day ->
        AlertDialog(
            onDismissRequest = { selectedHeatmapDay = null },
            icon = {
                Icon(
                    imageVector = Icons.Filled.CalendarMonth,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = { Text(DateTimeUtils.formatDayHeader(day.timestampMs)) },
            text = {
                Column {
                    Text(stringResource(R.string.stats_day_total), style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = DateTimeUtils.formatDurationShort(day.studySeconds),
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            },
            confirmButton = {
                if (onNavigateToTimeline != null) {
                    TextButton(
                        onClick = {
                            val ts = day.timestampMs
                            selectedHeatmapDay = null
                            onNavigateToTimeline(ts)
                        },
                        modifier = Modifier.testTag("heatmap_view_timeline_button")
                    ) {
                        Text(stringResource(R.string.stats_view_timeline))
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedHeatmapDay = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

// =================================================================================================
// Pieces
// =================================================================================================

@Composable
private fun RowScope.StatTile(label: String, value: String, valueColor: Color = MaterialTheme.colorScheme.onSurface) {
    AppCard(modifier = Modifier.weight(1f)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = valueColor,
            maxLines = 1
        )
    }
}

@Composable
private fun BarChart(points: List<BarChartPoint>, tab: StatsTab) {
    if (points.isEmpty()) return
    val maxSeconds = points.maxOf { it.seconds }.coerceAtLeast(60L)
    val barColor = MaterialTheme.colorScheme.primary
    val bestColor = Ui.extra.warning
    val emptyColor = MaterialTheme.colorScheme.surfaceVariant
    val gridColor = Ui.extra.hairline

    val labelStep = when (tab) {
        StatsTab.DAY -> 4
        StatsTab.WEEK -> 1
        StatsTab.MONTH -> 5
        StatsTab.YEAR -> 2
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = stringResource(R.string.stats_max_axis, DateTimeUtils.formatDurationCompact(maxSeconds)),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.align(Alignment.End)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .testTag("stats_canvas_bar_chart")
        ) {
            val w = size.width
            val h = size.height
            val slot = w / points.size
            val barWidth = slot * 0.62f

            for (i in 0..3) {
                val y = h * (i / 3f)
                drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1.dp.toPx())
            }
            points.forEachIndexed { index, point ->
                val fraction = if (point.seconds <= 0L) 0.03f else (point.seconds.toFloat() / maxSeconds.toFloat()).coerceIn(0.05f, 1f)
                val barH = h * fraction
                drawRoundRect(
                    color = when {
                        point.seconds <= 0L -> emptyColor
                        point.isBest -> bestColor
                        else -> barColor
                    },
                    topLeft = Offset(index * slot + (slot - barWidth) / 2f, h - barH),
                    size = Size(barWidth, barH),
                    cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            points.forEachIndexed { index, point ->
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    if (index % labelStep == 0) {
                        Text(
                            text = point.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            softWrap = false,
                            modifier = Modifier.wrapContentWidth(Alignment.CenterHorizontally, unbounded = true)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Donut(ui: StatsUiState) {
    val unknown = UnknownSubjectColor
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(160.dp)
            .testTag("stats_canvas_donut_chart")
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            var startAngle = -90f
            val strokeWidthPx = 20.dp.toPx()
            val gap = if (ui.distribution.size > 1) 2f else 0f
            ui.distribution.forEach { item ->
                val sweep = item.percentage * 360f
                val color = item.subject?.takeIf { !it.isArchived }?.let { Color(it.color) } ?: unknown
                drawArc(
                    color = color,
                    startAngle = startAngle + gap / 2f,
                    sweepAngle = (sweep - gap).coerceAtLeast(0.5f),
                    useCenter = false,
                    style = Stroke(width = strokeWidthPx)
                )
                startAngle += sweep
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = DateTimeUtils.formatDurationShort(ui.totalSeconds),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = stringResource(R.string.stats_total_short),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DistributionRow(item: SubjectDistributionItem) {
    val subject = item.subject
    val name = when {
        subject == null -> stringResource(R.string.timeline_unknown_subject)
        subject.isArchived -> subject.name + " " + stringResource(R.string.timeline_deleted_suffix)
        else -> subject.name
    }
    val color = if (subject != null && !subject.isArchived) Color(subject.color) else UnknownSubjectColor
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ColorDot(color)
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = DateTimeUtils.formatDurationShort(item.durationSeconds),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "${(item.percentage * 100).toInt()}%",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(36.dp),
            textAlign = TextAlign.End
        )
    }
}

@Composable
private fun Heatmap(ui: StatsUiState, onDayClick: (HeatmapDay) -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val empty = MaterialTheme.colorScheme.surfaceVariant
    fun cellColor(intensity: Int): Color = when (intensity) {
        0 -> empty
        else -> primary.copy(alpha = 0.18f + 0.82f * (intensity / 4f))
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        // Weekday headers follow the first day of the week chosen in Settings.
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (0 until 7).forEach { offset ->
                val day = DayOfWeek.of(((ui.firstDayOfWeek.value - 1 + offset) % 7) + 1)
                Text(
                    text = day.getDisplayName(TextStyle.NARROW, Locale.getDefault()),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))

        val cells: List<HeatmapDay?> = List(ui.heatmapLeadingBlanks) { null } + ui.heatmapDays
        cells.chunked(7).forEach { week ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                week.forEach { day ->
                    if (day == null) {
                        Spacer(modifier = Modifier.weight(1f).height(40.dp))
                    } else {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .clip(MaterialTheme.shapes.small)
                                .background(cellColor(day.intensity))
                                .clickable { onDayClick(day) }
                                .testTag("heatmap_day_${day.dayNumber}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = day.dayNumber.toString(),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp,
                                    color = if (day.intensity >= 3) Ui.extra.onAccent else MaterialTheme.colorScheme.onSurface
                                )
                                if (day.studySeconds >= 60L) {
                                    Text(
                                        text = DateTimeUtils.formatDurationCompact(day.studySeconds),
                                        fontSize = 8.sp,
                                        maxLines = 1,
                                        color = if (day.intensity >= 3) Ui.extra.onAccent else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                repeat(7 - week.size) { Spacer(modifier = Modifier.weight(1f)) }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(stringResource(R.string.stats_less), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(6.dp))
            (0..4).forEach { level ->
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(MaterialTheme.shapes.extraSmall)
                        .background(cellColor(level))
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(stringResource(R.string.stats_more), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
