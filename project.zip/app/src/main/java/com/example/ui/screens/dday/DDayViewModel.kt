package com.example.ui.screens.dday

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.StudyApplication
import com.example.data.model.DDay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DDayViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as StudyApplication
    private val studyRepo = app.studyRepository

    val dDays: StateFlow<List<DDay>> = studyRepo.allDDays.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun addDDay(title: String, targetDateMs: Long, countUp: Boolean, isPinned: Boolean, color: Long = 0xFF3B82F6L) {
        viewModelScope.launch {
            val dDay = DDay(
                title = title,
                targetDate = targetDateMs,
                countUp = countUp,
                color = color,
                isPinned = isPinned
            )
            studyRepo.insertDDay(dDay)
        }
    }

    fun updateDDay(dDay: DDay) {
        viewModelScope.launch {
            studyRepo.updateDDay(dDay)
        }
    }

    fun deleteDDay(dDay: DDay) {
        viewModelScope.launch {
            studyRepo.deleteDDay(dDay)
        }
    }

    fun pinDDay(id: Long) {
        viewModelScope.launch {
            studyRepo.pinDDay(id)
        }
    }
}
