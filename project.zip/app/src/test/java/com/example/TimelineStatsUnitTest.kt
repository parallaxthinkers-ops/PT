package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.data.repository.StudyRepository
import com.example.service.TimerMode
import com.example.service.TimerState
import com.example.service.TimerStateManager
import com.example.service.TimerStatus
import com.example.util.DateTimeUtils
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.Calendar

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class TimelineStatsUnitTest {

    @Test
    fun testDayBoundarySplittingExact() {
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 5, 0, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val dayStartHour = 5 // 05:00 AM reset

        // Study day 1 range: Oct 5 05:00 to Oct 6 05:00
        val (day1Start, day1End) = DateTimeUtils.getStudyDayRange(cal.timeInMillis + (10 * 3600000L), dayStartHour)
        // Study day 2 range: Oct 6 05:00 to Oct 7 05:00
        val (day2Start, day2End) = DateTimeUtils.getStudyDayRange(day1End + 1000L, dayStartHour)

        // Session from Oct 6 04:00 AM (Day 1) to Oct 6 06:30 AM (Day 2) -> 2.5 hours total
        val sessionStart = day1End - (3600000L) // 04:00 AM (1 hour before boundary)
        val sessionEnd = day1End + (5400000L)   // 06:30 AM (1.5 hours after boundary)

        val session = StudySession(
            id = 1,
            subjectId = 1,
            startTime = sessionStart,
            endTime = sessionEnd
        )

        val overlapDay1 = DateTimeUtils.getSessionOverlapMillis(session, day1Start, day1End)
        val overlapDay2 = DateTimeUtils.getSessionOverlapMillis(session, day2Start, day2End)

        // Overlap in Day 1 must be exactly 1 hour (3600000 ms)
        assertEquals(3600000L, overlapDay1)
        // Overlap in Day 2 must be exactly 1.5 hours (5400000 ms)
        assertEquals(5400000L, overlapDay2)
        // Total split equals total session duration (2.5 hours = 9000000 ms)
        assertEquals(session.durationMillis, overlapDay1 + overlapDay2)
    }

    @Test
    fun testMidnightCrossingSameStudyDay() {
        // Study day starts at 05:00 AM.
        // Session runs from 23:30 (11:30 PM) to 01:30 (1:30 AM next calendar day).
        // Since 01:30 is before 05:00, it belongs to the same study day!
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 5, 12, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val dayStartHour = 5
        val (studyDayStart, studyDayEnd) = DateTimeUtils.getStudyDayRange(cal.timeInMillis, dayStartHour)

        cal.set(2026, Calendar.OCTOBER, 5, 23, 30, 0)
        val startMs = cal.timeInMillis
        cal.set(2026, Calendar.OCTOBER, 6, 1, 30, 0)
        val endMs = cal.timeInMillis

        val session = StudySession(
            id = 2,
            subjectId = 1,
            startTime = startMs,
            endTime = endMs
        )

        val overlap = DateTimeUtils.getSessionOverlapMillis(session, studyDayStart, studyDayEnd)
        // The entire 2-hour session (7200000 ms) belongs to this single study day
        assertEquals(7200000L, overlap)
        assertEquals(session.durationMillis, overlap)
    }

    @Test
    fun testPeriodTotalsCalculationWithMultipleSessions() {
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 5, 5, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val weekStart = cal.timeInMillis
        val weekEnd = weekStart + (7 * 86400000L)

        // Session 1: inside the week (1 hour)
        val s1 = StudySession(id = 1, startTime = weekStart + 3600000L, endTime = weekStart + 7200000L)
        // Session 2: inside the week (2 hours)
        val s2 = StudySession(id = 2, startTime = weekStart + 36000000L, endTime = weekStart + 43200000L)
        // Session 3: overlapping the start boundary (1 hour before, 1 hour inside -> 1 hour effective)
        val s3 = StudySession(id = 3, startTime = weekStart - 3600000L, endTime = weekStart + 3600000L)
        // Session 4: outside the week completely (0 hours)
        val s4 = StudySession(id = 4, startTime = weekEnd + 100000L, endTime = weekEnd + 3600000L)

        val sessions = listOf(s1, s2, s3, s4)
        var totalCalculatedMs = 0L
        for (s in sessions) {
            totalCalculatedMs += DateTimeUtils.getSessionOverlapMillis(s, weekStart, weekEnd)
        }

        // Expected: s1 (1h) + s2 (2h) + s3 (1h overlap) + s4 (0h) = 4 hours (14400000 ms)
        assertEquals(14400000L, totalCalculatedMs)
        val totalHours = totalCalculatedMs / 3600000L
        assertEquals(4L, totalHours)
    }

    @Test
    fun testSessionOutsideRangeReturnsZero() {
        val rangeStart = 1000000L
        val rangeEnd = 2000000L
        val before = StudySession(id = 1, startTime = 500000L, endTime = 900000L)
        val after = StudySession(id = 2, startTime = 2100000L, endTime = 2500000L)

        assertEquals(0L, DateTimeUtils.getSessionOverlapMillis(before, rangeStart, rangeEnd))
        assertEquals(0L, DateTimeUtils.getSessionOverlapMillis(after, rangeStart, rangeEnd))
    }

    @Test
    fun testFormatTimerClockAndDuration() {
        assertEquals("00:00:00", DateTimeUtils.formatTimerClock(0L))
        assertEquals("00:01:30", DateTimeUtils.formatTimerClock(90L))
        assertEquals("01:15:20", DateTimeUtils.formatTimerClock(4520L))

        assertEquals("0s", DateTimeUtils.formatDurationShort(0L))
        assertEquals("45s", DateTimeUtils.formatDurationShort(45L))
        assertEquals("1m 30s", DateTimeUtils.formatDurationShort(90L))
        assertEquals("2h 15m", DateTimeUtils.formatDurationShort(8100L))
    }

    @Test
    fun testTimelineQueryReturnsAllSubjectsRegardlessOfTimerSelection() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val studyRepo = StudyRepository(db)

        // 1. Create 3 subjects
        val mathId = studyRepo.insertSubject(Subject(name = "Math", color = 0xFFEF4444L))
        val englishId = studyRepo.insertSubject(Subject(name = "English", color = 0xFF3B82F6L))
        val scienceId = studyRepo.insertSubject(Subject(name = "Science", color = 0xFF10B981L))

        // 2. Define study day range (e.g. 05:00 today to 05:00 tomorrow)
        val cal = Calendar.getInstance().apply {
            set(2026, Calendar.OCTOBER, 5, 5, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val dayStartMs = cal.timeInMillis
        val dayEndMs = dayStartMs + 86400000L

        // 3. Create study sessions for all 3 subjects on this same day
        val s1 = StudySession(
            subjectId = mathId,
            startTime = dayStartMs + 3600000L,       // 06:00
            endTime = dayStartMs + 7200000L,         // 07:00
            mode = "STOPWATCH"
        )
        val s2 = StudySession(
            subjectId = englishId,
            startTime = dayStartMs + 10800000L,      // 08:00
            endTime = dayStartMs + 14400000L,        // 09:00
            mode = "COUNTDOWN"
        )
        val s3 = StudySession(
            subjectId = scienceId,
            startTime = dayStartMs + 18000000L,      // 10:00
            endTime = dayStartMs + 21600000L,        // 11:00
            mode = "POMODORO"
        )
        studyRepo.insertSession(s1)
        studyRepo.insertSession(s2)
        studyRepo.insertSession(s3)

        // 4. Select one subject on the Timer (e.g. Math)
        TimerStateManager.setState(
            TimerState(
                status = TimerStatus.RUNNING,
                mode = TimerMode.STOPWATCH,
                subjectId = mathId,
                subjectName = "Math",
                subjectColor = 0xFFEF4444L
            )
        )

        // Verify Timer state has Math selected
        assertEquals(mathId, TimerStateManager.timerState.value.subjectId)

        // 5. Query Timeline sessions for the day range (date range only, as Timeline does)
        val timelineSessions = studyRepo.getSessionsInRange(dayStartMs, dayEndMs).first()

        // 6. Assert that the Timeline query still returns ALL 3 sessions/subjects
        assertEquals(3, timelineSessions.size)
        val returnedSubjectIds = timelineSessions.mapNotNull { it.subjectId }.toSet()
        assertTrue(returnedSubjectIds.contains(mathId))
        assertTrue(returnedSubjectIds.contains(englishId))
        assertTrue(returnedSubjectIds.contains(scienceId))

        db.close()
    }
}
