package com.example.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.LayoutMath

/** The colour of every pop-up: the usual dialog colour, see-through by [LayoutMath.DIALOG_ALPHA]. */
@Composable
fun dialogContainerColor(): Color =
    AlertDialogDefaults.containerColor.copy(alpha = LayoutMath.DIALOG_ALPHA)

/**
 * The app's one dialog. It is Material's AlertDialog with the semi-transparent colour built in, so every pop-up in the app
 * looks the same and a new one cannot forget it. Use this, never AlertDialog directly.
 */
@Composable
fun AppAlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: @Composable (() -> Unit)? = null,
    icon: @Composable (() -> Unit)? = null,
    title: @Composable (() -> Unit)? = null,
    text: @Composable (() -> Unit)? = null,
    shape: Shape = AlertDialogDefaults.shape,
    containerColor: Color = dialogContainerColor(),
    iconContentColor: Color = AlertDialogDefaults.iconContentColor,
    titleContentColor: Color = AlertDialogDefaults.titleContentColor,
    textContentColor: Color = AlertDialogDefaults.textContentColor,
    tonalElevation: Dp = AlertDialogDefaults.TonalElevation,
    properties: DialogProperties = DialogProperties()
) {
    // The glass edge (bright at the top-left, fading) and the faint top highlight, the same as the cards. It is drawn over
    // the dialog by the wrapper, so the see-through fill stays exactly as it was.
    val look = rememberGlassLook()
    AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = confirmButton,
        modifier = modifier.glassEdge(shape, look),
        dismissButton = dismissButton,
        icon = icon,
        title = title,
        text = text,
        shape = shape,
        containerColor = containerColor,
        iconContentColor = iconContentColor,
        titleContentColor = titleContentColor,
        textContentColor = textContentColor,
        tonalElevation = tonalElevation,
        properties = properties
    )
}
