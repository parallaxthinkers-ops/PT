package com.example.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.res.Resources

/**
 * Gives Compose resources in another language while it stays a wrapper around the real Activity.
 * A context made with createConfigurationContext() is NOT an Activity and cannot be unwrapped to one, which
 * silently breaks everything that needs the window (immersive mode, keep-screen-on, screen pinning).
 */
class LocalizedContextWrapper(base: Context, private val localizedResources: Resources) : ContextWrapper(base) {
    override fun getResources(): Resources = localizedResources
}

/** The Activity behind this context, also through any number of wrappers. Null when there is none. */
fun Context.findActivity(): Activity? {
    var current: Context? = this
    var guard = 0
    while (current != null && guard < 20) {
        if (current is Activity) return current
        current = (current as? ContextWrapper)?.baseContext
        guard++
    }
    return null
}
