package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "study_tasks",
    foreignKeys = [
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index(value = ["subjectId"]),
        Index(value = ["date"])
    ]
)
data class StudyTask(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val subjectId: Long? = null,
    val plannedMinutes: Int = 0,
    val date: String, // "yyyy-MM-dd"
    val isDone: Boolean = false,
    val repeatRule: String = "NONE", // NONE, DAILY, WEEKDAYS, WEEKLY
    val order: Int = 0
)
