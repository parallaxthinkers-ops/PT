package com.example.ui.navigation

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.LocalThemeLook
import com.example.ui.components.RowDivider

data class NavItem(
    val screen: Screen,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    @StringRes val labelRes: Int
)

val navItems = listOf(
    NavItem(Screen.Timer, Icons.Filled.Timer, Icons.Outlined.Timer, R.string.nav_timer),
    NavItem(Screen.Planner, Icons.Filled.Checklist, Icons.Outlined.Checklist, R.string.nav_planner),
    NavItem(Screen.Timeline, Icons.Filled.Schedule, Icons.Outlined.Schedule, R.string.nav_timeline),
    NavItem(Screen.Stats, Icons.Filled.BarChart, Icons.Outlined.BarChart, R.string.nav_stats),
    NavItem(Screen.Settings, Icons.Filled.Settings, Icons.Outlined.Settings, R.string.nav_settings)
)

/** Flat bar with a hairline on top. Labels come from string resources, so they follow the app language. */
@Composable
fun StudyBottomNavBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val primary = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(modifier = modifier) {
        RowDivider()
        NavigationBar(
            // Transparent when the gradient backdrop is on, so the bar does not cut a plain band across it.
            containerColor = if (LocalThemeLook.current.backdrop != null) Color.Transparent else MaterialTheme.colorScheme.background,
            tonalElevation = 0.dp
        ) {
            navItems.forEach { item ->
                val isSelected = currentScreen.route == item.screen.route
                val label = stringResource(item.labelRes)
                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onNavigate(item.screen) },
                    icon = {
                        Icon(
                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                            contentDescription = label
                        )
                    },
                    label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    alwaysShowLabel = true,
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = primary,
                        selectedTextColor = primary,
                        indicatorColor = primary.copy(alpha = 0.12f),
                        unselectedIconColor = muted,
                        unselectedTextColor = muted
                    ),
                    modifier = Modifier.testTag("nav_tab_${item.screen.route}")
                )
            }
        }
    }
}
