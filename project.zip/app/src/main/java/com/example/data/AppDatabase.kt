package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.DDayDao
import com.example.data.dao.GoalDao
import com.example.data.dao.StudySessionDao
import com.example.data.dao.StudyTaskDao
import com.example.data.dao.SubjectDao
import com.example.data.dao.TaskCompletionDao
import com.example.data.model.DDay
import com.example.data.model.Goal
import com.example.data.model.StudySession
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.TaskCompletion

@Database(
    entities = [
        Subject::class,
        StudySession::class,
        Goal::class,
        DDay::class,
        StudyTask::class,
        TaskCompletion::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun goalDao(): GoalDao
    abstract fun dDayDao(): DDayDao
    abstract fun studyTaskDao(): StudyTaskDao
    abstract fun taskCompletionDao(): TaskCompletionDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `task_completions` (
                        `taskId` INTEGER NOT NULL,
                        `date` TEXT NOT NULL,
                        PRIMARY KEY(`taskId`, `date`),
                        FOREIGN KEY(`taskId`) REFERENCES `study_tasks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_task_completions_taskId` ON `task_completions` (`taskId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_task_completions_date` ON `task_completions` (`date`)")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_study_sessions_startTime` ON `study_sessions` (`startTime`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_study_sessions_endTime` ON `study_sessions` (`endTime`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_study_sessions_subjectId` ON `study_sessions` (`subjectId`)")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val cursor = db.query("PRAGMA table_info(study_sessions)")
                var hasInterruptions = false
                while (cursor.moveToNext()) {
                    val nameIndex = cursor.getColumnIndex("name")
                    if (nameIndex != -1 && cursor.getString(nameIndex) == "interruptions") {
                        hasInterruptions = true
                        break
                    }
                }
                cursor.close()
                if (!hasInterruptions) {
                    db.execSQL("ALTER TABLE `study_sessions` ADD COLUMN `interruptions` INTEGER NOT NULL DEFAULT 0")
                }
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val cursor = db.query("PRAGMA table_info(subjects)")
                var hasIsArchived = false
                while (cursor.moveToNext()) {
                    val nameIndex = cursor.getColumnIndex("name")
                    if (nameIndex != -1 && cursor.getString(nameIndex) == "isArchived") {
                        hasIsArchived = true
                        break
                    }
                }
                cursor.close()
                if (!hasIsArchived) {
                    db.execSQL("ALTER TABLE `subjects` ADD COLUMN `isArchived` INTEGER NOT NULL DEFAULT 0")
                }
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "studylocal_database.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            seedDefaultGoals(db)
                        }
                    })
                    .build()
                    .also { INSTANCE = it }
            }
        }

        /**
         * A brand-new database starts with a 4 hour goal for every weekday and NOTHING else:
         * no sample subjects and no sample D-Day. The first-run screen lets the user create their own.
         * Plain SQL inside onCreate, so it is atomic and needs no coroutine or INSTANCE race.
         */
        private fun seedDefaultGoals(db: SupportSQLiteDatabase) {
            for (weekday in 1..7) {
                db.execSQL("INSERT OR REPLACE INTO `goals` (`weekday`, `targetMinutes`) VALUES ($weekday, 240)")
            }
        }
    }
}
