package com.example

import com.example.data.backup.AutoBackupPlan
import com.example.data.model.StudySession
import com.example.data.repository.LayoutNames
import com.example.ui.theme.HeatMath
import com.example.ui.theme.LayoutMath
import com.example.ui.theme.ThemeMath
import com.example.ui.theme.ThemePresets
import com.example.ui.screens.stats.StatsEngine
import com.example.ui.screens.stats.StatsTab
import com.example.ui.screens.timeline.SessionWithSubject
import com.example.ui.screens.timeline.TimelineViewModel
import com.example.util.DateTimeUtils
import com.example.util.StudyMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/** Plain JVM tests for the pure logic: no Android classes are needed, so they run fast. */
class PureLogicTest {

    private fun block(id: Long, startMin: Long, endMin: Long): SessionWithSubject {
        val start = startMin * 60_000L
        val end = endMin * 60_000L
        return SessionWithSubject(
            session = StudySession(id = id, subjectId = 1, startTime = start, endTime = end),
            subject = null,
            effectiveStartMs = start,
            effectiveEndMs = end,
            effectiveDurationSeconds = (end - start) / 1000L
        )
    }

    private fun millis(date: LocalDate, hour: Int, minute: Int = 0): Long =
        LocalDateTime.of(date, java.time.LocalTime.of(hour, minute)).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    // ---- Timeline layout (the "short subjects do not show" fix) -------------------------------

    @Test
    fun shortSessionsCloseTogetherGetSeparateColumns() {
        // Two 3-minute sessions 10 minutes apart. Drawn at the 15-minute minimum height they would
        // overlap, so they must not share a column (before the fix one of them was hidden).
        val a = block(1, 0, 3)
        val b = block(2, 10, 13)
        val layouts = TimelineViewModel.computeTimelineLayouts(listOf(a, b), minDurationMs = 15 * 60_000L)
        assertEquals(2, layouts.size)
        assertEquals(setOf(0, 1), layouts.map { it.colIndex }.toSet())
        assertTrue(layouts.all { it.totalCols == 2 })
    }

    @Test
    fun shortSessionsFarApartShareOneColumn() {
        val layouts = TimelineViewModel.computeTimelineLayouts(
            listOf(block(1, 0, 3), block(2, 60, 63)),
            minDurationMs = 15 * 60_000L
        )
        assertTrue(layouts.all { it.colIndex == 0 && it.totalCols == 1 })
    }

    @Test
    fun backToBackSessionsDoNotOverlap() {
        val layouts = TimelineViewModel.computeTimelineLayouts(listOf(block(1, 0, 30), block(2, 30, 60)))
        assertTrue(layouts.all { it.colIndex == 0 && it.totalCols == 1 })
    }

    @Test
    fun chainedOverlapReusesFreeColumn() {
        // A 0-60, B 30-90, C 70-100: C fits under A's finished column, so only two columns are needed.
        val layouts = TimelineViewModel.computeTimelineLayouts(listOf(block(1, 0, 60), block(2, 30, 90), block(3, 70, 100)))
        val byId = layouts.associateBy { it.sessionWithSubject.session.id }
        assertEquals(0, byId.getValue(1L).colIndex)
        assertEquals(1, byId.getValue(2L).colIndex)
        assertEquals(0, byId.getValue(3L).colIndex)
        assertTrue(layouts.all { it.totalCols == 2 })
    }

    @Test
    fun emptyInputGivesEmptyLayout() {
        assertTrue(TimelineViewModel.computeTimelineLayouts(emptyList()).isEmpty())
    }

    // ---- Study maths ---------------------------------------------------------------------------

    @Test
    fun calendarWeekdayMatchesGoalTableNumbering() {
        assertEquals(1, StudyMath.calendarWeekday(DayOfWeek.SUNDAY))
        assertEquals(2, StudyMath.calendarWeekday(DayOfWeek.MONDAY))
        assertEquals(7, StudyMath.calendarWeekday(DayOfWeek.SATURDAY))
        assertEquals(StudyMath.calendarWeekday(LocalDate.of(2026, 10, 16)), 6) // a Friday
    }

    @Test
    fun sessionAcrossDayStartIsSplitBetweenStudyDays() {
        val day = LocalDate.of(2026, 10, 6)
        val session = StudySession(id = 1, subjectId = 1, startTime = millis(day, 4), endTime = millis(day, 6))
        val perDay = StudyMath.secondsPerStudyDay(listOf(session), dayStartHour = 5)
        assertEquals(3600L, perDay[day.minusDays(1)])
        assertEquals(3600L, perDay[day])
        assertEquals(7200L, perDay.values.sum())
    }

    @Test
    fun streakCountsConsecutiveDaysAndSkipsAnUnfinishedToday() {
        val today = LocalDate.of(2026, 10, 16)
        val met = mapOf(today.minusDays(1) to 3600L, today.minusDays(2) to 3600L)
        val goal = { _: LocalDate -> 3600L }
        // Today not reached yet: the streak of the two earlier days is kept.
        assertEquals(2, StudyMath.streak(met, goal, today))
        // Time still running in the timer completes today's goal and extends the streak.
        assertEquals(3, StudyMath.streak(met, goal, today, todayLiveSeconds = 3600L))
        // A gap ends the streak.
        assertEquals(0, StudyMath.streak(mapOf(today.minusDays(3) to 3600L), goal, today))
    }

    @Test
    fun goalOfZeroNeverCountsAsMet() {
        val today = LocalDate.of(2026, 10, 16)
        assertEquals(0, StudyMath.streak(mapOf(today to 9999L), { 0L }, today))
    }

    // ---- Stats periods -------------------------------------------------------------------------

    @Test
    fun calendarDayConvertsToDayOfWeek() {
        assertEquals(DayOfWeek.SUNDAY, StatsEngine.dayOfWeekFromCalendar(1))
        assertEquals(DayOfWeek.MONDAY, StatsEngine.dayOfWeekFromCalendar(2))
        assertEquals(DayOfWeek.SATURDAY, StatsEngine.dayOfWeekFromCalendar(7))
    }

    @Test
    fun weekPeriodStartsOnTheChosenFirstDay() {
        val friday = LocalDate.of(2026, 10, 16)
        val (monStart, monEnd) = StatsEngine.periodOf(StatsTab.WEEK, friday, DayOfWeek.MONDAY)
        assertEquals(LocalDate.of(2026, 10, 12), monStart)
        assertEquals(LocalDate.of(2026, 10, 18), monEnd)
        val (satStart, _) = StatsEngine.periodOf(StatsTab.WEEK, friday, DayOfWeek.SATURDAY)
        assertEquals(LocalDate.of(2026, 10, 10), satStart)
    }

    @Test
    fun monthAndYearPeriodsCoverWholeRange() {
        val (ms, me) = StatsEngine.periodOf(StatsTab.MONTH, LocalDate.of(2028, 2, 10), DayOfWeek.MONDAY)
        assertEquals(LocalDate.of(2028, 2, 1), ms)
        assertEquals(LocalDate.of(2028, 2, 29), me) // leap year
        val (ys, ye) = StatsEngine.periodOf(StatsTab.YEAR, LocalDate.of(2026, 7, 4), DayOfWeek.MONDAY)
        assertEquals(LocalDate.of(2026, 1, 1), ys)
        assertEquals(LocalDate.of(2026, 12, 31), ye)
    }

    @Test
    fun elapsedDaysIgnoresFutureDays() {
        val start = LocalDate.of(2026, 10, 12)
        val end = LocalDate.of(2026, 10, 18)
        assertEquals(5, StatsEngine.elapsedDays(start, end, LocalDate.of(2026, 10, 16)))
        assertEquals(7, StatsEngine.elapsedDays(start, end, LocalDate.of(2026, 11, 1)))
        assertEquals(0, StatsEngine.elapsedDays(start, end, LocalDate.of(2026, 10, 1)))
    }

    // ---- Formatting ------------------------------------------------------------------------------

    @Test
    fun compactDurationNeverShowsSecondsAfterAMinute() {
        assertEquals("30s", DateTimeUtils.formatDurationCompact(30L))
        assertEquals("45m", DateTimeUtils.formatDurationCompact(2700L + 59L))
        assertEquals("2h", DateTimeUtils.formatDurationCompact(7200L))
        assertEquals("2h 15m", DateTimeUtils.formatDurationCompact(8100L))
    }

    // ---- Scheduled backup rules --------------------------------------------------------------------

    private val dhaka: ZoneId = ZoneId.of("Asia/Dhaka")

    private fun at(y: Int, m: Int, d: Int, h: Int, min: Int): Long =
        LocalDateTime.of(y, m, d, h, min).atZone(dhaka).toInstant().toEpochMilli()

    @Test
    fun backupIsDueWhenNeverDone() {
        assertTrue(AutoBackupPlan.isDue(0L, at(2026, 10, 17, 3, 0), 1, dhaka))
    }

    @Test
    fun backupIsNotDueTwiceOnTheSameDay() {
        val last = at(2026, 10, 17, 3, 2)
        assertFalse(AutoBackupPlan.isDue(last, at(2026, 10, 17, 22, 0), 1, dhaka))
    }

    @Test
    fun dailyBackupRunsEvenIfTheNextCheckIsAFewMinutesEarly() {
        // Yesterday 03:02, today 03:00 is only 23h58m later, but it is the next calendar day.
        assertTrue(AutoBackupPlan.isDue(at(2026, 10, 16, 3, 2), at(2026, 10, 17, 3, 0), 1, dhaka))
    }

    @Test
    fun multiDayIntervalWaitsForEnoughDays() {
        val last = at(2026, 10, 10, 3, 0)
        assertFalse(AutoBackupPlan.isDue(last, at(2026, 10, 12, 3, 0), 3, dhaka))
        assertTrue(AutoBackupPlan.isDue(last, at(2026, 10, 13, 3, 0), 3, dhaka))
    }

    @Test
    fun backupIsDueWhenTheClockMovedBackwards() {
        assertTrue(AutoBackupPlan.isDue(at(2026, 10, 20, 3, 0), at(2026, 10, 17, 3, 0), 7, dhaka))
    }

    @Test
    fun autoBackupFileNamesSortByAgeAndAreRecognised() {
        val older = AutoBackupPlan.fileName(at(2026, 10, 9, 23, 59), dhaka)
        val newer = AutoBackupPlan.fileName(at(2026, 10, 17, 3, 0), dhaka)
        assertEquals("parallaxtracker-auto-2026-10-17-0300.json", newer)
        assertTrue(older < newer)
        assertTrue(AutoBackupPlan.isOurFile(newer))
        // Files the person made by hand must never be pruned.
        assertFalse(AutoBackupPlan.isOurFile("parallaxtracker-backup-2026-10-17.json"))
        assertFalse(AutoBackupPlan.isOurFile("holiday-photos.json"))
        assertFalse(AutoBackupPlan.isOurFile("parallaxtracker-auto-2026-10-17-0300.json.bak"))
    }

    // ---- Themes ---------------------------------------------------------------------------------------

    @Test
    fun everyAestheticIsReadableInLightAndDark() {
        for (preset in ThemePresets.all) {
            for ((mode, p) in listOf("light" to preset.light, "dark" to preset.dark)) {
                val tag = preset.id + " " + mode
                assertTrue("$tag main text", ThemeMath.contrast(p.onSurface, p.surface) >= 4.5)
                assertTrue("$tag main text on screen", ThemeMath.contrast(p.onSurface, p.bg) >= 4.5)
                assertTrue("$tag secondary text", ThemeMath.contrast(p.onVariant, p.surface) >= 4.5)
                assertTrue("$tag secondary text on screen", ThemeMath.contrast(p.onVariant, p.bg) >= 4.5)
                assertTrue("$tag text on chips", ThemeMath.contrast(p.onVariant, p.variant) >= 3.5)
                assertTrue("$tag accent on cards", ThemeMath.contrast(p.accent, p.surface) >= 3.0)
                assertTrue("$tag accent on screen", ThemeMath.contrast(p.accent, p.bg) >= 3.0)
                assertTrue("$tag button text", ThemeMath.contrast(ThemeMath.onColorFor(p.accent), p.accent) >= 4.5)
            }
        }
    }

    @Test
    fun buttonTextIsReadableOnAnyColour() {
        // A grid over the whole colour cube: whatever accent a person picks, the text on it stays readable.
        for (r in 0..255 step 51) for (g in 0..255 step 51) for (b in 0..255 step 51) {
            val c = 0xFF000000L or (r.toLong() shl 16) or (g.toLong() shl 8) or b.toLong()
            assertTrue("colour $c", ThemeMath.contrast(ThemeMath.onColorFor(c), c) >= 4.4)
        }
        assertEquals(ThemeMath.NEAR_BLACK, ThemeMath.onColorFor(0xFFFFFFFFL))
        assertEquals(ThemeMath.WHITE, ThemeMath.onColorFor(0xFF000000L))
    }

    @Test
    fun aestheticIdsAreUniqueAndUnknownIdsFallBackToClassic() {
        val ids = ThemePresets.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertFalse(ids.contains(ThemePresets.CLASSIC))
        assertEquals(ThemePresets.CLASSIC, ThemePresets.normalize(null))
        assertEquals(ThemePresets.CLASSIC, ThemePresets.normalize("NOT_A_THEME"))
        assertEquals("SAKURA", ThemePresets.normalize("SAKURA"))
        assertEquals(ThemePresets.all.size, ids.count { ThemePresets.find(it) != null })
    }

    // ---- Layouts (Neumorphism and Glassmorphism) -------------------------------------------------------

    @Test
    fun layoutNamesFallBackToClassic() {
        assertEquals(LayoutNames.CLASSIC, LayoutNames.normalize(null))
        assertEquals(LayoutNames.CLASSIC, LayoutNames.normalize("garbage"))
        assertEquals(LayoutNames.NEUMORPHISM, LayoutNames.normalize("NEUMORPHISM"))
        assertEquals(LayoutNames.GLASSMORPHISM, LayoutNames.normalize("GLASSMORPHISM"))
    }

    @Test
    fun mixMovesBetweenTwoColours() {
        assertEquals(0xFF000000L, LayoutMath.mix(0xFF000000L, 0xFFFFFFFFL, 0f))
        assertEquals(0xFFFFFFFFL, LayoutMath.mix(0xFF000000L, 0xFFFFFFFFL, 1f))
        assertEquals(0xFF808080L, LayoutMath.mix(0xFF000000L, 0xFFFFFFFFL, 0.5f))
    }

    @Test
    fun glassTextStaysReadableOverEveryBackdropTint() {
        // The card is see-through, so what is behind it changes the colour the text sits on. Check the worst
        // case: the card over each of the three backdrop stops, for every aesthetic in light and dark.
        for (preset in ThemePresets.all) {
            for ((mode, p) in listOf("light" to preset.light, "dark" to preset.dark)) {
                val stops = LayoutMath.glassStops(p.bg, p.accent, p.accent2, mode == "dark")
                for (stop in stops) {
                    val card = LayoutMath.glassComposite(stop, p.surface)
                    val tag = preset.id + " " + mode
                    assertTrue("$tag glass main text", ThemeMath.contrast(p.onSurface, card) >= 4.5)
                    assertTrue("$tag glass secondary text", ThemeMath.contrast(p.onVariant, card) >= 4.5)
                }
            }
        }
    }

    @Test
    fun glassOnClassicColoursWithAnyAccent() {
        val accents = listOf(0xFFFF0000L, 0xFF00FF00L, 0xFF0000FFL, 0xFFFFFF00L, 0xFFFF00FFL, 0xFF00FFFFL, 0xFF3B6EF6L)
        val modes = listOf(
            // bg, surface, onSurface, onVariant, dark
            listOf(0xFFF7F7F5L, 0xFFFFFFFFL, 0xFF111318L, 0xFF6B7280L, 0L),
            listOf(0xFF0E0F13L, 0xFF16181DL, 0xFFEDEEF1L, 0xFF9AA0ABL, 1L)
        )
        for (m in modes) {
            for (accent in accents) {
                for (stop in LayoutMath.glassStops(m[0], accent, accent, m[4] == 1L)) {
                    val card = LayoutMath.glassComposite(stop, m[1])
                    assertTrue("main text $accent", ThemeMath.contrast(m[2], card) >= 4.5)
                    // The most extreme single colours (pure blue on light) land a hair under 4.5; 4.4 is the floor.
                    assertTrue("secondary text $accent", ThemeMath.contrast(m[3], card) >= 4.4)
                }
            }
        }
    }

    @Test
    fun neumorphismEdgesAreVisibleButTextUsesTheScreenColour() {
        // The card is the screen colour, so text contrast is the (already tested) text-on-screen contrast.
        // The two edges must really differ from the card, in the right direction.
        for (preset in ThemePresets.all) {
            for ((mode, p) in listOf("light" to preset.light, "dark" to preset.dark)) {
                val dark = mode == "dark"
                val light = LayoutMath.neoLight(p.bg, dark)
                val shade = LayoutMath.neoDark(p.bg, dark)
                assertTrue("${preset.id} $mode light edge is lighter", ThemeMath.luminance(light) >= ThemeMath.luminance(p.bg))
                assertTrue("${preset.id} $mode dark edge is darker", ThemeMath.luminance(shade) < ThemeMath.luminance(p.bg))
            }
        }
    }

    // ---- Stats calendars (the colour deepens with study time) -----------------------------------------------

    private val goal4h: (LocalDate) -> Long = { 4 * 3600L }

    @Test
    fun clockShowsHoursWithoutCappingAtTwentyFour() {
        assertEquals("0:00", StatsEngine.clock(0))
        assertEquals("1:01", StatsEngine.clock(3661))
        assertEquals("30:36", StatsEngine.clock(30 * 3600L + 36 * 60L + 30L))
        assertEquals("0:00", StatsEngine.clock(-5))
    }

    @Test
    fun intensityIsMeasuredAgainstTheGoalOfTheWholeCell() {
        assertEquals(0, StatsEngine.intensity(0, 4 * 3600L))
        assertEquals(1, StatsEngine.intensity(600, 4 * 3600L))
        assertEquals(2, StatsEngine.intensity(2 * 3600L, 4 * 3600L))
        assertEquals(3, StatsEngine.intensity(3 * 3600L, 4 * 3600L))
        assertEquals(4, StatsEngine.intensity(4 * 3600L, 4 * 3600L))
        // A week is judged against a week of goals, so 28 hours against 7 x 4 hours is a full cell.
        assertEquals(4, StatsEngine.intensity(28 * 3600L, 28 * 3600L, 7))
        // No goal at all: fixed hours per day.
        assertEquals(4, StatsEngine.intensity(28 * 3600L, 0, 7))
        assertEquals(1, StatsEngine.intensity(7 * 1800L, 0, 7))
    }

    @Test
    fun quarterAndCalendarRangesAreRight() {
        val aug = LocalDate.of(2025, 8, 15)
        assertEquals(LocalDate.of(2025, 7, 1) to LocalDate.of(2025, 9, 30), StatsEngine.quarterOf(aug))
        assertEquals(3, StatsEngine.quarterNumber(aug))
        // Week tab: the quarter widened to whole weeks (Monday 30 June to Sunday 5 October).
        val (ws, we) = StatsEngine.calendarRange(StatsTab.WEEK, aug, DayOfWeek.MONDAY)
        assertEquals(LocalDate.of(2025, 6, 30), ws)
        assertEquals(LocalDate.of(2025, 10, 5), we)
        // Month tab: the year. Day tab: the month.
        assertEquals(LocalDate.of(2025, 1, 1) to LocalDate.of(2025, 12, 31), StatsEngine.calendarRange(StatsTab.MONTH, aug, DayOfWeek.MONDAY))
        assertEquals(LocalDate.of(2025, 8, 1) to LocalDate.of(2025, 8, 31), StatsEngine.calendarRange(StatsTab.DAY, aug, DayOfWeek.MONDAY))
    }

    @Test
    fun dayCalendarHasOneCellPerDayAndTheRightLeadingBlanks() {
        val aug = LocalDate.of(2025, 8, 16)
        val byDay = mapOf(aug to 4 * 3600L, LocalDate.of(2025, 8, 4) to 3600L)
        val grid = StatsEngine.buildCalendar(StatsTab.DAY, aug, LocalDate.of(2025, 8, 20), DayOfWeek.MONDAY, byDay, goal4h, java.util.Locale.US)!!
        assertEquals(31, grid.cells.size)
        assertEquals(7, grid.columns)
        // 1 August 2025 is a Friday, so with Monday first there are four blanks before it.
        assertEquals(4, grid.leadingBlanks)
        assertEquals(4, grid.cells[15].level)           // the 16th: a full goal
        assertEquals(1, grid.cells[3].level)            // the 4th: 1h of a 4h goal is 25%, the lightest level
        assertEquals(5 * 3600L, grid.totalSeconds)
        assertTrue(grid.cells[25].isFuture)             // 26 August is after "today" (20 August)
        assertFalse(grid.cells[15].isFuture)
    }

    @Test
    fun weekAndMonthCalendarsHaveTheExpectedShape() {
        val today = LocalDate.of(2025, 9, 22)
        val byDay = mapOf(LocalDate.of(2025, 9, 22) to 10 * 3600L, LocalDate.of(2025, 9, 23) to 20 * 3600L)
        val weeks = StatsEngine.buildCalendar(StatsTab.WEEK, today, today, DayOfWeek.MONDAY, byDay, goal4h, java.util.Locale.US)!!
        assertEquals(14, weeks.cells.size)
        assertEquals(5, weeks.columns)
        assertEquals("6/30", weeks.cells.first().label)
        // The week of 22 September holds both days: 30 hours against a 28 hour week of goals.
        val thisWeek = weeks.cells.first { it.date == LocalDate.of(2025, 9, 22) }
        assertEquals(30 * 3600L, thisWeek.seconds)
        assertEquals(4, thisWeek.level)
        val months = StatsEngine.buildCalendar(StatsTab.MONTH, today, today, DayOfWeek.MONDAY, byDay, goal4h, java.util.Locale.US)!!
        assertEquals(12, months.cells.size)
        assertEquals(4, months.columns)
        assertEquals("Sep", months.cells[8].label)
        assertEquals(30 * 3600L, months.cells[8].seconds)
        assertEquals(30 * 3600L, months.totalSeconds)
        assertTrue(months.cells[9].isFuture)            // October starts after 22 September
        assertEquals(null, StatsEngine.buildCalendar(StatsTab.YEAR, today, today, DayOfWeek.MONDAY, byDay, goal4h, java.util.Locale.US))
    }

    @Test
    fun heatColoursDeepenWithEveryLevelAndTextStaysReadable() {
        val accents = listOf(0xFFFF0000L, 0xFF00FF00L, 0xFF0000FFL, 0xFFFFFF00L, 0xFFFF00FFL, 0xFF00FFFFL, 0xFF3B6EF6L, 0xFFF97316L)
        for ((surface, dark) in listOf(0xFFFFFFFFL to false, 0xFF16181DL to true)) {
            for (accent in accents) {
                var previousDistance = -1.0
                var previousLuminance = if (dark) -1.0 else 2.0
                for (level in 1..4) {
                    val fill = HeatMath.fill(level, surface, accent, dark)
                    // The cell moves further away from the card at every level.
                    val distance = Math.abs(ThemeMath.luminance(fill) - ThemeMath.luminance(surface))
                    assertTrue("level $level distance, accent $accent dark=$dark", distance >= previousDistance)
                    previousDistance = distance
                    // On a light theme each level is darker; on a dark theme each level is brighter or equal.
                    val lum = ThemeMath.luminance(fill)
                    if (!dark) assertTrue("light level $level darker, accent $accent", lum <= previousLuminance)
                    previousLuminance = lum
                    // The text on the cell is readable whatever the accent.
                    assertTrue("text on level $level, accent $accent", ThemeMath.contrast(HeatMath.textOn(fill), fill) >= 4.4)
                }
            }
        }
    }

    // ---- "Up to ..." comparison chart -------------------------------------------------------------

    private fun sess(date: LocalDate, fromHour: Int, fromMin: Int, toHour: Int, toMin: Int, id: Long = 1): StudySession =
        StudySession(id = id, subjectId = 1, startTime = millis(date, fromHour, fromMin), endTime = millis(date, toHour, toMin))

    private val h1 = 3600L

    @Test
    fun clockAndRunningTotalsHelpers() {
        assertEquals("26:25:12", StatsEngine.clockSeconds(26 * 3600L + 25 * 60L + 12L))
        assertEquals("0:00:00", StatsEngine.clockSeconds(0L))
        assertEquals("0:00:00", StatsEngine.clockSeconds(-5L))
        assertEquals(listOf(1L, 3L, 6L), StatsEngine.runningTotals(listOf(1L, 2L, 3L)))
        assertEquals(emptyList<Long>(), StatsEngine.runningTotals(emptyList()))
    }

    @Test
    fun compareChartIsNotBuiltForTheYearTab() {
        val today = LocalDate.of(2026, 9, 22)
        val chart = StatsEngine.buildCompareChart(
            StatsTab.YEAR, LocalDate.of(2026, 1, 1), today, millis(today, 12), 0, DayOfWeek.MONDAY, emptyList(), emptyList()
        )
        assertEquals(null, chart)
    }

    @Test
    fun compareWeekUsesThePreviousWeekWhenViewingTheCurrentOne() {
        val today = LocalDate.of(2026, 9, 22)                // Tuesday
        val thisMonday = LocalDate.of(2026, 9, 21)
        val lastMonday = LocalDate.of(2026, 9, 14)
        val baseline = listOf(
            sess(lastMonday, 9, 0, 11, 0, 1),               // Mon 2h
            sess(lastMonday.plusDays(1), 9, 0, 10, 0, 2),   // Tue 1h
            sess(lastMonday.plusDays(2), 9, 0, 12, 0, 3)    // Wed 3h
        )
        val current = listOf(
            sess(thisMonday, 9, 0, 10, 0, 4),               // Mon 1h
            sess(today, 9, 0, 12, 0, 5)                     // Tue 3h
        )
        val chart = StatsEngine.buildCompareChart(
            StatsTab.WEEK, thisMonday, today, millis(today, 14), 0, DayOfWeek.MONDAY, baseline, current
        )!!
        assertEquals(7, chart.bins)
        assertEquals(lastMonday, chart.baselineStart)
        assertTrue(chart.baselineIsPrevious)
        assertEquals(listOf(2 * h1, 3 * h1, 6 * h1, 6 * h1, 6 * h1, 6 * h1, 6 * h1), chart.baselineLevels)
        assertEquals(1, chart.nowIndex)
        assertEquals(listOf(1 * h1, 4 * h1), chart.todayLevels)
        assertEquals(2f, chart.spanBins, 0f)
        assertEquals(1 * h1, chart.diffSeconds)               // 4h today against 3h at the same weekday
    }

    @Test
    fun compareWeekUsesTheViewedWeekWhenItIsInThePast() {
        val today = LocalDate.of(2026, 9, 22)
        val thisMonday = LocalDate.of(2026, 9, 21)
        val pastMonday = LocalDate.of(2026, 9, 14)
        val baseline = listOf(sess(pastMonday, 9, 0, 11, 0, 1), sess(pastMonday.plusDays(1), 9, 0, 10, 0, 2))
        val current = listOf(sess(today, 9, 0, 10, 0, 3))
        val chart = StatsEngine.buildCompareChart(
            StatsTab.WEEK, pastMonday, today, millis(today, 14), 0, DayOfWeek.MONDAY, baseline, current
        )!!
        assertEquals(pastMonday, chart.baselineStart)
        assertFalse(chart.baselineIsPrevious)
        assertEquals(listOf(0L, 1 * h1), chart.todayLevels)   // Monday nothing, Tuesday 1h
        assertEquals(1 * h1 - 3 * h1, chart.diffSeconds)      // behind: record had 3h by Tuesday
    }

    @Test
    fun compareMonthIsBehindTheRecordWithANegativeDifference() {
        val today = LocalDate.of(2026, 9, 22)
        val september = LocalDate.of(2026, 9, 1)
        val august = LocalDate.of(2026, 8, 1)
        val baseline = listOf(
            sess(august, 9, 0, 10, 0, 1),                         // 1 Aug 1h
            sess(august.plusDays(21), 9, 0, 11, 0, 2),            // 22 Aug 2h
            sess(august.plusDays(22), 9, 0, 14, 0, 3)             // 23 Aug 5h (after "now", still part of the record)
        )
        val current = listOf(sess(today, 9, 0, 10, 0, 4))
        val chart = StatsEngine.buildCompareChart(
            StatsTab.MONTH, september, today, millis(today, 14), 0, DayOfWeek.MONDAY, baseline, current
        )!!
        assertEquals(31, chart.bins)                              // August
        assertEquals(21, chart.nowIndex)                          // the 22nd
        assertEquals(22, chart.todayLevels.size)
        assertEquals(3 * h1, chart.baselineLevels[21])
        assertEquals(8 * h1, chart.baselineLevels.last())
        assertEquals(1 * h1, chart.todayLevels.last())
        assertEquals(-2 * h1, chart.diffSeconds)
    }

    @Test
    fun compareDayComparesAtTheExactTimeOfTheStudyDay() {
        val today = LocalDate.of(2026, 9, 22)
        val yesterday = today.minusDays(1)
        val baseline = listOf(
            sess(yesterday, 5, 0, 6, 0, 1),                       // 1h in the second hour
            sess(yesterday, 9, 0, 11, 0, 2)                       // 2h across the sixth and seventh hour
        )
        val current = listOf(
            sess(today, 4, 30, 5, 30, 3),                         // 1h
            sess(today, 10, 0, 10, 30, 4)                         // 30 min, still running at "now"
        )
        val chart = StatsEngine.buildCompareChart(
            StatsTab.DAY, today, today, millis(today, 10, 30), 4, DayOfWeek.MONDAY, baseline, current
        )!!
        assertEquals(24, chart.bins)
        assertEquals(6, chart.nowIndex)                           // 4:00 + 6h = 10:00, inside the 10:00 hour
        assertEquals(6.5f, chart.spanBins, 0.0001f)
        assertEquals(yesterday, chart.baselineStart)
        assertTrue(chart.baselineIsPrevious)
        assertEquals(listOf(1800L, 3600L, 3600L, 3600L, 3600L, 3600L, 5400L), chart.todayLevels)
        assertEquals(0L, chart.baselineLevels[0])
        assertEquals(3600L, chart.baselineLevels[1])
        assertEquals(7200L, chart.baselineLevels[5])
        assertEquals(10800L, chart.baselineLevels[23])
        assertEquals(5400L - 9000L, chart.diffSeconds)            // record had 2.5h by 10:30
    }

    @Test
    fun compareWithNoStudyIsAllZeroAndEven() {
        val today = LocalDate.of(2026, 9, 22)
        for (tab in listOf(StatsTab.DAY, StatsTab.WEEK, StatsTab.MONTH)) {
            val start = StatsEngine.periodOf(tab, today, DayOfWeek.MONDAY).first
            val chart = StatsEngine.buildCompareChart(
                tab, start, today, millis(today, 12), 0, DayOfWeek.MONDAY, emptyList(), emptyList()
            )!!
            assertEquals("diff $tab", 0L, chart.diffSeconds)
            assertTrue("levels $tab", chart.baselineLevels.all { it == 0L } && chart.todayLevels.all { it == 0L })
            assertTrue("today never longer than the axis $tab", chart.todayLevels.size <= chart.bins)
        }
    }
}
