package com.example.ui.navigation

/** The places the app can show. Display names come from string resources (see BottomNavBar), not from here. */
sealed class Screen(val route: String) {
    object Timer : Screen("timer")
    object Planner : Screen("planner")
    object Timeline : Screen("timeline")
    object Stats : Screen("stats")
    object Settings : Screen("settings")
    object DDayManager : Screen("dday_manager")
    object FocusMode : Screen("focus_mode")
    object Onboarding : Screen("onboarding")
}
