package com.example.ui.theme

/**
 * The colours of the stats calendars: the more you study, the deeper the accent colour. ARGB Longs, no Android
 * classes, so the unit tests check the same numbers the screen draws with.
 *
 * Level 0 is "nothing studied" and is drawn by the screen in its own empty colour. Levels 1 to 4 mix the card
 * colour towards the accent: a little, some, most, all. On a LIGHT theme the top level is also pulled towards black,
 * so it really is the darkest cell. On a DARK theme "deeper" cannot mean darker (it would vanish into the card), so
 * it means stronger and brighter instead.
 */
object HeatMath {
    private val LIGHT = floatArrayOf(0.20f, 0.42f, 0.68f, 0.92f)
    private val DARK = floatArrayOf(0.22f, 0.42f, 0.65f, 0.90f)

    /** The fill of a cell with [level] 1..4. [surface] is the card colour the cell sits on. */
    fun fill(level: Int, surface: Long, accent: Long, dark: Boolean): Long {
        val i = (level - 1).coerceIn(0, 3)
        val base = LayoutMath.mix(surface, accent, if (dark) DARK[i] else LIGHT[i])
        return if (!dark && level >= 4) LayoutMath.mix(base, 0xFF000000L, 0.22f) else base
    }

    /** Text on a filled cell: near-black or white, whichever reads better (at least 4.4 on any fill). */
    fun textOn(fill: Long): Long = ThemeMath.onColorFor(fill)
}
