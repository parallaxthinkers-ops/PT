package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.util.DateTimeUtils

private const val MAX_SECONDS = 86_399L

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CountdownDurationPickerDialog(
    initialSeconds: Long,
    onDismiss: () -> Unit,
    onConfirm: (totalSeconds: Long, saveAsPreset: Boolean) -> Unit
) {
    val safeInitial = initialSeconds.coerceIn(1L, MAX_SECONDS)

    // One source of truth: the total. The three text fields are views of it, so what the user sees is
    // always what will be saved (typing "75" into minutes used to show 75 but save 59).
    var totalSeconds by remember { mutableStateOf(safeInitial) }
    var hoursText by remember { mutableStateOf((safeInitial / 3600L).toString()) }
    var minutesText by remember { mutableStateOf(((safeInitial % 3600L) / 60L).toString()) }
    var secondsText by remember { mutableStateOf((safeInitial % 60L).toString()) }
    var saveAsPreset by remember { mutableStateOf(false) }
    var showError by remember { mutableStateOf(false) }

    fun setTotal(newTotal: Long) {
        val t = newTotal.coerceIn(0L, MAX_SECONDS)
        totalSeconds = t
        hoursText = (t / 3600L).toString()
        minutesText = ((t % 3600L) / 60L).toString()
        secondsText = (t % 60L).toString()
        showError = false
    }

    fun hours() = totalSeconds / 3600L
    fun minutes() = (totalSeconds % 3600L) / 60L
    fun seconds() = totalSeconds % 60L

    // Typing edits one unit and keeps the other two.
    fun typed(unit: Int, input: String) {
        val max = if (unit == 0) 23L else 59L
        val value = (input.toLongOrNull() ?: 0L).coerceAtMost(max)
        val shown = if (input.isEmpty()) "" else value.toString()
        val h = if (unit == 0) value else hours()
        val m = if (unit == 1) value else minutes()
        val s = if (unit == 2) value else seconds()
        totalSeconds = h * 3600L + m * 60L + s
        when (unit) {
            0 -> hoursText = shown
            1 -> minutesText = shown
            else -> secondsText = shown
        }
        showError = false
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.countdown_set_duration),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(R.string.dlg_countdown_range_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    shape = MaterialTheme.shapes.large,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        Text(
                            text = DateTimeUtils.formatTimerClock(totalSeconds),
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 2.sp
                        )
                        Text(
                            text = if (totalSeconds > 0L) DateTimeUtils.formatDurationShort(totalSeconds)
                            else stringResource(R.string.dlg_zero_duration),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TimeUnitColumn(
                        text = hoursText,
                        label = stringResource(R.string.dlg_unit_hr),
                        plusDescription = stringResource(R.string.dlg_cd_hour_plus),
                        minusDescription = stringResource(R.string.dlg_cd_hour_minus),
                        tagPrefix = "hours",
                        inputTag = "countdown_hours_input",
                        onTyped = { typed(0, it) },
                        onPlus = { setTotal(totalSeconds + 3600L) },
                        onMinus = { setTotal(totalSeconds - 3600L) }
                    )
                    Text(":", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    TimeUnitColumn(
                        text = minutesText,
                        label = stringResource(R.string.dlg_unit_min),
                        plusDescription = stringResource(R.string.dlg_cd_min_plus),
                        minusDescription = stringResource(R.string.dlg_cd_min_minus),
                        tagPrefix = "minutes",
                        inputTag = "countdown_mins_input",
                        onTyped = { typed(1, it) },
                        onPlus = { setTotal(totalSeconds + 60L) },
                        onMinus = { setTotal(totalSeconds - 60L) }
                    )
                    Text(":", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    TimeUnitColumn(
                        text = secondsText,
                        label = stringResource(R.string.dlg_unit_sec),
                        plusDescription = stringResource(R.string.dlg_cd_sec_plus),
                        minusDescription = stringResource(R.string.dlg_cd_sec_minus),
                        tagPrefix = "seconds",
                        inputTag = "countdown_secs_input",
                        onTyped = { typed(2, it) },
                        onPlus = { setTotal(totalSeconds + 1L) },
                        onMinus = { setTotal(totalSeconds - 1L) }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(1, 5, 15, 30).forEach { minutesToAdd ->
                        SuggestionChip(
                            onClick = { setTotal(totalSeconds + minutesToAdd * 60L) },
                            label = {
                                Text(
                                    stringResource(R.string.dlg_add_minutes, minutesToAdd.toString()),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        )
                    }
                    SuggestionChip(
                        onClick = { setTotal(0L) },
                        label = { Text(stringResource(R.string.dlg_clear), style = MaterialTheme.typography.labelSmall) }
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(
                        checked = saveAsPreset,
                        onCheckedChange = { saveAsPreset = it },
                        modifier = Modifier.testTag("save_as_preset_checkbox")
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.countdown_save_preset),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                if (showError) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = stringResource(R.string.countdown_invalid_range),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (totalSeconds < 1L || totalSeconds > MAX_SECONDS) showError = true
                    else onConfirm(totalSeconds, saveAsPreset)
                },
                modifier = Modifier.testTag("confirm_countdown_duration")
            ) {
                Text(stringResource(R.string.dlg_countdown_confirm))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel))
            }
        }
    )
}

@Composable
private fun TimeUnitColumn(
    text: String,
    label: String,
    plusDescription: String,
    minusDescription: String,
    tagPrefix: String,
    inputTag: String,
    onTyped: (String) -> Unit,
    onPlus: () -> Unit,
    onMinus: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledTonalIconButton(
            onClick = onPlus,
            modifier = Modifier.size(36.dp).testTag("${tagPrefix}_increment_button")
        ) {
            Icon(Icons.Default.Add, contentDescription = plusDescription, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { input ->
                if (input.length <= 2 && input.all { it in '0'..'9' }) onTyped(input)
            },
            label = { Text(label) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.width(76.dp).testTag(inputTag)
        )
        Spacer(modifier = Modifier.height(4.dp))
        FilledTonalIconButton(
            onClick = onMinus,
            modifier = Modifier.size(36.dp).testTag("${tagPrefix}_decrement_button")
        ) {
            Icon(Icons.Default.Remove, contentDescription = minusDescription, modifier = Modifier.size(18.dp))
        }
    }
}
