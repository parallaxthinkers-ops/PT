package com.example.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.data.AppDatabase
import com.example.data.model.StudySession
import com.example.data.repository.SettingsRepository
import com.example.util.DateTimeUtils
import com.example.util.LocaleHelper
import com.example.util.StudyMath
import com.example.widget.StudyGlanceWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.first

/**
 * Owns the running timer. The timer itself is a set of timestamps (start, last resume, accumulated time),
 * never a counter, so elapsed time is always recomputed from the wall clock and survives process death.
 */
class TimerForegroundService : Service() {
    companion object {
        const val CHANNEL_ID = NotificationHelper.CHANNEL_TIMER
        const val COMPLETION_CHANNEL_ID = NotificationHelper.CHANNEL_COMPLETION
        const val NOTIFICATION_ID = NotificationHelper.NOTIFICATION_ID_TIMER
        const val NOTIFICATION_ID_COMPLETION = NotificationHelper.NOTIFICATION_ID_COMPLETION

        const val ACTION_START = "com.example.studylocal.ACTION_START"
        const val ACTION_PAUSE = "com.example.studylocal.ACTION_PAUSE"
        const val ACTION_RESUME = "com.example.studylocal.ACTION_RESUME"
        const val ACTION_STOP = "com.example.studylocal.ACTION_STOP"
        const val ACTION_SWITCH_SUBJECT = "com.example.studylocal.ACTION_SWITCH_SUBJECT"
        const val ACTION_RECORD_INTERRUPTION = "com.example.studylocal.ACTION_RECORD_INTERRUPTION"
        const val ACTION_ADJUST_COUNTDOWN = "com.example.studylocal.ACTION_ADJUST_COUNTDOWN"
        const val ACTION_RESTORE = "com.example.studylocal.ACTION_RESTORE"
        const val ACTION_SKIP_POMO_PHASE = "com.example.studylocal.ACTION_SKIP_POMO_PHASE"

        const val EXTRA_SUBJECT_ID = "extra_subject_id"
        const val EXTRA_SUBJECT_NAME = "extra_subject_name"
        const val EXTRA_SUBJECT_COLOR = "extra_subject_color"
        const val EXTRA_MODE = "extra_mode"
        const val EXTRA_TARGET_SECONDS = "extra_target_seconds"
        const val EXTRA_POMO_FOCUS = "extra_pomo_focus"
        const val EXTRA_POMO_SHORT_BREAK = "extra_pomo_short_break"
        const val EXTRA_POMO_LONG_BREAK = "extra_pomo_long_break"
        const val EXTRA_POMO_INTERVAL = "extra_pomo_interval"
        const val EXTRA_ADJUST_SECONDS = "extra_adjust_seconds"

        const val PREFS_NAME = "studylocal_active_session"
        const val PREF_STATUS = "pref_status"
        const val PREF_MODE = "pref_mode"
        const val PREF_SUBJECT_ID = "pref_subject_id"
        const val PREF_SUBJECT_NAME = "pref_subject_name"
        const val PREF_SUBJECT_COLOR = "pref_subject_color"
        const val PREF_SESSION_START = "pref_session_start"
        const val PREF_LAST_RESUME = "pref_last_resume"
        const val PREF_ACCUMULATED_MS = "pref_accumulated_ms"
        const val PREF_TARGET_SECONDS = "pref_target_seconds"
        const val PREF_POMO_PHASE = "pref_pomo_phase"
        const val PREF_POMO_CYCLE = "pref_pomo_cycle"
        const val PREF_INTERRUPTIONS = "pref_interruptions"
        /** Last time the ticker was alive. Used after a reboot to pause at the right moment. */
        const val PREF_HEARTBEAT = "pref_heartbeat"

        /** Separate from the timer file on purpose: the timer file is wiped whenever a session ends. */
        private const val GOAL_NOTIFIED_PREFS = "studylocal_goal_notified"
        private const val GOAL_NOTIFIED_DAY = "day"
        private const val GOAL_NOTIFIED_ALMOST = "almost"
        private const val GOAL_NOTIFIED_DONE = "done"

        private const val GOAL_CHECK_EVERY_SECONDS = 30L
        private const val HEARTBEAT_EVERY_SECONDS = 15L

        /** Survives the service being destroyed, so a stop never loses the session that is being saved. */
        private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        /**
         * Android 12+ may refuse to start a foreground service from the background. That must never crash
         * the app: the timer state is already on disk and is restored the next time the app is visible.
         */
        private fun send(context: Context, intent: Intent, foreground: Boolean) {
            try {
                if (foreground && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
            }
        }

        private fun intentFor(context: Context, action: String): Intent =
            Intent(context, TimerForegroundService::class.java).apply { this.action = action }

        fun startTimer(
            context: Context,
            subjectId: Long,
            subjectName: String,
            subjectColor: Long,
            mode: TimerMode = TimerMode.STOPWATCH,
            targetSeconds: Long = 0L,
            pomoFocus: Int = 25,
            pomoShortBreak: Int = 5,
            pomoLongBreak: Int = 15,
            pomoInterval: Int = 4
        ) {
            val intent = intentFor(context, ACTION_START).apply {
                putExtra(EXTRA_SUBJECT_ID, subjectId)
                putExtra(EXTRA_SUBJECT_NAME, subjectName)
                putExtra(EXTRA_SUBJECT_COLOR, subjectColor)
                putExtra(EXTRA_MODE, mode.name)
                putExtra(EXTRA_TARGET_SECONDS, targetSeconds)
                putExtra(EXTRA_POMO_FOCUS, pomoFocus)
                putExtra(EXTRA_POMO_SHORT_BREAK, pomoShortBreak)
                putExtra(EXTRA_POMO_LONG_BREAK, pomoLongBreak)
                putExtra(EXTRA_POMO_INTERVAL, pomoInterval)
            }
            send(context, intent, foreground = true)
        }

        fun restoreRunningTimer(context: Context) =
            send(context, intentFor(context, ACTION_RESTORE), foreground = true)

        fun adjustCountdown(context: Context, deltaSeconds: Long) {
            val intent = intentFor(context, ACTION_ADJUST_COUNTDOWN).apply {
                putExtra(EXTRA_ADJUST_SECONDS, deltaSeconds)
            }
            send(context, intent, foreground = false)
        }

        /**
         * Throws the running timer away WITHOUT saving it. Used before restoring a backup or resetting
         * all data, when the saved session would otherwise be written into a database that is being replaced.
         */
        fun discardTimer(context: Context) {
            TimerStateManager.setState(TimerState(status = TimerStatus.STOPPED))
            try {
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
            } catch (_: Exception) {
            }
            try {
                context.stopService(Intent(context, TimerForegroundService::class.java))
            } catch (_: Exception) {
            }
        }

        fun pauseTimer(context: Context) = send(context, intentFor(context, ACTION_PAUSE), false)
        fun resumeTimer(context: Context) = send(context, intentFor(context, ACTION_RESUME), false)
        fun stopTimer(context: Context) = send(context, intentFor(context, ACTION_STOP), false)
        fun skipPomodoroPhase(context: Context) = send(context, intentFor(context, ACTION_SKIP_POMO_PHASE), false)
        fun recordInterruption(context: Context) = send(context, intentFor(context, ACTION_RECORD_INTERRUPTION), false)

        fun switchSubject(
            context: Context,
            newSubjectId: Long,
            newSubjectName: String,
            newSubjectColor: Long
        ) {
            val intent = intentFor(context, ACTION_SWITCH_SUBJECT).apply {
                putExtra(EXTRA_SUBJECT_ID, newSubjectId)
                putExtra(EXTRA_SUBJECT_NAME, newSubjectName)
                putExtra(EXTRA_SUBJECT_COLOR, newSubjectColor)
            }
            send(context, intent, foreground = false)
        }
    }

    // Declared before onCreate on purpose (Playbook: property order matters for init).
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    /** Not cancelled in onDestroy, so an alert that is playing when the service stops still finishes. */
    private val alertScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var tickerJob: Job? = null
    private lateinit var database: AppDatabase
    private lateinit var settingsRepository: SettingsRepository

    private var pomoFocusMinutes = 25
    private var pomoShortBreakMinutes = 5
    private var pomoLongBreakMinutes = 15
    private var pomoInterval = 4

    private var hasNotifiedBreak = false
    private var isForeground = false

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        settingsRepository = SettingsRepository(this)
        NotificationHelper.createChannels(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        if (intent != null && action == ACTION_START) {
            val subjectId = intent.getLongExtra(EXTRA_SUBJECT_ID, -1L)
            val subjectName = intent.getStringExtra(EXTRA_SUBJECT_NAME) ?: ""
            val subjectColor = intent.getLongExtra(EXTRA_SUBJECT_COLOR, 0xFF3B82F6L)
            val mode = try {
                TimerMode.valueOf(intent.getStringExtra(EXTRA_MODE) ?: TimerMode.STOPWATCH.name)
            } catch (_: Exception) {
                TimerMode.STOPWATCH
            }
            val targetSec = intent.getLongExtra(EXTRA_TARGET_SECONDS, 0L)
            pomoFocusMinutes = intent.getIntExtra(EXTRA_POMO_FOCUS, 25).coerceAtLeast(1)
            pomoShortBreakMinutes = intent.getIntExtra(EXTRA_POMO_SHORT_BREAK, 5).coerceAtLeast(1)
            pomoLongBreakMinutes = intent.getIntExtra(EXTRA_POMO_LONG_BREAK, 15).coerceAtLeast(1)
            pomoInterval = intent.getIntExtra(EXTRA_POMO_INTERVAL, 4).coerceAtLeast(1)
            hasNotifiedBreak = false
            handleStart(subjectId, subjectName, subjectColor, mode, targetSec)
            return START_STICKY
        }

        // Every other command (including a null intent after the system restarted the service) first
        // rebuilds the in-memory state from disk. Without this, Pause/Stop from the notification do nothing
        // after the process was killed.
        try {
            SessionRecovery.restoreStateOnly(this)
        } catch (_: Exception) {
        }

        when (action) {
            null, ACTION_RESTORE -> handleRestore()
            ACTION_ADJUST_COUNTDOWN -> handleAdjustCountdown(intent?.getLongExtra(EXTRA_ADJUST_SECONDS, 0L) ?: 0L)
            ACTION_PAUSE -> handlePause()
            ACTION_RESUME -> handleResume()
            ACTION_STOP -> handleStop()
            ACTION_SWITCH_SUBJECT -> handleSwitchSubject(
                intent?.getLongExtra(EXTRA_SUBJECT_ID, -1L) ?: -1L,
                intent?.getStringExtra(EXTRA_SUBJECT_NAME) ?: "",
                intent?.getLongExtra(EXTRA_SUBJECT_COLOR, 0xFF3B82F6L) ?: 0xFF3B82F6L
            )
            ACTION_SKIP_POMO_PHASE -> handleSkipPomodoroPhase()
            ACTION_RECORD_INTERRUPTION -> {
                val current = TimerStateManager.timerState.value
                if (current.status != TimerStatus.STOPPED) {
                    val updated = current.copy(interruptions = current.interruptions + 1)
                    TimerStateManager.setState(updated)
                    saveStateToDisk(updated)
                }
            }
        }

        val state = TimerStateManager.timerState.value
        if (state.status == TimerStatus.STOPPED) {
            // Nothing is running: do not keep an empty service alive.
            shutDown()
            return START_NOT_STICKY
        }
        // A freshly created service instance (after process death) must also become foreground and tick.
        if (!isForeground) enterForeground(state)
        if (state.status == TimerStatus.RUNNING && tickerJob?.isActive != true) startTicker()
        return START_STICKY
    }

    private fun handleRestore() {
        val current = TimerStateManager.timerState.value
        when (current.status) {
            TimerStatus.RUNNING -> {
                enterForeground(current)
                startTicker()
            }
            TimerStatus.PAUSED -> enterForeground(current)
            TimerStatus.STOPPED -> {
                // startForegroundService() obliges us to call startForeground() quickly, even if there is
                // nothing to show. Show a minimal notification, then leave immediately.
                enterForeground(current)
            }
        }
    }

    private fun handleStart(
        subjectId: Long,
        subjectName: String,
        subjectColor: Long,
        mode: TimerMode,
        targetSec: Long
    ) {
        // Starting while something is already running must not lose that time.
        val previous = TimerStateManager.timerState.value
        if (previous.status != TimerStatus.STOPPED) {
            tickerJob?.cancel()
            persistSession(previous)
        }

        val now = System.currentTimeMillis()
        val effectiveTarget = when (mode) {
            TimerMode.STOPWATCH -> 0L
            TimerMode.COUNTDOWN -> if (targetSec > 0) targetSec else 1800L
            TimerMode.POMODORO -> pomoFocusMinutes * 60L
        }

        val initialState = TimerState(
            status = TimerStatus.RUNNING,
            mode = mode,
            subjectId = if (subjectId > 0) subjectId else null,
            subjectName = subjectName,
            subjectColor = subjectColor,
            sessionStartTime = now,
            lastResumeTime = now,
            accumulatedMillis = 0L,
            currentElapsedSeconds = 0L,
            targetSeconds = effectiveTarget,
            remainingSeconds = effectiveTarget,
            pomodoroPhase = PomodoroPhase.FOCUS,
            pomodoroCycle = 1,
            interruptions = 0
        )
        TimerStateManager.setState(initialState)
        saveStateToDisk(initialState)
        enterForeground(initialState)
        startTicker()
        updateGlanceWidget()
    }

    private fun handleAdjustCountdown(deltaSeconds: Long) {
        val current = TimerStateManager.timerState.value
        if (current.mode != TimerMode.COUNTDOWN || current.status == TimerStatus.STOPPED) return

        val newTarget = (current.targetSeconds + deltaSeconds).coerceIn(1L, 86399L)
        val newRemaining = (current.remainingSeconds + deltaSeconds).coerceIn(1L, 86399L)
        val updated = current.copy(targetSeconds = newTarget, remainingSeconds = newRemaining)
        TimerStateManager.setState(updated)
        saveStateToDisk(updated)
        refreshNotification(updated)
    }

    private fun handlePause() {
        val current = TimerStateManager.timerState.value
        if (current.status != TimerStatus.RUNNING) return
        tickerJob?.cancel()

        val now = System.currentTimeMillis()
        val newAccumulated = current.accumulatedMillis + (now - current.lastResumeTime).coerceAtLeast(0L)
        val elapsedSec = newAccumulated / 1000L
        val updated = current.copy(
            status = TimerStatus.PAUSED,
            accumulatedMillis = newAccumulated,
            currentElapsedSeconds = elapsedSec,
            remainingSeconds = if (current.targetSeconds > 0) {
                (current.targetSeconds - elapsedSec).coerceAtLeast(0L)
            } else 0L
        )
        TimerStateManager.setState(updated)
        saveStateToDisk(updated)
        refreshNotification(updated)
        updateGlanceWidget()
    }

    private fun handleResume() {
        val current = TimerStateManager.timerState.value
        if (current.status != TimerStatus.PAUSED) return

        val updated = current.copy(status = TimerStatus.RUNNING, lastResumeTime = System.currentTimeMillis())
        TimerStateManager.setState(updated)
        saveStateToDisk(updated)
        enterForeground(updated)
        startTicker()
        updateGlanceWidget()
    }

    private fun handleStop() {
        tickerJob?.cancel()
        val current = TimerStateManager.timerState.value
        // A second Stop (double tap, notification + button) finds STOPPED and does nothing.
        if (current.status != TimerStatus.STOPPED) {
            persistSession(current)
            // A stopwatch has no "end" the app could beep at, so it only leaves a quiet note.
            if (current.mode == TimerMode.STOPWATCH && current.currentElapsedSeconds >= 1L) {
                val text = LocaleHelper.localized(this)
                val name = current.subjectName.ifEmpty { text.getString(R.string.notif_default_subject) }
                NotificationHelper.showSilentSessionSavedNotification(
                    this,
                    text.getString(R.string.notif_session_saved_title),
                    text.getString(R.string.notif_session_saved_msg, name, DateTimeUtils.formatDurationShort(current.currentElapsedSeconds))
                )
            }
            TimerStateManager.setState(TimerState(status = TimerStatus.STOPPED))
        }
        updateGlanceWidget()
        shutDown()
    }

    private fun handleSwitchSubject(newSubjectId: Long, newSubjectName: String, newSubjectColor: Long) {
        val current = TimerStateManager.timerState.value
        if (current.status == TimerStatus.STOPPED) return
        persistSession(current)

        val now = System.currentTimeMillis()
        val targetSec = when (current.mode) {
            TimerMode.STOPWATCH -> 0L
            TimerMode.COUNTDOWN -> current.targetSeconds
            TimerMode.POMODORO -> current.targetSeconds
        }
        // Keep the Pomodoro phase and cycle. Only the subject changes; the phase timer restarts.
        val newState = current.copy(
            subjectId = if (newSubjectId > 0) newSubjectId else null,
            subjectName = newSubjectName,
            subjectColor = newSubjectColor,
            sessionStartTime = now,
            lastResumeTime = now,
            accumulatedMillis = 0L,
            currentElapsedSeconds = 0L,
            remainingSeconds = targetSec,
            interruptions = 0
        )
        TimerStateManager.setState(newState)
        saveStateToDisk(newState)
        refreshNotification(newState)
        if (newState.status == TimerStatus.RUNNING) startTicker()
        updateGlanceWidget()
    }

    private fun handleSkipPomodoroPhase() {
        val current = TimerStateManager.timerState.value
        if (current.mode != TimerMode.POMODORO || current.status == TimerStatus.STOPPED) return
        tickerJob?.cancel()
        tickerJob = serviceScope.launch {
            advancePomodoroPhase(current, skipped = true)
            if (TimerStateManager.timerState.value.status == TimerStatus.RUNNING) {
                runTickerLoop()
            }
        }
    }

    /** Saves what the timer has recorded so far. Pomodoro breaks are never study time. */
    private fun persistSession(state: TimerState) {
        val session = buildSession(state)
        val startOfSavedSession = state.sessionStartTime
        ioScope.launch {
            if (session != null) {
                try {
                    database.studySessionDao().insert(session)
                } catch (_: Exception) {
                }
            }
            // Only clear the saved timer if it still belongs to the session we just stored; a new session
            // may already have been started.
            clearStateFromDiskIfSession(startOfSavedSession)
        }
    }

    private fun buildSession(state: TimerState): StudySession? {
        val subjectId = state.subjectId ?: return null
        if (state.mode == TimerMode.POMODORO && state.pomodoroPhase != PomodoroPhase.FOCUS) return null

        val now = System.currentTimeMillis()
        val totalMs = if (state.status == TimerStatus.RUNNING) {
            state.accumulatedMillis + (now - state.lastResumeTime).coerceAtLeast(0L)
        } else {
            state.accumulatedMillis
        }
        val effectiveMs = if (state.targetSeconds > 0 &&
            (state.mode == TimerMode.COUNTDOWN || state.mode == TimerMode.POMODORO)
        ) {
            minOf(totalMs, state.targetSeconds * 1000L)
        } else {
            totalMs
        }
        if (effectiveMs < 1000L) return null

        val start = state.sessionStartTime.takeIf { it > 0 } ?: (now - effectiveMs)
        return StudySession(
            subjectId = subjectId,
            startTime = start,
            endTime = start + effectiveMs,
            mode = state.mode.name,
            interruptions = state.interruptions
        )
    }

    private fun startTicker() {
        tickerJob?.cancel()
        tickerJob = serviceScope.launch { runTickerLoop() }
    }

    /** Runs inside [tickerJob]. Aligned to second boundaries so the display never drifts or skips. */
    private suspend fun runTickerLoop() {
        while (serviceScope.isActive) {
            val s = TimerStateManager.timerState.value
            if (s.status != TimerStatus.RUNNING) return

            val now = System.currentTimeMillis()
            val totalMs = s.accumulatedMillis + (now - s.lastResumeTime).coerceAtLeast(0L)
            delay(1000L - (totalMs % 1000L))

            val current = TimerStateManager.timerState.value
            if (current.status != TimerStatus.RUNNING || current.sessionStartTime != s.sessionStartTime) {
                if (current.status != TimerStatus.RUNNING) return
                continue
            }

            val liveMs = current.accumulatedMillis + (System.currentTimeMillis() - current.lastResumeTime).coerceAtLeast(0L)
            val sec = liveMs / 1000L

            when (current.mode) {
                TimerMode.STOPWATCH -> {
                    TimerStateManager.setState(current.copy(currentElapsedSeconds = sec))
                }
                TimerMode.COUNTDOWN, TimerMode.POMODORO -> {
                    val rem = (current.targetSeconds - sec).coerceAtLeast(0L)
                    val updated = current.copy(currentElapsedSeconds = sec, remainingSeconds = rem)
                    TimerStateManager.setState(updated)
                    if (rem == 0L) {
                        if (current.mode == TimerMode.COUNTDOWN) {
                            finishCountdown(updated)
                            return
                        }
                        advancePomodoroPhase(updated, skipped = false)
                        continue
                    }
                }
            }

            if (sec > 0 && sec % HEARTBEAT_EVERY_SECONDS == 0L) saveHeartbeat()
            if (sec > 0 && sec % 60L == 0L) updateGlanceWidget()
            if (sec > 0 && sec % GOAL_CHECK_EVERY_SECONDS == 0L) checkBreakReminderAndGoalProgress(sec)
        }
    }

    private fun finishCountdown(state: TimerState) {
        val text = LocaleHelper.localized(this)
        val name = state.subjectName.ifEmpty { text.getString(R.string.notif_default_subject) }
        val alert = playAlertSoundAndVibration(isBreakEnd = false, pomodoro = false)
        NotificationHelper.showCompletionNotification(
            this,
            text.getString(R.string.countdown_complete_title),
            text.getString(R.string.countdown_complete_message, DateTimeUtils.formatDurationShort(state.targetSeconds), name)
        )
        persistSession(state)
        TimerStateManager.setState(TimerState(status = TimerStatus.STOPPED))
        updateGlanceWidget()
        // Let the beeps finish before the service stops. If the person starts a new timer meanwhile, keep running.
        serviceScope.launch {
            withTimeoutOrNull(3_000L) { alert.join() }
            if (TimerStateManager.timerState.value.status == TimerStatus.STOPPED) shutDown()
        }
    }

    private fun checkBreakReminderAndGoalProgress(continuousSeconds: Long) {
        serviceScope.launch(Dispatchers.IO) {
            try {
                val settings = settingsRepository.settings.first()
                if (settings.breakReminderEnabled && !hasNotifiedBreak &&
                    continuousSeconds >= settings.breakReminderMinutes * 60L
                ) {
                    hasNotifiedBreak = true
                    NotificationHelper.showBreakReminderNotification(this@TimerForegroundService, settings.breakReminderMinutes)
                }

                val now = System.currentTimeMillis()
                val dayStartHour = settings.dayStartHour
                val (startMs, endMs) = DateTimeUtils.getStudyDayRange(now, dayStartHour)
                val sessions = database.studySessionDao().getSessionsInRangeList(startMs, endMs)
                var totalTodaySec = continuousSeconds
                for (s in sessions) {
                    totalTodaySec += DateTimeUtils.getSessionOverlapMillis(s, startMs, endMs) / 1000L
                }
                val weekday = StudyMath.calendarWeekday(DateTimeUtils.studyDateOf(now, dayStartHour))
                val goal = database.goalDao().getGoalForWeekday(weekday)
                val goalSec = (goal?.targetMinutes ?: 240) * 60L

                if (goalSec > 0) {
                    // "Almost there" and "Goal reached" are told ONCE PER STUDY DAY. They used to be remembered only
                    // for the current timer run, so every new timer started after the goal was met announced it again.
                    val flags = getSharedPreferences(GOAL_NOTIFIED_PREFS, Context.MODE_PRIVATE)
                    val dayKey = DateTimeUtils.getStudyDateString(now, dayStartHour)
                    if (flags.getString(GOAL_NOTIFIED_DAY, null) != dayKey) {
                        flags.edit().clear().putString(GOAL_NOTIFIED_DAY, dayKey).apply()
                    }
                    if (!flags.getBoolean(GOAL_NOTIFIED_ALMOST, false) &&
                        totalTodaySec >= (0.9 * goalSec) && totalTodaySec < goalSec
                    ) {
                        flags.edit().putBoolean(GOAL_NOTIFIED_ALMOST, true).apply()
                        NotificationHelper.showGoalAlmostReachedNotification(this@TimerForegroundService)
                    }
                    if (!flags.getBoolean(GOAL_NOTIFIED_DONE, false) && totalTodaySec >= goalSec) {
                        flags.edit()
                            .putBoolean(GOAL_NOTIFIED_ALMOST, true)
                            .putBoolean(GOAL_NOTIFIED_DONE, true)
                            .apply()
                        NotificationHelper.showGoalAchievedNotification(this@TimerForegroundService)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private suspend fun advancePomodoroPhase(current: TimerState, skipped: Boolean) {
        val now = System.currentTimeMillis()
        val isEndingFocus = current.pomodoroPhase == PomodoroPhase.FOCUS
        val text = LocaleHelper.localized(this)

        // Fresh values, because the service may have been restarted and lost its fields.
        try {
            val s = settingsRepository.settings.first()
            pomoFocusMinutes = s.pomoFocusMinutes
            pomoShortBreakMinutes = s.pomoShortBreakMinutes
            pomoLongBreakMinutes = s.pomoLongBreakMinutes
            pomoInterval = s.pomoInterval.coerceAtLeast(1)
        } catch (_: Exception) {
        }
        val autoStart = try { settingsRepository.settings.first().pomoAutoStart } catch (_: Exception) { false }

        if (!skipped) playAlertSoundAndVibration(isBreakEnd = !isEndingFocus, pomodoro = true)

        val updated: TimerState
        if (isEndingFocus) {
            persistSession(current)
            val isLongBreak = (current.pomodoroCycle % pomoInterval) == 0
            val nextPhase = if (isLongBreak) PomodoroPhase.LONG_BREAK else PomodoroPhase.SHORT_BREAK
            val breakMinutes = if (isLongBreak) pomoLongBreakMinutes else pomoShortBreakMinutes
            val targetSec = breakMinutes * 60L

            if (!skipped) {
                NotificationHelper.showCompletionNotification(
                    this,
                    text.getString(R.string.notif_focus_done_title),
                    text.getString(
                        if (isLongBreak) R.string.notif_long_break_msg else R.string.notif_short_break_msg,
                        breakMinutes
                    )
                )
            }
            updated = current.copy(
                status = if (autoStart) TimerStatus.RUNNING else TimerStatus.PAUSED,
                pomodoroPhase = nextPhase,
                sessionStartTime = now,
                lastResumeTime = now,
                accumulatedMillis = 0L,
                currentElapsedSeconds = 0L,
                targetSeconds = targetSec,
                remainingSeconds = targetSec,
                interruptions = 0
            )
        } else {
            val nextCycle = current.pomodoroCycle + 1
            val targetSec = pomoFocusMinutes * 60L
            if (!skipped) {
                NotificationHelper.showCompletionNotification(
                    this,
                    text.getString(R.string.notif_break_over_title),
                    text.getString(R.string.notif_break_over_msg, nextCycle, pomoFocusMinutes)
                )
            }
            updated = current.copy(
                status = if (autoStart) TimerStatus.RUNNING else TimerStatus.PAUSED,
                pomodoroPhase = PomodoroPhase.FOCUS,
                pomodoroCycle = nextCycle,
                sessionStartTime = now,
                lastResumeTime = now,
                accumulatedMillis = 0L,
                currentElapsedSeconds = 0L,
                targetSeconds = targetSec,
                remainingSeconds = targetSec
            )
        }
        TimerStateManager.setState(updated)
        saveStateToDisk(updated)
        refreshNotification(updated)
        updateGlanceWidget()
    }

    /**
     * Beeps and vibrates. Runs in [alertScope], NOT in [serviceScope]: when a countdown ends the service stops
     * itself, which cancels serviceScope and used to cut the beep off before it was heard.
     */
    private fun playAlertSoundAndVibration(isBreakEnd: Boolean, pomodoro: Boolean): Job {
        return alertScope.launch {
            val settings = try { settingsRepository.settings.first() } catch (_: Exception) { return@launch }
            // Countdown and Pomodoro each have their own sound and vibration switches.
            val soundOn = if (pomodoro) settings.pomoSound else settings.countdownSound
            val vibrationOn = if (pomodoro) settings.pomoVibration else settings.countdownVibration

            if (soundOn) {
                // A short beep, not the phone's ringtone: it is clear without being loud or long.
                // Focus end = three beeps, break end = two.
                var tone: ToneGenerator? = null
                try {
                    tone = ToneGenerator(AudioManager.STREAM_ALARM, 80)
                    val beeps = if (isBreakEnd) 2 else 3
                    repeat(beeps) {
                        tone.startTone(ToneGenerator.TONE_PROP_BEEP, 180)
                        delay(320L)
                    }
                } catch (_: Exception) {
                } finally {
                    try { tone?.release() } catch (_: Exception) {}
                }
            }

            if (vibrationOn) {
                try {
                    val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
                    } else {
                        @Suppress("DEPRECATION")
                        getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                    }
                    // One pulse when a break ends, two when focus ends.
                    val effect = if (isBreakEnd) {
                        VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE)
                    } else {
                        VibrationEffect.createWaveform(longArrayOf(0, 300, 200, 400), -1)
                    }
                    vibrator?.vibrate(effect)
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun updateGlanceWidget() {
        serviceScope.launch {
            try {
                StudyGlanceWidget.updateAll(this@TimerForegroundService)
            } catch (_: Exception) {
            }
        }
    }

    private fun enterForeground(state: TimerState) {
        try {
            val notification = buildNotification(state)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            isForeground = true
        } catch (_: Exception) {
            // Refused by the system (background start limits). State stays on disk; the app restores it
            // the next time it is opened.
            isForeground = false
        }
    }

    private fun refreshNotification(state: TimerState) {
        if (!isForeground) {
            enterForeground(state)
            return
        }
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, buildNotification(state))
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(state: TimerState): Notification {
        val text = LocaleHelper.localized(this)
        val name = state.subjectName.ifEmpty { text.getString(R.string.notif_default_subject) }
        val running = state.status == TimerStatus.RUNNING
        val now = System.currentTimeMillis()

        val title = if (state.mode == TimerMode.POMODORO) {
            val phase = when (state.pomodoroPhase) {
                PomodoroPhase.FOCUS -> text.getString(R.string.pomo_phase_focus)
                PomodoroPhase.SHORT_BREAK -> text.getString(R.string.pomo_phase_short_break)
                PomodoroPhase.LONG_BREAK -> text.getString(R.string.pomo_phase_long_break)
            }
            "$name • $phase (${state.pomodoroCycle})"
        } else {
            name
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setSmallIcon(R.drawable.ic_notification_small)
            .setContentIntent(NotificationHelper.appPendingIntent(this))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        if (state.subjectColor != 0L) builder.setColor(state.subjectColor.toInt())

        if (running && state.status != TimerStatus.STOPPED) {
            // The system draws the ticking clock itself, so the service does not have to update the
            // notification every second (saves battery and avoids notification rate limits).
            val liveMs = state.accumulatedMillis + (now - state.lastResumeTime).coerceAtLeast(0L)
            builder.setShowWhen(true).setUsesChronometer(true)
            if (state.mode == TimerMode.STOPWATCH) {
                builder.setWhen(now - liveMs)
                    .setContentText(text.getString(R.string.notif_running_stopwatch))
            } else {
                val remainingMs = (state.targetSeconds * 1000L - liveMs).coerceAtLeast(0L)
                builder.setWhen(now + remainingMs)
                    .setChronometerCountDown(true)
                    .setContentText(text.getString(R.string.notif_running_countdown))
            }
        } else {
            val shown = if (state.mode == TimerMode.STOPWATCH) state.currentElapsedSeconds else state.remainingSeconds
            builder.setShowWhen(false).setUsesChronometer(false)
                .setContentText(text.getString(R.string.notif_paused) + " • " + DateTimeUtils.formatTimerClock(shown))
        }

        if (running) {
            builder.addAction(
                android.R.drawable.ic_media_pause,
                text.getString(R.string.notif_action_pause),
                servicePendingIntent(1, ACTION_PAUSE)
            )
        } else if (state.status == TimerStatus.PAUSED) {
            builder.addAction(
                android.R.drawable.ic_media_play,
                text.getString(R.string.notif_action_resume),
                servicePendingIntent(2, ACTION_RESUME)
            )
        }
        builder.addAction(
            android.R.drawable.ic_menu_close_clear_cancel,
            text.getString(R.string.notif_action_stop),
            servicePendingIntent(3, ACTION_STOP)
        )
        return builder.build()
    }

    private fun servicePendingIntent(requestCode: Int, action: String): PendingIntent =
        PendingIntent.getService(
            this,
            requestCode,
            Intent(this, TimerForegroundService::class.java).apply { this.action = action },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun shutDown() {
        tickerJob?.cancel()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        } catch (_: Exception) {
        }
        isForeground = false
        stopSelf()
    }

    private fun saveHeartbeat() {
        try {
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putLong(PREF_HEARTBEAT, System.currentTimeMillis())
                .apply()
        } catch (_: Exception) {
        }
    }

    private fun saveStateToDisk(state: TimerState) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().apply {
            putString(PREF_STATUS, state.status.name)
            putString(PREF_MODE, state.mode.name)
            putLong(PREF_SUBJECT_ID, state.subjectId ?: -1L)
            putString(PREF_SUBJECT_NAME, state.subjectName)
            putLong(PREF_SUBJECT_COLOR, state.subjectColor)
            putLong(PREF_SESSION_START, state.sessionStartTime)
            putLong(PREF_LAST_RESUME, state.lastResumeTime)
            putLong(PREF_ACCUMULATED_MS, state.accumulatedMillis)
            putLong(PREF_TARGET_SECONDS, state.targetSeconds)
            putString(PREF_POMO_PHASE, state.pomodoroPhase.name)
            putInt(PREF_POMO_CYCLE, state.pomodoroCycle)
            putInt(PREF_INTERRUPTIONS, state.interruptions)
            putLong(PREF_HEARTBEAT, System.currentTimeMillis())
            apply()
        }
    }

    @Synchronized
    private fun clearStateFromDiskIfSession(sessionStart: Long) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getLong(PREF_SESSION_START, -1L)
        val stoppedInMemory = TimerStateManager.timerState.value.status == TimerStatus.STOPPED
        if (saved == sessionStart || (stoppedInMemory && saved != -1L)) {
            prefs.edit().clear().apply()
        }
    }

    override fun onDestroy() {
        tickerJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }
}
