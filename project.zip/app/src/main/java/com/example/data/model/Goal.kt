package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey
    val weekday: Int, // 1 = Sunday, 2 = Monday, ... 7 = Saturday (Calendar.SUNDAY, etc.)
    val targetMinutes: Int = 240 // Default 4 hours
)
